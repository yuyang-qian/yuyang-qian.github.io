# /usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2022-01-7, 周五, 20:02
# @File    : image_data.py
############################

import torch
import torch.utils.data as data

from utils.shift_simulate import *


class CustomDataset(data.Dataset):
    def __init__(self, data, labels):
        self.data = data
        self.labels = labels
        
        if isinstance(self.data, np.ndarray):
            self.data = torch.from_numpy(self.data)
        self.data = self.data.float()
    
    def __getitem__(self, index):
        pass
    
    def __len__(self):
        return len(self.data)


class TrainDataset(CustomDataset):
    def __init__(self, data, labels):
        super(TrainDataset, self).__init__(data, labels)
    
    def __getitem__(self, index):
        return self.data[index], self.labels[index]


class SimulateTestDataset(CustomDataset):
    def __init__(self, data, labels, **kwargs):
        super(SimulateTestDataset, self).__init__(data, labels)
        self.rng = np.random.default_rng(kwargs.get("seed", 1214))
        self.shift_gen = eval(kwargs['shift']['type'])(rng=self.rng,
                                                       **kwargs['shift']['kwargs'])
        self.batch_size = kwargs['batch_size']
        
        self.data_menu = {}
        for i in np.unique(self.labels):
            self.data_menu[i] = np.where(self.labels == i)[0]
    
    def __getitem__(self, t):
        priors = self.shift_gen(t)
        cls_num = len(priors)
        dim = self.data.shape[1]
        priors /= np.sum(priors)
        labels = self.rng.choice(cls_num, size=self.batch_size, p=priors)
        data = torch.zeros((self.batch_size, dim), device=self.data.device)
        
        for i in range(cls_num):
            idx = (labels == i)
            num = idx.sum()
            data_idx_idx = self.rng.choice(len(self.data_menu[i]), size=num, replace=False)
            
            data_idx = self.data_menu[i][data_idx_idx]
            data[idx] = self.data[data_idx]
        
        return data, torch.from_numpy(labels), priors


def get_img_data(cfgs, bbox=False):
    train_data = torch.load(cfgs['source_data']['path'])
    if 'soft_preds' in train_data:
        train_features = train_data['soft_preds']
    else:
        train_features = train_data['features']
    train_labels = train_data['labels']
    
    test_data = torch.load(cfgs['online_data']['path'])
    if 'soft_preds' in test_data:
        test_features = test_data['soft_preds']
    else:
        test_features = test_data['features']
    test_labels = test_data['labels']
    
    train_set = TrainDataset(
        data=train_features,
        labels=train_labels,
    )
    
    if bbox:
        test_set = TrainDataset(
            data=test_features,
            labels=test_labels,
        )
    else:
        test_set = SimulateTestDataset(
            data=test_features,
            labels=test_labels,
            seed=cfgs['seed'],
            **cfgs['online_data']
        )
    
    cls_num = len(train_labels.unique())
    count = torch.bincount(train_labels, minlength=cls_num)
    priors = count / count.sum()
    
    info = {
        'cls_num'    : cls_num,
        'dim'        : train_features.shape[1],
        'init_priors': priors,
    }
    
    return train_set, test_set, info
