# /usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2022-12-31, 周五, 16:18

# @File    : wrapper.py
############################
from dataset.toy_data import ToyTrainSet, ToyTestSet
from dataset.table_data import get_table_data
from dataset.image_data import get_img_data


def get_dataset(name, cfgs, rng):
    train_set, test_set, info = None, None, {}
    if name == 'toy':
        train_set = ToyTrainSet(cfgs, rng=rng)
        info = train_set.info
        test_set = ToyTestSet(cfgs, info, rng=rng)
    elif name == "table":
        train_set, test_set, info = get_table_data(cfgs)
    elif name == "image":
        train_set, test_set, info = get_img_data(cfgs)
    else:
        raise NotImplementedError
    
    return train_set, test_set, info
