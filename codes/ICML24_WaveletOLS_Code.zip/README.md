# Python implementation for "Efficient Non-stationary Online Learning by Wavelets with Application to Online Label Shift"

This is the python implementation for the experiments in the paper "**Efficient Non-stationary Online Learning by Wavelets with Application to Online Label Shift**". We will first introduce the structure and requirements of the code, followed by a brief instruction for a quick start.

## Code Structure

`main.py` is the entrance of the program. The code mainly contains the following three parts.

* **online**: Implementations of the proposed algorithms (Wav-O and Wav-R).

* **dataset**: Code for datasets pre-processing.

* **utils**: Useful tools for running the code.

## Requirements

* matplotlib==3.3.3
* numpy==1.19.2
* pandas==1.4.1
* prettytable==0.9.2
* PyYAML==6.0
* scikit_learn==0.23.2
* torch==1.7.0
* tqdm==4.62.3

## Download Data

Please first download the dataset in the following link and put them in the folder `./demos/locomotion/data`:

``https://anonymous.4open.science/r/NeurIPS23_Wavelet-B4D8/demos/locomotion/data/train_data.csv``

``https://anonymous.4open.science/r/NeurIPS23_Wavelet-B4D8/demos/locomotion/data/test_data.csv``

## Quick Start

We provide several demos in the folder *./demos*. To get a quick start, the readers can run any demo by `bash train.sh` in the corresponding path with the parameter specified in `config.yaml`.

For example, one can use ``./demos/locomotion/Wav-O/train.sh`` to run Wav-O algorithm over the SHL datasets, whose parameters are set as ``./demos/locomotion/Wav-O/config.yaml``
