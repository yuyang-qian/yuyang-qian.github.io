
import argparse

import torch
import torch.utils.data as data

import sys
sys.path.append('..')

from os.path import join
from utils.temperature_scaling import ModelWithTemperature
from model.linear import Linear
from dataset.toy_data import get_toy_data
import numpy as np

def dataset_setup(rng):
    toy_cfgs = {
        'dim': 12, 'sigma': 0.1, 'centers': None, 'cls_num': 3,
        'source_priors': [1 / 3, 1 / 3, 1 / 3], 'dst_priors': [0, 0, 1.0],
        'train_num': 10000, 'test_num': 5000,
    }

    train_set, test_set, info = get_toy_data(rng, **toy_cfgs)

    return train_set, test_set, info


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_path", type=str)
    parser.add_argument("--output_path", type=str)
    args = parser.parse_args()

    rng = np.random.default_rng(1881)
    train_set, test_set, info = dataset_setup(rng)
    val_loader = data.DataLoader(train_set, batch_size=5000,
                                  shuffle=True, pin_memory=False)

    ori_model = Linear(input_dim=info['dim'], output_dim=info['cls_num'], R=100)
    ori_model.load_state_dict(torch.load(args.model_path, map_location='cpu'))

    model = ModelWithTemperature(ori_model)
    model.set_temperature(val_loader)

    torch.save(model.state_dict(), join(args.output_path, 'calibration_model.bin'))
