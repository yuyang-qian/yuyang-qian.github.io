import os
import time

import math
import numpy as np
import psutil
import pywt
import torch
from tqdm import trange

from StreamingWaveletPkg.StreamingWavelet import StreamingWavelet, StreamingWaveletCDJV
from StandardWavelet import fast_transform


# from memory_profiler import profile


# @profile
def test_Streaming():
    t0 = time.time()
    # print('\nSequential:')
    # wav_fast_np = SequentialWavelet(dim=dim, max_length=length, order=3, verbose=False, mem_statistic=mem_statistic)
    # wav_fast_np = StreamingWavelet(dim=dim, max_length=length, get_coeff=True, order=8, verbose=False, memory_statistic=mem_statistic)
    wav_fast_np = StreamingWavelet(dim=dim, max_length=length, get_coeff=False, order=order, verbose=False)
    
    for s in trange(length, desc='Streaming Fast Wavelet'):
        wav_fast_np.add_signal(signal[s, :].numpy())
        tmp_norm = wav_fast_np.get_norm()
    
    print('\nStreaming Wavelet Time: {}s'.format(time.time() - t0))
    # print('NP Wavelet Mem: {}mb'.format(max_mem_use))
    # print('\nFast Result:', wav_fast.all_coeff_arrs)
    print('Streaming Wavelet Norm:', wav_fast_np.get_norm())
    # print('Length of Wavelet Coeffs:', len(wav_fast_np.all_coeff_arrs))
    # print('Wavelet Coeffs:', np.array(wav_fast_np.all_coeff_arrs).reshape(-1))
    print()


def test_Streaming_CDJV():
    t0 = time.time()
    # print('\nSequential:')
    # wav_fast_np = SequentialWavelet(dim=dim, max_length=length, order=3, verbose=False, mem_statistic=mem_statistic)
    # wav_fast_np = StreamingWavelet(dim=dim, max_length=length, get_coeff=True, order=8, verbose=False, memory_statistic=mem_statistic)
    wav_fast_np = StreamingWaveletCDJV(dim=dim, max_length=length, get_coeff=False, order=order, verbose=False)
    
    for s in trange(length, desc='Streaming CDJV Wavelet'):
        wav_fast_np.add_signal(signal[s, :].numpy())
        tmp_norm = wav_fast_np.get_norm()
    
    print('\nStreaming CDJV Wavelet Time: {}s'.format(time.time() - t0))
    # print('NP Wavelet Mem: {}mb'.format(max_mem_use))
    # print('\nFast Result:', wav_fast.all_coeff_arrs)
    print('Streaming CDJV Wavelet Norm:', wav_fast_np.get_norm())
    # print('Length of Wavelet Coeffs:', len(wav_fast_np.all_coeff_arrs))
    # print('Wavelet Coeffs:', np.array(wav_fast_np.all_coeff_arrs).reshape(-1))
    print()


# @profile
def test_pywt(mem=False):
    signal_old = torch.zeros_like(signal)
    # coeffs = pywt.dwt(signal_old, 'haar')
    # W, true_coeff = slowWavelet(signal_old, order=3, normalized=False, mem_statistic=True)
    # true_coeff = pywt.wavedec(signal.numpy(), 'db{}'.format(order))
    true_coeff = pywt.wavedec(signal.numpy()[:, 0].reshape(-1), 'db{}'.format(order))
    # print('True coeff:', true_coeff)
    t0 = time.time()
    # Sequentially using true coeff:
    for i in trange(length, desc='Pywt Wavelet'):
        # if length > 2 ** 10 and i < length - 100: continue
        if not mem:
            if length > 2 ** 12 and i > 100: break
        if mem:
            if length > 2 ** 12 and i < length - 100: continue
        signal_old[i, :] = signal[i, :]
        # if i == length - 1:
        # W, true_coeff = slowWavelet(signal=signal_old, order=3, normalized=False, mem_statistic=mem_statistic)
        tmp_norm = 0.0
        for j in range(dim):
            # _, true_coeff = pywt.dwt(signal_old[:, j].double().numpy(), 'haar')
            coeff = pywt.wavedec(signal_old[:, j].double().numpy(), 'db{}'.format(order))
            # tmp_norm += np.linalg.norm(true_coeff[1:]) ** 2
            tmp_norm += sum([np.linalg.norm(x) ** 2 for x in coeff[1:]])
            # print('True coeff:', true_coeff)  # first element is the sum of the signal
    # print('True norm:', torch.norm(true_coeff))
    if not mem:
        print('\nPywt Wavelet Time: {}s'.format(time.time() - t0))
        # print('Pywt Wavelet Mem: {}mb'.format(max_mem_use))
        # print('Standard Wavelet Result:', true_coeff[1:])
        print('Pywt Wavelet Norm:', math.sqrt(tmp_norm))
        print()


# @profile
def test_Standard(mem=False):
    t = fast_transform.FastWaveletTransform('db{}'.format(order))
    t0 = time.time()
    signal_old = torch.zeros_like(signal)
    for i in trange(length, desc='Standard Wavelet'):
        # if length > 2 ** 10 and i < length - 100: continue
        if not mem:
            if length > 2 ** 12 and i > 10: break
        if mem:
            if length > 2 ** 12 and i < length - 5: continue
        signal_old[i, :] = signal[i, :]
        coefficients = t.waveDec(signal_old)
        tmp_norm = np.linalg.norm(coefficients)
    if not mem:
        # print('True Coeff:', np.array(coefficients).reshape(-1))
        print('\nStandard Wavelet Time: {}s'.format(time.time() - t0))
        # print('Standard Wavelet Mem: {}mb'.format(max_mem_use))
        # print('Standard Wavelet Result:', true_coeff[1:])
        print('Standard Wavelet Norm:', tmp_norm)


# signal = torch.randn(length)
# signal = torch.tensor([[1.0, 7.0, 5.0, 3.0, 2.0, 6.0, 9.0, 1.0]]).reshape(8, 1)

# signal = torch.tensor([1.0, 7.0, 5.0, 3.0, 1.85, 5.4, 6.7, 1.2]).reshape(8, 1)
# signal = torch.randn(128, 1)
signal = torch.randn(2 ** 15, 64)
# signal = torch.tensor([1.0, 7.0, 5.0, 3.0])
length = signal.shape[0]
dim = signal.shape[1]
order = 2

if __name__ == '__main__':
    test_Streaming_CDJV()
    
    # Steraming Wavelet:
    test_Streaming()
    # print('Streaming mem: %.2f MB' % (psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024))
    
    # Pywt Wavelet:
    test_pywt()
    # print('Pywt mem: %.2f MB' % (psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024))
    
    # Standard Wavelet:
    test_Standard()
    
    #
    #
    t = fast_transform.FastWaveletTransform('db{}'.format(order))
    coefficients = t.waveDec(signal)
    # print('True Coeff:', np.array(coefficients).reshape(-1))
    print('True Norm:', np.linalg.norm(coefficients))
    
    #
    #
    #
    print('finished')
