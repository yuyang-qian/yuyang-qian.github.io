# /usr/bin/env python
# -*- coding: utf-8 -*-
import copy
from collections import OrderedDict, defaultdict

import math
import numpy as np
import torch
from prettytable import PrettyTable

from StreamingWaveletPkg.StreamingWavelet import StreamingWavelet, StreamingWaveletCDJV
from model.ONS import ONS
from online.models.meta import Hedge
from online.models.ogd import Base, CustomOGD, OptOGD
from online.utils.lr import SelfTuningLr, OptSelfTuningLr
from online.utils.schedule import DiscretizedSSP, Schedule
from utils.tools import Timer

from online.utils.loss_function import SquareLoss, LogisticLoss
from online.utils.domain import Ball, Simplex


def soft_threshold(x, threshold):
    return max(0, x - threshold)


class WaveletRestartModule():
    def __init__(self, dim, max_length, order, get_coeff=False):
        # self.wavelet = StreamingWavelet(dim=dim, max_length=max_length, order=order, get_coeff=get_coeff)
        self.wavelet = StreamingWaveletCDJV(dim=dim, max_length=max_length, order=order, get_coeff=get_coeff)
    
    def update(self, signal):
        self.wavelet.add_signal(signal)
    
    def is_restart_now(self, threshold):
        if soft_threshold(self.wavelet.get_norm(), threshold / 10.0) >= threshold:
            # if self.wavelet.get_norm() >= threshold:
            self.wavelet.reinit()
            return True
        else:
            return False


class WaveletRestart(Base):
    def __init__(self, cfgs=None, seed=None, **alg_kwargs):
        super(WaveletRestart, self).__init__(cfgs=cfgs, seed=seed, **alg_kwargs)
        if cfgs is None:
            cfgs = {}
        self.cfgs = cfgs
        
        self.T = cfgs['T']
        self.order = cfgs['order']
        R = cfgs['R']
        S = cfgs['S']
        self.dim = alg_kwargs['cls_num']
        if alg_kwargs['learner_for_mu'] == 'ONS':
            domain = eval(cfgs['domain'])(self.dim, cfgs['R'])
            eta_meta = 1 / 2
            coff_meta_prob = cfgs['coff_meta_prob']
            coff_output = cfgs['coff_output']
            weights_tranc = cfgs['weights_tranc']
            ignore_num = cfgs['ignore_num']
            if_warm_restart = cfgs['if_warm_restart']
            coff_eta_base = cfgs['coff_eta_base']
            eta_base = coff_eta_base * (1 + np.exp(R * S))
            epsilon_base = cfgs['epsilon']
            alg_kwargs['eta_base'] = eta_base
            alg_kwargs['epsilon_base'] = epsilon_base
            alg_kwargs['if_warm_restart'] = if_warm_restart
        elif alg_kwargs['learner_for_mu'] == 'OGD':
            # alg_kwargs['lr_init'] = cfgs['lr_init']
            self.projection = cfgs['projection']
        N = int(np.ceil(np.log2(self.T))) + 1
        self.sigma_min = cfgs['sigma_min']
        cfgs['N'] = N
        alg_kwargs['dim'] = self.dim
        self.alg_kwargs = alg_kwargs
        
        self.combine = cfgs.get('combine', 'weight')
        
        print('ALL KWARGS:', self.alg_kwargs, self.cfgs)
        
        # initialize ONS as the Base Learner
        self.learner_for_mu = self.learner_for_mu_setup()  # use this model to estimate weights (ONS or OGD)
        self.init_learner_for_mu = copy.deepcopy((self.learner_for_mu))
        self.restart_schedule = self.restart_schedule_setup()
        
        self.initial_classifier = self.alg_kwargs['model']  # store the initial model
        
        self.loss_vector = torch.zeros(1)
        
        self._t = 0
        self._interval_len = 0
        # self.combine = cfgs.get('combine', 'weight')
        self.print = cfgs.get('pretty_print', False)
    
    def restart(self):
        self._interval_len = 0
        # self.learner_for_mu = self.learner_for_mu_setup()
        if self.alg_kwargs['learner_for_mu'] == 'ONS':
            self.learner_for_mu = self.learner_for_mu_setup()
        elif self.alg_kwargs['learner_for_mu'] == 'OGD':
            self.learner_for_mu.bases[0].model = copy.deepcopy(self.init_learner_for_mu.bases[0].model)
    
    def learner_for_mu_setup(self):
        # Initialize ONS base learner
        if self.alg_kwargs['learner_for_mu'] == 'ONS':
            learner = ONS(cfgs=self.cfgs, seed=self.cfgs['seed'], **self.alg_kwargs)  # ONS or OGD
            learner.set_model(np.zeros(self.dim))
            return learner
        elif self.alg_kwargs['learner_for_mu'] == 'OGD':
            ssp = [self.alg_kwargs['lr_init']]  # only init one learner
            print('ssp:', ssp)
            self.ssp = ssp
            _schedule = self.expert_steup(ssp, **self.alg_kwargs)  # pool of base learners
            return _schedule
            # self._meta = self.meta_setup(ssp, self.cfgs)
        else:
            raise NotImplementedError
    
    def expert_steup(self, ssp, **alg_kwargs):
        return Schedule(ssp, CustomOGD,
                        ['model'],
                        use_optimism=False,
                        thread=self.cfgs.get('thread', 0),
                        **alg_kwargs)
    
    def restart_schedule_setup(self):
        RestartModule = WaveletRestartModule(dim=self.dim, max_length=self.T, order=self.order, get_coeff=False)
        return RestartModule
    
    @torch.no_grad()
    def predict(self, data):
        if self.alg_kwargs['learner_for_mu'] == 'ONS':
            # Reweighting to get the final output
            output = self.initial_classifier(data)
            
            # self.dummy_feature = torch.ones_like(data[:, 0:self.dim])
            self.dummy_feature = torch.ones_like(data[:, 0:self.dim]) * torch.arange(1, self.dim + 1).float() ** (torch.arange(0, self.dim).float() * 0.1)
            self.learner_for_mu.set_feature(self.dummy_feature)
            _, estimated_mu = self.learner_for_mu.predict(self.dummy_feature)
            
            output = output * estimated_mu
            self.pretty_print(estimated_mu, '\hat{mu} by ONS')
            pred = output.argmax(-1)
        elif self.alg_kwargs['learner_for_mu'] == 'OGD':
            # OGD Update to get the final output
            output = self.learner_for_mu.bases[0].model(data)
            pred = output.argmax(-1)
        else:
            raise NotImplementedError
        return pred
    
    def set_func(self, func):
        super().set_func(func)
        self.learner_for_mu.set_func(func)
    
    def opt(self, prior_estimate, target_data):  # update \hat{mu} of the base_learner (ONS)
        self._t += 1
        self._interval_len += 1
        
        # optimization
        # self._meta.update_lr()
        # self._meta.opt(self.loss_vector)  # Meta
        # self.learner_for_mu.update_lr()
        # self.learner_for_mu.opt(self.loss_vector)
        
        if self.alg_kwargs['learner_for_mu'] == 'ONS':
            loss, grad = 0., 0.
            func = LogisticLoss(self.dummy_feature, prior_estimate).func
            self.learner_for_mu.set_feature(self.dummy_feature)
            self.learner_for_mu.set_label(prior_estimate)
            self.learner_for_mu.set_func(func)
            _, _loss, _grad = self.learner_for_mu.opt()
            loss += _loss
            grad += _grad
        elif self.alg_kwargs['learner_for_mu'] == 'OGD':
            loss_vector = torch.zeros(len(self.learner_for_mu))
            self.learner_for_mu.bases[0].lr = self.alg_kwargs['lr_init'] / (np.sqrt(self._interval_len)) / 2.0 + self.alg_kwargs['lr_init'] / 2.0
            for batch_idx, (data, target) in enumerate(self.cache):
                loss_vector += self.learner_for_mu.opt(data, target, target_data)
            
            self.loss_vector = loss_vector / len(self.dataloader)
        
        self.restart_schedule.update(prior_estimate.cpu().detach().numpy().reshape(-1))
        # Restart Condition: 2-norm of wavelet efficients exceeds threshold
        if self.restart_schedule.is_restart_now(threshold=1 / self.sigma_min * self.order):
            self.restart()
            print('Restart at t = {}'.format(self._t))
    
    def eval(self):
        estimate_loss, underlying_loss = 0, 0
        
        # for batch_idx, (data, target) in enumerate(self.cache):
        #     output = self.model(data)
        #     info = self.criterion(output.float(), target)
        #     estimate_loss += info['estimate'].item()
        #     if info['underlying'] is None:
        #         underlying_loss = None
        #     else:
        #         underlying_loss += info['underlying'].item()
        #
        # estimate_loss /= len(self.dataloader)
        # if underlying_loss is not None:
        #     underlying_loss /= len(self.dataloader)
        
        return estimate_loss, underlying_loss
    
    def forward(self, target_data, prior_estimate, t):
        
        # evaluate (re-weighting f_0)
        # self.load_model()
        pred = self.predict(target_data)
        estimate_loss, underlying_loss = self.eval()
        
        # update the mu
        self.opt(prior_estimate, target_data)
        
        return pred, estimate_loss, underlying_loss
    
    def pretty_print(self, values, name):
        if self.print:
            table = PrettyTable()
            values = values.cpu().detach().numpy()
            values = ['{:.2f}'.format(v) for v in values]
            
            table.add_row(['Val'] + values)
            print('>>>{}'.format(name))
            print(table)
