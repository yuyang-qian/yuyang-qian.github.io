from torch import nn, optim
import torch


class LinearModelwithProjection(nn.Module):
	'''
	Single Model in our OMD Ensemble Algorithm.
	:param w: d
	:param x: m * d
	:param y: m
	:param D: Diameter
	'''
	
	def __init__(self, feat_num, D, classes=1):
		super(LinearModelwithProjection, self).__init__()
		self.linear = nn.Linear(feat_num, classes, bias=False)
		self.D = D
	
	def forward(self, x, alpha=1.0, out='C'):
		x = self.linear(x)
		if out == 'C':
			return x, None
		if out == 'feat':
			return x
	
	def project(self):
		# if torch.norm(self.linear.weight) > self.D:
		self.linear.weight = torch.nn.Parameter(self.linear.weight / torch.norm(self.linear.weight) * self.D)


if __name__ == '__main__':
	model = LinearModelwithProjection(feat_num=8, D=1)
	
	X = torch.randn(128, 8)
	y = torch.randn(128)
	
	optimizer = optim.SGD(model.parameters(), lr=1e-5)

	for i in range(1000):
		optimizer.zero_grad()
		loss = torch.nn.MSELoss()
		
		# Received Old Gradients (xl, yl):
		# batch_size = x_received.size(0)
		class_output, _ = model(X)
		err_received_label = loss(class_output, y)
		
		loss = err_received_label
		print(loss.detach().item())
		loss.backward()
		from IPython import embed
		embed()
		optimizer.step()
		model.project()
