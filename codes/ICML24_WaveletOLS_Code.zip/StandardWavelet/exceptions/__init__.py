from StandardWavelet.exceptions.custom import *
