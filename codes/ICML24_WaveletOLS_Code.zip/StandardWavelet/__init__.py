from StandardWavelet.fast_transform import FastWaveletTransform
from StandardWavelet.transforms.wavelet_transform import WaveletTransform
from StandardWavelet.util import *
from StandardWavelet.wavelets import getAllWavelets
from StandardWavelet.compression import *
