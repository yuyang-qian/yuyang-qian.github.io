# /usr/bin/env python
# -*- coding: utf-8 -*-
import copy
import json as js
import logging
import os
import time
from os.path import join
import random

import torch

import warnings

warnings.filterwarnings("ignore", category=UserWarning)

os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
os.environ['CUDA_VISIBLE_DEVICES'] = '7'
from torch.utils.data import Subset, ConcatDataset
import numpy as np
import torch.utils.data as data
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm

from dataset.wrapper import get_dataset
from model.wrapper import get_cls_model
from online.models.wrapper import get_model
from online.utils.bbse import BBSE
from online.utils.risk import *
from utils.argparser import argparser

from utils.tools import Timer
from utils.MPE.mpe import online_mpe_estimate

logging.getLogger("pytorch_lightning").setLevel(logging.WARNING)


def write(writer, info, t):
    for k, v in info.items():
        writer.add_scalar(k, v, t)


def set_cpu_num(cpu_num=8):
    os.environ['OMP_NUM_THREADS'] = str(cpu_num)
    os.environ['OPENBLAS_NUM_THREADS'] = str(cpu_num)
    os.environ['MKL_NUM_THREADS'] = str(cpu_num)
    os.environ['VECLIB_MAXIMUM_THREADS'] = str(cpu_num)
    os.environ['NUMEXPR_NUM_THREADS'] = str(cpu_num)
    torch.set_num_threads(cpu_num)
    torch.set_num_interop_threads(cpu_num)


def sample_dataset(data, labels, prior_estimate, N):
    num_samples = data.shape[0]
    num_classes = len(prior_estimate)
    prior_estimate = torch.maximum(prior_estimate, torch.ones_like(prior_estimate) * 1e-1)
    prior_estimate = torch.softmax(prior_estimate, dim=0)
    class_probabilities = prior_estimate.unsqueeze(0).expand(num_samples, -1)
    
    sampled_indices = torch.multinomial(class_probabilities, 1).squeeze()
    # sampled_indices = [i for i in range(len(sampled_indices)) if labels[i] == sampled_indices[i]]
    sampled_indices = torch.tensor(sampled_indices == torch.from_numpy(labels)).detach().nonzero(as_tuple=True)[0]
    sampled_indices = torch.tensor(sampled_indices).detach()
    perm = torch.randperm(sampled_indices.size(0))
    selected_samples = sampled_indices[perm[:N]]
    
    return selected_samples


from sklearn.metrics import f1_score


def compute_f1_multi(y_true, y_pred):
    # y_pred = torch.argmax(y_pred, dim=1)  # get the class with the highest probability
    y_pred = y_pred.detach().cpu().numpy()
    y_true = y_true.cpu().numpy()
    
    return f1_score(y_true, y_pred, average='macro')  # 'macro' will take the mean of F1 Score from each class


def accuracy_top3(output, target, topk=(1, 2, 3)):
    """Computes the accuracy over the k top predictions for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)
        
        _, pred = output.topk(maxk, 1, True, True)
        # pred = pred.t()
        correct = pred.eq(target.view(-1, 1).expand_as(pred))
        
        res = []
        for k in topk:
            correct_k = correct[:k].view(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
        return res


def run(T, train_set, test_set, estimator, online_alg, cfgs, info, device='cuda', writer=None):
    # procedure:
    # 1. estimate prior;
    # 2. get prior by BBSE;
    # 3. get prediction;
    # 4. get loss to update model
    
    record = []
    cumulative_estimate_loss, cumulative_underlying_loss, error_cnt = 0, 0, 0
    
    loss_cfgs = cfgs['Online']['kwargs'].get('loss', {})
    loss_name = loss_cfgs.get('name', 'RewritingRisk')
    nn_loss = loss_cfgs.get('nn_loss', False) or \
              cfgs['Online']['kwargs'].get('nn_loss', False)
    loss_func = eval(loss_name)(device=device, nn_loss=nn_loss, cfgs=cfgs)
    print('Loss {}, Use nn: {}'.format(loss_name, nn_loss))
    
    time_helper = Timer()
    time_helper.tik()
    f1_list = []
    top_3_list = []
    tot_new_class_num = 0
    tot_sample_num = 0
    tot_estimate_class_prior = 0.0
    for t in tqdm(range(T)):
        
        target_data, target_label, target_label_masks = test_set[t]
        
        # PvU_dataset = Subset(test_set, list(range(t, t + test_set.interval)))
        # PvU_dataset.dataset.pvu = True
        # PvU_dataset = ConcatDataset([train_set, PvU_dataset])
        
        target_data = target_data.to(device)
        sample_num = target_data.shape[0]
        if sample_num == 0: continue
        prior_estimate = estimator.estimate(target_data).to(device)  # \tilde{mu} estimated by BBSE
        
        # use resampled train_set instead of full of train_set (resample according to prior_estimate)
        sampled_idx = sample_dataset(train_set.data, train_set.labels, prior_estimate, len(target_data))
        PvU_dataset = copy.deepcopy(train_set)
        PvU_dataset.data = torch.cat([PvU_dataset.data[sampled_idx], target_data], dim=0)
        PvU_dataset.labels = torch.cat([torch.tensor(PvU_dataset.labels)[sampled_idx], torch.tensor(target_label)], dim=0)
        PvU_dataset.label_mask = torch.cat([torch.tensor(PvU_dataset.label_mask)[sampled_idx], torch.tensor(target_label_masks)], dim=0)
        
        loss_func.set_priors(prior_estimate, target_label_masks)
        online_alg.set_func(loss_func)
        
        result = online_alg.forward(target_data, prior_estimate, PvU_dataset, t)
        # output = None
        if len(result) == 3:
            pred, estimate_loss, underlying_loss = result
            loss_info = None
        else:
            pred, estimate_loss, underlying_loss, new_class_prior = result
        
        ori_pred = None
        if isinstance(pred, dict):
            ori_pred = pred['Ori']
            pred = pred['Opt']
        
        new_class = cfgs['Data']['kwargs']['online_data']['cfg'].get('new_class')
        target_label = target_label.to(pred.device)
        if cfgs['Online']['algorithm'] in ['ATLAS', 'FIX', 'FTH', 'FTWH']:
            for c in new_class:
                target_label[target_label == c] = -1
        
        _error_cnt = (pred.view_as(target_label) != target_label).sum().item()
        error_cnt += _error_cnt
        
        tot_sample_num += sample_num
        tot_new_class_num += torch.isin(target_label.detach().cpu(), torch.tensor(new_class)).sum().item()
        mpe_true = tot_new_class_num / tot_sample_num
        tot_estimate_class_prior = new_class_prior * sample_num / tot_sample_num + tot_estimate_class_prior * (
            1 - sample_num / tot_sample_num)
        
        avg_error = error_cnt / ((t + 1) * sample_num)
        
        f1 = compute_f1_multi(target_label, pred)
        f1_list.append(f1)
        
        # top_3_list.append(accuracy_top3(output.detach(), target_label.detach().reshape(-1, 1)))
        
        cumulative_estimate_loss += estimate_loss
        
        if underlying_loss is not None:
            cumulative_underlying_loss += underlying_loss
        if writer is not None:
            res_info = {
                'Estimate/1-Estimate Loss'     : estimate_loss,
                'Estimate/2-Cumulative Loss'   : cumulative_estimate_loss,
                'Estimate/3-Prior[0]'          : prior_estimate[0],
                'Underlying/3-Avg Error'       : avg_error,
                'Underlying/4-Cumulative Error': error_cnt,
                'MPE/True'                     : mpe_true,
                'MPE/Estimated'                : tot_estimate_class_prior,
            }
            # if underlying_loss is not None and target_label_masks is not None:
            #     res_info.update({
            #         'Underlying/1-Underlying Loss': underlying_loss,
            #         'Underlying/2-Cumulative Loss': cumulative_underlying_loss,
            #         'Underlying/5-Prior[0]'       : target_label_masks[0],
            #     })
            
            write(writer, res_info, t)
            for k, v in res_info.items():
                res_info[k] = v.item() if isinstance(v, torch.Tensor) else v
            record.append(res_info)
        
        if t % cfgs.get('log_interval', 100) == 0:
            print('estimated_new_class_prior:', tot_estimate_class_prior, 'real_new_class_prior:', mpe_true)
            time_helper.tok('{} rounds'.format(t))
            print(
                '\n[Time {}] Estimate Loss: {}, F1 Score: {}, Avg Error: {}'.format(t, estimate_loss,
                                                                                    np.average(np.array(f1_list)),
                                                                                    avg_error))
    return record


def stepsize(cfgs, sigma_min, K):
    alg = cfgs['algorithm']
    cfgs = cfgs['kwargs']
    D = float(cfgs['D'])
    G = float(cfgs['G'])
    T = cfgs['T']
    
    print('D: {}, G: {}, T:{}'.format(D, G, T))
    print('K: {}, Sigma: {}'.format(K, sigma_min))
    
    if alg == 'ATLASADA':
        min_step = (D * sigma_min) / (2 * G * ((K * T) ** 0.5))
        max_step = D * ((1 + 2 * T) ** 0.5)
    else:
        min_step, max_step = D / (G * (T ** 0.5)), D / G
    
    max_step_clip = cfgs.get('max_step_clip', max_step)
    max_step = min(max_step, max_step_clip)
    
    return min_step, max_step


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


if __name__ == "__main__":
    cfgs = argparser()
    print(cfgs)
    
    device = cfgs.get('device', 'cpu')
    cpu_num = cfgs.get('cpu_num', 8)
    set_cpu_num(cpu_num)
    setup_seed(cfgs['random_seed'])
    rng = np.random.default_rng(cfgs['random_seed'])
    
    train_set, test_set, info = get_dataset(
        name=cfgs['Data']['name'],
        cfgs=cfgs['Data']['kwargs'],
        rng=rng
    )
    
    # BBSE estimation
    bbox, _ = get_cls_model(cfgs, info, device)
    
    source_loader = data.DataLoader(train_set,
                                    batch_size=cfgs['BlackBox']['source_batch_size'],
                                    shuffle=True,
                                    pin_memory=False)
    
    estimator = BBSE(bbox=bbox,
                     source_loader=source_loader,
                     cls_num=info['cls_num'],
                     device=device,
                     kwargs=cfgs['BlackBox'].get("kwargs", {}),
                     )
    sigma_min = estimator.get_sigma_min()
    cfgs['Online']['kwargs']['sigma_min'] = sigma_min
    min_step, max_step = stepsize(cfgs['Online'],
                                  sigma_min,
                                  info['cls_num'])
    
    model, init = get_cls_model(cfgs, info, device)
    online_alg = get_model(cfgs, cfgs['Online'], min_step, max_step, model, train_set, device, init, rng, info)
    
    writer = None
    if cfgs['Online'].get('write', True):
        writer = SummaryWriter(join(cfgs['output'],
                                    'runs_{}'.format(time.strftime("%a_%b_%d_%H:%M:%S",
                                                                   time.localtime()))))
    record = run(cfgs['round'], train_set, test_set, estimator, online_alg, cfgs, info, device=device, writer=writer)
    
    with open(join(cfgs["output"], 'result.json'), 'w') as fw:
        js.dump(record, fw, indent=4)
