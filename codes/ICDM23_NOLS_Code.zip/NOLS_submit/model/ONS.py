# /usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
import torch

from scipy import optimize
from scipy.optimize import NonlinearConstraint

from online.utils.domain import Ball, Simplex


class Base(object):
    def __init__(self, cfgs=None, seed=None, **alg_kwargs):
        self.cfgs = cfgs
        self._seed = seed
        self.alg_kwargs = alg_kwargs
        
        self._domain = domain = eval(cfgs['domain'])(alg_kwargs['dim'], cfgs['R'])
        self._func = None
        self._grad = None
        self._x = domain.x_init(seed)
        
        self._feature = None
        self._label = None
    
    def set_func(self, func):
        self._func = func
    
    def get_model(self):
        return self._x
    
    def set_model(self, a):
        self._x = a
    
    def clear(self):
        self._func = None
        self._grad = None
    
    def set_feature(self, feature):
        self._feature = feature.numpy()
    
    def set_label(self, y):
        self._label = y.numpy()
    
    def cal_logist_grad(self):
        # grad = -1 * self._label * self._feature / (1 + np.exp(self._label * np.dot(self._x, self._feature)))
        
        # grad = -1 * self._label * self._feature \
        #        / (1.0 + torch.exp(torch.from_numpy(self._label)
        #                           * torch.from_numpy(self._x)
        #                           * torch.from_numpy(self._feature))).numpy()
        
        bs = self._feature.shape[0]
        grad = -1 * self._label.reshape(1, -1).repeat(bs, axis=0) * self._feature / \
               (1 + np.exp(self._label.reshape(1, -1).repeat(bs, axis=0) * self._x.reshape(1, -1).repeat(bs, axis=0) * self._feature))
        grad = np.sum(grad, axis=0)
        return grad
    
    def cal_KL_grad(self):
        return NotImplementedError
    
    def reinit(self):
        self.__init__(self._domain, self._seed, **self.alg_kwargs)
    
    def opt(self):
        pass


class ONS(Base):
    def __init__(self, cfgs=None, seed=None, **algo_kwargs):
        super(ONS, self).__init__(cfgs=cfgs, seed=seed, **algo_kwargs)
        self._r = self._domain.get_r()
        self._square_r = self._r ** 2
        self._gamma = algo_kwargs['eta_base']
        self._eps = algo_kwargs['epsilon_base']
        self._d = self._domain.get_dimension()
        self._A_t = self._eps * np.eye(self._d)
        self._y = -1
        self._feature = np.zeros(self._d)
        self.grad = np.zeros((self._d, self._d))
    
    def get_dim(self):
        return self._d
    
    def get_grad(self):
        return self.grad
    
    def set_model(self, a):
        self._x = a
        self._A_t = self._eps * np.eye(self._d)
        self._inv_A_t = np.eye(self._d) / self._eps
    
    def opt(self):
        x = self._x.copy()
        loss = self._func(self._x)
        # TODO: finish the code of cal_KL_grad
        # gradient = self.cal_KL_grad()
        gradient = self.cal_logist_grad()
        self.grad = gradient
        tmp = np.outer(gradient, gradient)
        # tmp = gradient.T @ gradient
        self._A_t += tmp
        self._inv_A_t -= np.dot(np.dot(self._inv_A_t, tmp), self._inv_A_t) / (1 + np.dot(np.dot(gradient, self._inv_A_t), gradient))
        # self._inv_A_t -= (torch.from_numpy(self._inv_A_t)
        #                   * torch.from_numpy(tmp)
        #                   * torch.from_numpy(self._inv_A_t)).numpy() / \
        #                  (1.0 + tmp * self._inv_A_t)
        y = x - self._gamma * self._inv_A_t.dot(gradient)
        self._x = self.proj(y)
        self.clear()
        return x, loss, gradient
    
    def proj(self, y):
        obj_fun = lambda x: 1 / 2 * (x - y).dot(self._A_t).dot(x - y)
        jac_obj_fun = lambda x: self._A_t.dot(x - y)
        x_init = self.get_model()  # use last round point as start point
        nlc = NonlinearConstraint(lambda x: np.dot(x, x), -np.inf, self._square_r, jac=lambda x: 2 * x)
        result = optimize.minimize(obj_fun, x_init, jac=jac_obj_fun, method='SLSQP', constraints=[nlc])
        if not result.success:
            print("Fail, use last round decision instead!")
            return self.get_model()
        else:
            return np.array(result.x)
    
    def reinit(self):
        self.__init__(self.cfgs, self._seed, **self.alg_kwargs)
    
    # def sigmoid(self, z):
    #     return 1.0 / (1.0 + np.exp(-z))
    
    def softmax(self, x):
        x -= np.max(x)
        x = np.exp(x) / np.sum(np.exp(x))
        return x
    
    def predict_proba(self, row):
        # z = np.dot(row, self._x)
        z = row * self._x
        return self.softmax(z)
    
    def predict(self, X):
        if not isinstance(X, np.ndarray):
            X = X.cpu().detach().numpy()
        self.predict_probas = []
        for i in range(len(X)):
            ypred = self.predict_proba(X[i, :])
            self.predict_probas.append(ypred)
        self.cutoff = 0.5
        
        return self.predict_probas, (np.array(self.predict_probas)) * 1.0
