# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : resnet.py
############################

from torch import nn
from torchvision.models import resnet34
from collections import OrderedDict


def remove_fc(model):
    new_model_dict = OrderedDict()
    for name, module in model.named_children():
        if name == 'fc':
            break
        new_model_dict[name] = module
    
    new_model = nn.Sequential(new_model_dict)
    
    return new_model


class ResModel(nn.Module):
    def __init__(self, **kwargs):
        super(ResModel, self).__init__()
        num_cls = kwargs['num_classes']
        del kwargs['num_classes']
        
        pretrained = resnet34(**kwargs)
        self.backbone = remove_fc(pretrained)
        
        last_layer = list(pretrained.children())[-1]
        self.classifier = nn.Linear(last_layer.in_features, num_cls, bias=True)
        nn.init.normal_(self.classifier.weight, 0, 0.01)
        nn.init.constant_(self.classifier.bias, 0)
    
    def forward(self, x):
        features = self.backbone(x).flatten(1)
        out = self.classifier(features)
        
        return out, features


class Linear(nn.Module):
    def __init__(self, **kwargs):
        super(Linear, self).__init__()
        input_dim = kwargs['dim']
        num_cls = kwargs['num_classes']
        self.linear = nn.Linear(input_dim, num_cls, bias=True)
    
    def forward(self, x):
        # out = x.view(-1, self.num_flat_features(x))
        out = self.linear(x)
        return out, x
