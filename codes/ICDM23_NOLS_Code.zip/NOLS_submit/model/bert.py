# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : bert.py
############################

from transformers import DistilBertForSequenceClassification
import torch.nn as nn


class BertModel(nn.Module):
    def __init__(self, **kwargs):
        super(BertModel, self).__init__()
        self.pretrain_model = DistilBertForSequenceClassification.\
            from_pretrained("distilbert-base-uncased", num_labels=kwargs['num_classes'])
        self.num_classes = kwargs['num_classes']

        self.pre_classifier = nn.Sequential(
            nn.Linear(768, 2 * kwargs['dim']),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(2 * kwargs['dim'], kwargs['dim']),
            nn.ReLU()
        )

        self.classifier = nn.Linear(kwargs['dim'], kwargs['num_classes'], bias=False)

    def forward(self, x):
        input_ids = x[:, :, 0]
        attention_mask = x[:, :, 1]

        distilbert_output = self.pretrain_model.distilbert(input_ids=input_ids,
                                            attention_mask=attention_mask)
        hidden_state = distilbert_output[0]
        pooled_output = hidden_state[:, 0]
        # pooled_output = self.pretrain_model.pre_classifier(pooled_output)
        # features = nn.ReLU()(pooled_output)
        # features_drop = self.pretrain_model.dropout(features)
        # out = self.pretrain_model.classifier(features_drop)

        features = self.pre_classifier(pooled_output)
        out = self.classifier(features)
        return out, features
