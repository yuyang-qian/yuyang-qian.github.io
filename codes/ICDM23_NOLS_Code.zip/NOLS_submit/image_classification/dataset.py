# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : dataset.py
############################

# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : data.py
############################

import torchvision.transforms as transforms
import torch.utils.data as data
from PIL import Image
import torch
from os.path import join
from sklearn.model_selection import train_test_split


def preprocess(cfg):
    print('==> Preparing data..')
    transform_train, transform_test = [], []
    
    if cfg.get('RandomResizedCrop', False):
        transform_train.append(transforms.RandomResizedCrop(cfg['crop']))
    if cfg.get('ColorJitter', False):
        transform_train.append(transforms.ColorJitter(**cfg['kwargs']['ColorJitter']))
    if cfg.get('RandomFlip', False):
        transform_train += [
            transforms.RandomHorizontalFlip(),
            transforms.RandomHorizontalFlip(),
        ]
    if cfg.get("RandomEqualize", False):
        transform_train += [
            transforms.RandomEqualize()
        ]
    if cfg.get('gray', False):
        transform_train.append(transforms.Grayscale())
    transform_train += [
        transforms.Resize(cfg['crop']),
        transforms.CenterCrop(cfg['crop']),
        transforms.ToTensor(),
    ]
    if 'normalize' in cfg:
        transform_train.append(transforms.Normalize(*cfg['normalize']))
    transform_train = transforms.Compose(transform_train)
    
    if cfg.get('gray', False):
        transform_test.append(transforms.Grayscale())
    transform_test += [
        transforms.Resize(cfg['crop']),
        transforms.CenterCrop(cfg['crop']),
        transforms.ToTensor(),
    ]
    if 'normalize' in cfg:
        transform_test.append(transforms.Normalize(*cfg['normalize']))
    transform_test = transforms.Compose(transform_test)
    
    return transform_train, transform_test


class PNDatasetloader(data.Dataset):
    def __init__(self, images, labels, transform=None):
        self.transform = transform
        self.imgs = images
        self.labels = labels
    
    def __getitem__(self, index):
        label = self.labels[index]
        fn = self.imgs[index]
        img = Image.open(fn).convert('RGB')
        # print(img)
        if self.transform is not None:
            img = self.transform(img)
        return img, label
    
    def __len__(self):
        return len(self.imgs)


class Dataset(object):
    def __init__(self, cfg, type='train'):
        self.root_path = join(cfg['path'], cfg['name'])
        self.name = cfg['name']
        
        # if self.name not in ['MNIST', 'CIFAR10', 'SVHN']:
        #     raise ValueError('Dataset must be selected within MNIST, CIFAR10 or SVHN.')
        self.transform_train, self.transform_test = preprocess(cfg['preprocess'])
        
        self.kwargs = {'num_workers': cfg['num_workers'],
                       'pin_memory' : cfg['pin_memory']} \
            if torch.cuda.is_available() else {}
        self.cfg = cfg
        self.root_path = join(self.cfg['path'], self.cfg['name'])
        
        if type == 'train':
            txt_path = join(self.root_path, self.cfg['file_name'])
            imgs, labels = self.load_data(txt_path)
            self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
                imgs, labels,
                test_size=0.2, random_state=1214,
                stratify=labels
            )
        else:
            train_txt_path = join(self.root_path,
                                  self.cfg['train']['file_name'])
            test_txt_path = join(self.root_path,
                                 self.cfg['test']['file_name'])
            self.X_train, self.y_train = self.load_data(train_txt_path)
            self.X_test, self.y_test = self.load_data(test_txt_path)
    
    def load_data(self, txt_path):
        fh = open(txt_path, 'r')
        
        imgs = []
        labels = []
        
        for line in fh:
            line = line.rstrip()
            words = line.split()
            image_path = join(self.root_path, words[0])
            real_label = int(words[1])
            imgs.append(image_path)
            labels.append(real_label)
        
        return imgs, labels
    
    def train_data(self):
        train_set = PNDatasetloader(self.X_train, self.y_train, transform=self.transform_train)
        train_loader = torch.utils.data.DataLoader(dataset=train_set,
                                                   batch_size=self.cfg['train']['batch_size'],
                                                   shuffle=True,
                                                   **self.kwargs)
        
        return train_loader, len(train_set)
    
    def test_data(self):
        test_set = PNDatasetloader(self.X_test, self.y_test, transform=self.transform_test)
        test_loader = torch.utils.data.DataLoader(dataset=test_set,
                                                  batch_size=self.cfg['test']['batch_size'],
                                                  shuffle=True,
                                                  **self.kwargs)
        
        return test_loader, len(test_set)
