# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : classifier.py
############################
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
from os.path import join
import numpy as np
import argparse
import yaml
import time
import random

import torch
from torch.utils.tensorboard import SummaryWriter
from torch.optim import Adam
import torch.nn as nn

from model import resnet, ResModel
from dataset import Dataset


def train(cfg, model, device, train_loader, optimizer, epoch, writer, loss_fct):
    model.train()
    tr_loss = 0
    length = len(train_loader)
    
    for batch_idx, (data, targets) in enumerate(train_loader):
        data, targets = data.to(device), targets.to(device)
        
        optimizer.zero_grad()
        output, features = model(data)  # output, {-1, 1}
        
        loss = loss_fct(output, targets)
        
        tr_loss += loss.item()
        loss.backward()
        optimizer.step()
        
        pred = output.argmax(-1)
        
        _correct = pred.eq(targets.view_as(pred))
        correct = _correct.sum().item()
        
        acc = correct / len(data)
        iter_num = (epoch - 1) * length + batch_idx
        writer.add_scalar('Train/Acc', acc, iter_num)
        
        print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
            epoch, batch_idx * len(data), len(train_loader.dataset),
                   100. * batch_idx / len(train_loader), loss.item()))


def test(cfg, model, device, test_loader, epoch, writer, test_loss_fct):
    """Testing"""
    model.eval()
    correct = 0
    with torch.no_grad():
        for batch_idx, (data, targets) in enumerate(test_loader):
            data, targets = data.to(device), targets.to(device)
            
            output, features = model(data)
            
            pred = output.argmax(-1)
            correct += pred.eq(targets.view_as(pred)).sum().item()
    
    acc = correct / len(test_loader.dataset)
    writer.add_scalar('Test/Acc', acc, epoch)
    
    print('\nTest set: Accuracy: {}/{} ({:.0f}%)'.format(
        correct, len(test_loader.dataset),
        100. * correct / len(test_loader.dataset)))
    
    return acc


def seed_everything(seed=2021):
    os.environ['PYTHONHASHSEED'] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    # some cudnn methods can be random even after fixing the seed
    # unless you tell it to be deterministic
    torch.backends.cudnn.deterministic = True


def main():
    parser = argparse.ArgumentParser()
    # mode
    parser.add_argument("--expr_space",
                        type=str,
                        help='the path of the experiment')
    args = parser.parse_args()
    
    cfg_path = join(args.expr_space, 'config.yaml')
    with open(cfg_path) as f:
        cfg = yaml.load(f, Loader=yaml.Loader)
    cfg['output'] = join(args.expr_space, 'output')
    
    seed_everything()
    
    data_helper = Dataset(cfg['data'])
    test_loader, num_te = data_helper.test_data()
    train_loader, num_tr_sample = data_helper.train_data()
    
    print('Train num: {}, test num: {}'.format(num_tr_sample, num_te))
    
    # model
    device = torch.device('cuda')
    # model = resnet(**cfg['model'].get('kwargs', {})).to(device)
    model = ResModel(**cfg['model'].get('kwargs', {})).to(device)
    
    optimizer = Adam(model.parameters(),
                     lr=float(cfg['train']['lr']),
                     weight_decay=float(cfg['train']['weight_decay']))
    writer = SummaryWriter(os.path.join(cfg['output'], 'runs_{}'.format(int(time.time()))))
    loss_fct = nn.CrossEntropyLoss()
    
    best_acc = 0
    for epoch in range(1, cfg['train']['epoch'] + 1):
        train(cfg, model, device, train_loader, optimizer, epoch, writer, loss_fct)
        
        if (epoch - 1) % cfg['train']['log_interval'] == 0:
            acc = test(cfg, model, device, test_loader, epoch, writer, loss_fct)
            
            if acc > best_acc:
                best_acc = acc
                torch.save(model.state_dict(), join(cfg['output'], 'model_best.bin'))
            torch.save(model.state_dict(), join(cfg['output'], 'model_latest.bin'))


if __name__ == "__main__":
    main()
