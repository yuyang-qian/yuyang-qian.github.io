# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : extract_feature.py
############################
import argparse
from collections import OrderedDict
import yaml
import torch
import torch.nn.functional as F

from tqdm import tqdm
from os.path import basename, dirname, join
from dataset import Dataset
from model import ResModel

def run(cfg, data_loader, model, device):
    _features = []
    _labels = []
    correct = 0

    cls_num = cfg['model']['kwargs']['num_classes']
    cmatrix = torch.zeros((cls_num, cls_num), device=device)
    with torch.no_grad():
        for batch_idx, (data, targets) in enumerate(tqdm(data_loader)):
            data, targets = data.to(device), targets.to(device)
            output, features = model(data)
            _features.append(features.cpu().detach())
            _labels.append(targets.cpu().detach())

            pred = output.argmax(-1)
            correct += pred.eq(targets.view_as(pred)).sum().item()

            indices = cls_num * pred + targets
            m = torch.bincount(indices, minlength=cls_num ** 2)
            cmatrix += m.reshape(cmatrix.shape)

    cmatrix_joint = F.normalize(cmatrix.float().view(-1),
                                p=1, dim=0).reshape(cls_num, cls_num)
    u, s, v = torch.svd(cmatrix_joint)
    print("\nMinimum Singular Value: {}".format(s.min().item()))

    print('\nAccuracy: {}/{} ({:.0f}%)'.format(
        correct, len(data_loader.dataset),
        100. * correct / len(data_loader.dataset)))

    features = torch.cat(_features, 0)
    labels = torch.cat(_labels, 0)

    return features, labels


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--cfg_path", type=str)
    parser.add_argument("--output_path", type=str)
    args = parser.parse_args()

    with open(args.cfg_path) as f:
        cfg = yaml.load(f, Loader=yaml.Loader)

    data_helper = Dataset(cfg['data'], type='test')
    test_loader, num_te = data_helper.test_data()
    train_loader, num_train = data_helper.train_data()
    device = 'cuda'
    model = ResModel(**cfg['model'].get('kwargs', {})).to(device)

    model.eval()

    print(">>> Training data")
    train_features, train_labels = run(cfg, train_loader, model, device)
    print(">>> Testing data")
    test_features, test_labels = run(cfg, test_loader, model, device)
    weights = model.model.fc.weight.data.cpu().detach()

    torch.save({
        'features': train_features,
        'labels': train_labels
    }, join(args.output_path, 'train_features.bin'))

    torch.save({
        'features': test_features,
        'labels': test_labels
    }, join(args.output_path, 'test_features.bin'))

    torch.save(OrderedDict({
        'linear.weight': weights
    }), join(args.output_path, "black_box.bin"))



