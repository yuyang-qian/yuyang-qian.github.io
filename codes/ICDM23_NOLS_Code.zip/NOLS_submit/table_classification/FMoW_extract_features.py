# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : black_box.py
############################
import sys

# sys.path.append('../')
# sys.path.append('../')
# sys.path.append('../../')
sys.path.append('../model')

from linear import Linear
from dataset.fmow_data import FMoWTrainDataset, FMoWTestDataset

import torch.utils.data as data
from torch import nn
from torch.optim import SGD, ASGD
import torch.nn.functional as F
from torch.utils.tensorboard import SummaryWriter

from utils.draw import draw_acc
from utils.seed import seed_everything

import os
import time
import random
import torch
import numpy as np
from os.path import join
from prettytable import PrettyTable

import argparse


# from dataset.toy_data import ToyTrainSet, gen_data
# from dataset.toy_data import get_toy_data
# from dataset.arxiv_dataset import get_tfidf_data, get_bert_data
# from dataset.table_data import get_table_data


def set_cpu_num(cpu_num=8):
    os.environ['OMP_NUM_THREADS'] = str(cpu_num)
    os.environ['OPENBLAS_NUM_THREADS'] = str(cpu_num)
    os.environ['MKL_NUM_THREADS'] = str(cpu_num)
    os.environ['VECLIB_MAXIMUM_THREADS'] = str(cpu_num)
    os.environ['NUMEXPR_NUM_THREADS'] = str(cpu_num)
    torch.set_num_threads(cpu_num)


def estimate_grad(model):
    G = torch.norm(model.linear.weight.grad)
    grads.append(G)
    print('G: {}'.format(G))


def train(data_loader, model, criterion, lr, device, epoch, projection, cls_num=23):
    model.train()
    correct = 0
    # optimizer = SGD(model.parameters(), lr=lr, weight_decay=0)
    optimizer = ASGD(model.parameters(), lr=lr)
    cmatrix = torch.zeros((cls_num, cls_num), device=device)
    for batch_idx, (data, target, _) in enumerate(data_loader):
        data, target = data.to(device), target.to(device)
        optimizer.zero_grad()
        
        output = model(data)
        loss = criterion(output.float(), target)
        loss.backward()
        
        estimate_grad(model)
        
        optimizer.step()
        
        pred = output.argmax(-1)
        correct += pred.eq(target.view_as(pred)).sum()
        
        indices = cls_num * pred + target
        m = torch.bincount(indices, minlength=cls_num ** 2)
        cmatrix += m.reshape(cmatrix.shape)
    
    cmatrix_joint = F.normalize(cmatrix.float().view(-1),
                                p=1, dim=0).reshape(cls_num, cls_num)
    u, s, v = torch.svd(cmatrix_joint)
    print("Minimum Singular Value: {}".format(s.min().item()))
    
    if projection:
        model.project()
    
    acc = correct / len(data_loader.dataset)
    print('[Epoch {}] Training Acc: {}'.format(epoch, acc))
    
    return acc


@torch.no_grad()
def test(data_loader, model, device, epoch):
    model.eval()
    correct = 0
    count = 0
    for batch_idx, (data, target, _) in enumerate(data_loader):
        if batch_idx > 0:
            break
        
        data, target = data.to(device), target.to(device)
        output = model(data)
        pred = output.argmax(-1)
        
        correct += pred.eq(target.view_as(pred)).sum()
        count += len(data)
    
    # acc = correct / len(data_loader.dataset)
    acc = correct / count
    # acc = correct / (count * data_loader.batch_size)
    print('[Epoch {}] Testing Acc: {}'.format(epoch, acc))
    
    return acc


def dataset_setup(rng, args, name='toy'):
    output = args.expr_path
    source_path = args.source_path
    ratio = args.ratio
    nooverlap = args.nooverlap
    toy_cfgs = {
        'output'       : output,
        'dim'          : 12, 'sigma': 0.1, 'centers': None, 'cls_num': 3,
        'source_priors': [1 / 3, 1 / 3, 1 / 3], 'dst_priors': [0, 0, 1.0],
        'train_num'    : 10000, 'test_num': 5000,
    }
    
    arxiv_tfidf_cfgs = {
        'source_data':
            {
                'path': './data/arxiv/tfidf/arxiv.npz'
            }
    }
    
    arxiv_bert_cfgs = {
        'source_data'   :
            {
                'path': source_path,
            },
        'online_data'   :
            {
                'cls_num': 3 if args.discretization else 23,
            },
        'train_ratio'   : ratio,
        'discretization': args.discretization,
    }
    if args.filter:
        arxiv_bert_cfgs['filter'] = ['cs.CV', 'cs.LG', 'cs.AI', 'cs.IT']
    
    arxiv_table_cfgs = {
        'source_data':
            {
                'path': source_path,
            },
        'train_ratio': ratio,
    }
    
    fmow_cfgs = {
        'source_data'       :
            {
                # 'path': '../online_expr/FMoW/data/FMoW_data_dict_3_5710.pkl',
                # 'path': '../online_expr/FMoW/data/FMoW_data_dict_7_20819.pkl',
                'path': '../online_expr/FMoW/data/FMoW_data_dict_5_11119.pkl',
            },
        'years_start'       : 0,
        'years_end'         : 15,
        # 'years_for_pretrain': 4,
        # 'years_for_pretrain': 7,
        'years_for_pretrain': 6,
        'years_interval'    : 5,
        'per_round_num'     : 1
    }
    
    # if name == "toy":
    #     train_set, test_set, info = get_toy_data(rng, **toy_cfgs)
    # elif name == 'arxiv_tfidf':
    #     train_set, test_set, info = get_tfidf_data(arxiv_tfidf_cfgs, bbox=True)
    # elif name == "arxiv_bert":
    #     train_set, test_set, info = get_bert_data(arxiv_bert_cfgs,
    #                                               bbox=True,
    #                                               nooverlap=nooverlap,
    #                                               )
    if name == 'FMoW':
        train_set = FMoWTrainDataset(fmow_cfgs, rng=rng)
        info = train_set.info
        print(info)
        test_set = FMoWTestDataset(fmow_cfgs, info, rng=rng)
        # elif name == "table":
        #     train_set, test_set, info = get_table_data(arxiv_table_cfgs, bbox=True)
    else:
        raise NotImplementedError
    
    return train_set, test_set, info


def run(args, lr=1e-1, R=5, projection=True):
    rng = seed_everything()
    ratio = args.ratio
    print(ratio)
    epoch = 80
    dataset_name = args.dataset_name
    # expr_path = 'expr/bbox/{}/finetune_{}/train_ratio_{}'.format(dataset_name, ratio, ratio)
    # expr_path = 'expr/bbox/{}/finetune_{}/train_ratio_{}_debug'.format(dataset_name, ratio, ratio)
    expr_path = args.expr_path
    
    batch_size = 1000
    test_batch_size = 1000
    device = 'cuda'
    # init = 'expr/bbox/bike/sklearn/black_box.bin'
    init = None
    
    writer = SummaryWriter(join(expr_path,
                                'runs_{}'.format(time.strftime("%a_%b_%d_%H:%M:%S",
                                                               time.localtime()))))
    
    os.makedirs(expr_path, exist_ok=True)
    
    train_set, test_set, info = dataset_setup(rng, args, name=dataset_name)
    
    train_loader = data.DataLoader(train_set, batch_size=batch_size, shuffle=True, pin_memory=False)
    test_loader = data.DataLoader(test_set, batch_size=test_batch_size, shuffle=True, pin_memory=False)
    
    model = Linear(input_dim=info['dim'], output_dim=info['cls_num'], R=R).to(device)
    if init is not None:
        init_model = torch.load(init, map_location=device)
        model.load_state_dict(init_model)
        train_acc = test(train_loader, model, device, 0)
    
    loss = nn.CrossEntropyLoss()
    
    train_results, test_results = [], []
    for i in range(epoch):
        train_acc = train(train_loader, model, loss, lr, device, i, projection, cls_num=info['cls_num'])
        # train_results.append(train_acc)
        writer.add_scalar('Train Acc', train_acc, i)
        if i % 10 == 0:
            test_acc = test(test_loader, model, device, i)
            writer.add_scalar('Test Acc', test_acc, i)
            # test_results.append(test_acc)
    
    torch.save(model.state_dict(), join(expr_path, 'black_box.bin'))
    # draw_acc(train_results, test_results, epoch, output=expr_path)
    
    # return train_results[-1], test_results[-1]


if __name__ == "__main__":
    # dims = [3, 5, 10, 15, 20, 100]
    # sigmas = [0.01, 0.05, 0.1, 0.5, 1, 5]
    # lrs = [1e-1, 1e-2, 5e-2, 5e-3]
    #
    # table = PrettyTable()
    # table.field_names = ['dim', 'sigma', 'lr', 'train acc', 'test acc']
    # for dim in dims:
    #     for sigma in sigmas:
    #         for lr in lrs:
    #             train_acc, test_acc = run(dim=dim, sigma=sigma, lr=lr)
    #             table.add_row([dim, sigma, lr,
    #                            '{:.4f}'.format(train_acc.item()),
    #                            '{:.4f}'.format(test_acc.item())])
    #
    # print(table)
    parser = argparse.ArgumentParser()
    parser.add_argument("--lr", default=0.1,
                        type=float)
    parser.add_argument("--ratio", default=0.1,
                        type=float)
    parser.add_argument('--expr_path', type=str, default='./')
    parser.add_argument('--source_path', type=str)
    parser.add_argument('--nooverlap', action='store_true')
    parser.add_argument('--discretization', action='store_true')
    parser.add_argument('--filter', action='store_true')
    parser.add_argument("--dataset_name", default='FMoW')
    args = parser.parse_args()
    
    grads = []
    
    set_cpu_num()
    # os.environ["CUDA_VISIBLE_DEVICES"] = '7'
    run(args,
        lr=args.lr,
        R=5,
        projection=True)
