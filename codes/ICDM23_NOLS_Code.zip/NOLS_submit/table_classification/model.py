# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : model.py
############################
import torch.nn as nn

class MLP(nn.Module):
    """
    Basic Multi-layer perceptron as described in "Positive-Unlabeled Learning with Non-Negative Risk Estimator"
    """

    def __init__(self, input_size=21, hidden_size=None, output_size=3):
        super(MLP, self).__init__()
        if hidden_size is None:
            hidden_size = [64, 128, 256, 128, 32]
        layers = [
                nn.Linear(input_size, hidden_size[0], bias=False),
                nn.BatchNorm1d(hidden_size[0], eps=1e-3, momentum=0.99),
                nn.LeakyReLU(inplace=True),
                nn.Dropout(0.01),
                  ]
        for i in range(1, len(hidden_size)):
            layers += [
                    nn.Linear(hidden_size[i-1], hidden_size[i], bias=False),
                    nn.BatchNorm1d(hidden_size[i], eps=1e-3, momentum=0.99),
                    nn.LeakyReLU(inplace=True),
                    nn.Dropout(0.01),
                ]

        # for i in range(depth - 2):
        #     layers += [
        #         nn.Linear(hidden_size, hidden_size, bias=False),
        #         nn.BatchNorm1d(hidden_size, eps=1e-3, momentum=0.99),
        #         nn.ReLU(inplace=True)
        #     ]

        self.fc5 = nn.Linear(hidden_size[-1], output_size)
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        x = x.view(x.size()[0], -1)
        features = self.model(x)
        x = self.fc5(features)

        return x, features

