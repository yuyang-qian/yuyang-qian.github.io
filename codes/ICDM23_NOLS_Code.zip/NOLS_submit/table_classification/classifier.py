# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : classifier.py
############################
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
from os.path import join
import numpy as np
import argparse
import yaml
import time
import random

import torch
from torch.utils.tensorboard import SummaryWriter
import torch.utils.data as data
from torch.optim import Adam
import torch.nn as nn

from model import MLP
import sys

sys.path.append('../EULAC')
from dataset.table_data import get_table_data


def train(model, device, train_loader, optimizer, epoch, writer, loss_fct):
    model.train()
    tr_loss = 0
    length = len(train_loader)
    
    for batch_idx, (data, targets) in enumerate(train_loader):
        data, targets = data.to(device), targets.to(device)
        
        optimizer.zero_grad()
        output, features = model(data)  # output, {-1, 1}
        
        loss = loss_fct(output, targets)
        
        tr_loss += loss.item()
        loss.backward()
        optimizer.step()
        
        pred = output.argmax(-1)
        
        _correct = pred.eq(targets.view_as(pred))
        correct = _correct.sum().item()
        
        acc = correct / len(data)
        iter_num = (epoch - 1) * length + batch_idx
        writer.add_scalar('Train/Acc', acc, iter_num)
        
        print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
            epoch, batch_idx * len(data), len(train_loader.dataset),
                   100. * batch_idx / len(train_loader), loss.item()))


def test(model, device, test_loader, epoch, writer, test_loss_fct):
    """Testing"""
    model.eval()
    correct = 0
    count = 0
    with torch.no_grad():
        for batch_idx, (data, targets) in enumerate(test_loader):
            data, targets = data.to(device), targets.to(device)
            
            output, features = model(data)
            
            pred = output.argmax(-1)
            correct += pred.eq(targets.view_as(pred)).sum().item()
            count += len(data)
            
            # if count > 5000:
            #     break
    
    # acc = correct / len(test_loader.dataset)
    acc = correct / count
    writer.add_scalar('Test/Acc', acc, epoch)
    
    print('\nTest set: Accuracy: {}/{} ({:.0f}%)'.format(
        correct, count, 100. * acc))
    
    return acc


def cal_priors(dataset, cls_num):
    num = len(dataset)
    labels = []
    for i in range(num):
        labels.append(dataset[i][-1])
    count = np.bincount(labels, minlength=cls_num)
    priors = count / count.sum()
    
    return priors


def seed_everything(seed=2021):
    os.environ['PYTHONHASHSEED'] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    # some cudnn methods can be random even after fixing the seed
    # unless you tell it to be deterministic
    torch.backends.cudnn.deterministic = True


def main():
    parser = argparse.ArgumentParser()
    # mode
    parser.add_argument("--expr_space",
                        type=str,
                        help='the path of the experiment')
    parser.add_argument("--source_path",
                        type=str)
    parser.add_argument("--ratio",
                        type=float,
                        default=0.1)
    parser.add_argument("--batch_size",
                        type=int,
                        default=1024)
    parser.add_argument("--lr",
                        type=float,
                        default=1e-3)
    parser.add_argument("--weight_decay",
                        type=float,
                        default=0.01)
    parser.add_argument("--epoch",
                        type=int,
                        default=500)
    parser.add_argument("--model_depth",
                        type=int,
                        default=5)
    args = parser.parse_args()
    
    output = join(args.expr_space, 'output')
    
    seed_everything()
    
    arxiv_table_cfgs = {
        'source_data':
            {
                'path': args.source_path,
            },
        'train_ratio': args.ratio,
    }
    train_set, test_set, info = get_table_data(arxiv_table_cfgs, bbox=True)
    train_set, test_set = train_set.fission(0.2)
    source_priors = cal_priors(train_set, 3)
    target_priors = cal_priors(test_set, 3)
    print('source priors: {}\ttarget priors:{}'.format(source_priors, target_priors))
    
    train_loader = data.DataLoader(train_set, batch_size=args.batch_size, shuffle=True, pin_memory=False)
    test_loader = data.DataLoader(test_set, batch_size=args.batch_size, shuffle=True, pin_memory=False)
    # print('Train num: {}, test num: {}'.format(num_tr_sample, num_te))
    
    # model
    device = torch.device('cuda')
    # model = resnet(**cfg['model'].get('kwargs', {})).to(device)
    model = MLP(input_size=21,
                output_size=3,
                # hidden_size=100,
                ).to(device)
    
    optimizer = Adam(model.parameters(),
                     lr=float(args.lr),
                     weight_decay=float(args.weight_decay))
    writer = SummaryWriter(os.path.join(output, 'runs_{}'.format(int(time.time()))))
    loss_fct = nn.CrossEntropyLoss()
    
    best_acc = 0
    for epoch in range(1, args.epoch + 1):
        train(model, device, train_loader, optimizer, epoch, writer, loss_fct)
        
        if (epoch - 1) % 10 == 0:
            acc = test(model, device, test_loader, epoch, writer, loss_fct)
            
            if acc > best_acc:
                best_acc = acc
                torch.save(model.state_dict(), join(output, 'model_best.bin'))
            torch.save(model.state_dict(), join(output, 'model_latest.bin'))


if __name__ == "__main__":
    main()
