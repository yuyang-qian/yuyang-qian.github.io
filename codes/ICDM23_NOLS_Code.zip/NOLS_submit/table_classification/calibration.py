
import argparse

import torch
import torch.utils.data as data

import sys
sys.path.insert(0, '../EULAC')

from os.path import join
from utils.temperature_scaling import ModelWithTemperature

from model.linear import Linear
from dataset.table_data import get_table_data
import numpy as np
import pandas as pd
import torch.nn.functional as F
from sklearn.metrics import classification_report

def dataset_setup(data_path):
    data_cfgs = {
        'source_data':
            {
                'path': join('./data/tmp/LocomotionHuawei/features/allday', data_path),
            },
        'online_data': {},
        'seed': 0
    }

    train_set, test_set, info = get_table_data(data_cfgs, bbox=True)

    data_cfgs.update({
        'source_data': {
            'path': './data/tmp/LocomotionHuawei/features/allday/v4'
        }
    })

    val_set, _, _ = get_table_data(data_cfgs, bbox=True)

    return train_set, test_set, val_set, info


@torch.no_grad()
def extract(model, dataset, output):
    dates = dataset.datetime
    targets = dataset.ori_labels

    logits = model(dataset.data.cuda())

    soft_pred = F.softmax(logits, dim=-1)
    hard_pred = logits.argmax(-1)

    results = pd.DataFrame(soft_pred.cpu().numpy())
    results['date'] = dates
    results['y'] = targets

    results.to_csv(join(output), index=False)

    print(classification_report(dataset.labels, hard_pred.cpu().numpy()))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_path", type=str)
    parser.add_argument("--output_path", type=str)
    parser.add_argument('--disable_calibration', action='store_true')
    parser.add_argument("--data_path", type=str, default="v1/run_0")
    args = parser.parse_args()

    rng = np.random.default_rng(1881)
    train_set, test_set, val_set, info = dataset_setup(args.data_path)
    val_loader = data.DataLoader(val_set, batch_size=5000,
                                  shuffle=True, pin_memory=False)

    ori_model = Linear(input_dim=info['dim'], output_dim=info['cls_num'], R=100)
    ori_model.load_state_dict(torch.load(args.model_path, map_location='cpu'))
    ori_model.cuda()

    if args.disable_calibration:
        model = ori_model
    else:
        model = ModelWithTemperature(ori_model)
        model.set_temperature(val_loader)

    # torch.save(model.state_dict(), join(args.output_path, 'calibration_model.bin'))
    extract(model, train_set, join(args.output_path, 'train_data.csv'))
    extract(model, test_set, join(args.output_path, 'test_data.csv'))