# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : extract_features.py
############################
import argparse
from os.path import join
import pandas as pd
import numpy as np

from model import MLP

import sys
sys.path.append('../EULAC')
from dataset.table_data import get_table_data

import torch
from torch.utils.data import DataLoader, Dataset


class CustomDataset(Dataset):
    def __init__(self, data, labels, datetime):
        self.data = data
        self.labels = labels
        self.datetime = datetime

        if isinstance(self.data, np.ndarray):
            self.data = torch.from_numpy(self.data)
        self.data = self.data.float()

    def __getitem__(self, index):
        return self.data[index], self.labels[index], self.datetime[index]

    def __len__(self):
        return len(self.data)


def main():
    parser = argparse.ArgumentParser()
    # mode
    parser.add_argument("--output_path",
                        type=str,
                        help='the path of the experiment')
    parser.add_argument("--source_path",
                        type=str)
    parser.add_argument("--model_path",
                        type=str,)
    args = parser.parse_args()

    data = pd.read_csv(args.source_path)
    features = data.drop(columns=['y', 'date']).values
    labels = data['y'].values
    dates = data['date'].values

    train_loader = DataLoader(CustomDataset(features, labels, dates),
                                   batch_size=1024,
                                   shuffle=False,
                                   pin_memory=True)


    device = torch.device('cuda')
    # model = resnet(**cfg['model'].get('kwargs', {})).to(device)
    model = MLP(input_size=21,
                output_size=3,
                # hidden_size=100,
                ).to(device)
    model.load_state_dict(torch.load(args.model_path))
    model.eval()

    all_features, all_labels, all_dates = [], [], []
    for batch_idx, (data, labels, dates) in enumerate(train_loader):
        data, labels = data.to(device), labels.to(device)

        _, features = model(data)  # output, {-1, 1}
        all_features.append(features)
        all_labels.append(labels)
        all_dates.append(dates)

    all_features = torch.cat(all_features, dim=0).cpu().detach().numpy()
    all_labels = torch.cat(all_labels, dim=0).cpu().detach().numpy()
    all_dates = np.concatenate(all_dates, axis=0)
    # all_dates = torch.cat(all_dates, dim=0).cpu().numpy()

    df_features = pd.DataFrame(all_features, columns=["f{}".format(i) for i in range(len(all_features[0]))])
    df_labels = pd.DataFrame(all_labels, columns=["y"])
    df_dates = pd.DataFrame(all_dates, columns=["date"])

    df = pd.concat([df_features, df_labels, df_dates], axis=1)

    df.to_csv(args.output_path, index=False)

if __name__ == "__main__":
    main()
