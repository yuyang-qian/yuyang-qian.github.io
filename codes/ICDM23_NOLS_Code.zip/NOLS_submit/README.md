# Python implementation for "Handling New Class in Online Label Shift"

This is the python implementation for the experiments in the paper "**Handling New Class in Online Label Shift**". We will first introduce the structure and requirements of the code, followed by a brief instruction for a quick start.

## Code Structure

`main.py` is the entrance of the program. The code mainly contains the following three parts.

- **online**: Implementations of the proposed algorithms HAndling New class in Online Label shift (HANOL).

- **dataset**: Code for datasets pre-processing.

- **utils**: Useful tools for running the code.

## Requirements

- matplotlib==3.3.3
- numpy==1.19.2
- pandas==1.4.1
- prettytable==0.9.2
- PyYAML==6.0
- scikit_learn==0.23.2
- torch==2.0.1
- tqdm==4.62.3

## Quick Start

We provide several demos in the folder _./online_expr_. To get a quick start, the readers can run any demo by `bash train.sh` in the corresponding path with the parameter specified in `config.yaml`.

For example, one can use `./online_expr/locomotion/HANOL/train.sh` to run HANOL algorithm over the SHL datasets, whose parameters are set as `./online_expr/locomotion/HANOL/config.yaml`
