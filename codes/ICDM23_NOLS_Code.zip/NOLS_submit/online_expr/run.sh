find . -name train.sh | xargs -P 12 -I {} bash run.sh {}

