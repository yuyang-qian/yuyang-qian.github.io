# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : seed.py
############################
import os
import random
import torch
import numpy as np


def seed_everything(seed=2021):
    os.environ['PYTHONHASHSEED'] = str(seed)
    
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    # some cudnn methods can be random even after fixing the seed
    # unless you tell it to be deterministic
    torch.backends.cudnn.deterministic = True
    
    return np.random.default_rng(seed)
