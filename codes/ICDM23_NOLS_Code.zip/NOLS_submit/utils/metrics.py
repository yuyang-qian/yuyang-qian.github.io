#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021-01-25 10:25

# @File    : metrics.py
############################
import torch
import torch.tensor as tensor
from sklearn.metrics import classification_report


def augAuc(output, target, aug_label=6):
    # output: N * K
    # target: N
    logit_value = output
    tar_idx = target

    tpr_li, fpr_li = [], []
    threshold_li = [0, 0.001, 0.005, 0.01]
    for i in range(5):
        threshold_li.append(0.2 * i + 0.1)
    threshold_li.append(0.99)
    threshold_li.append(0.995)
    threshold_li.append(0.999)
    threshold_li.append(1)
    for j in range(len(threshold_li)):
        threshold = tensor(threshold_li[j], device='cuda:0')
        TP, FP, FN, TN, ic_pred, ic_acc = 0, 0, 0, 0, 0, 0
        for i in range(len(logit_value)):
            if bool(logit_value[i][-1] > threshold):  # predict true
                if bool(tar_idx[i] == tensor(aug_label, device='cuda:0')):  # TODO remove hard code
                    TP += 1
                else:
                    FP += 1
            else:  # predict false
                if bool(tar_idx[i] != tensor(aug_label, device='cuda:0')):
                    TN += 1
                else:
                    FN += 1
        tpr_li.append(TP / max(TP + FN, 1))
        fpr_li.append(FP / max(TN + FP, 1))

    auc = 0
    for i in range(len(tpr_li) - 1):
        auc += 0.5 * (fpr_li[i + 1] - fpr_li[i]) * (tpr_li[i] + tpr_li[i + 1])

    auc = round(-1 * auc, 5)

    return auc


def accuracy(output, target):
    # output: N * K
    # target: N

    predicts = output.argmax(-1)
    total = len(target)
    correct = (predicts == target).sum().item()
    acc = correct / total

    return acc


def binAccuracy(output, aug=False):
    # output: N * K
    # target: N
    predicts = output.argmax(-1)
    total = len(output)

    target = torch.ones(total) * 6
    target = target.cuda()
    # is augment class
    if aug:
        correct = (predicts == target).sum().item()
    else:
        correct = (predicts != target).sum().item()

    acc = correct / total

    return acc


def report(output, target):
    cls_num = len(output[0])
    y_pred = output.argmax(-1).cpu().detach().numpy()
    y_true = target.cpu().detach().numpy()
    target_names = ['Kc {}'.format(i) for i in range(cls_num-1)]
    if len(target_names) < len(torch.unique(target)):
        target_names.append('Ac')

    cls_report = classification_report(y_true, y_pred, target_names=target_names)

    return cls_report

