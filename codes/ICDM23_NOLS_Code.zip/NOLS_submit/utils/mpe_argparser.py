#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021-01-25 10:46

# @File    : argparser.py
############################
import argparse
import json as js
import yaml
import os
from os.path import join, exists


def argparser():
    parser = argparse.ArgumentParser()
    # mode
    parser.add_argument("--mode",
                        default="train",
                        type=str,
                        choices=["train", "test"])
    
    parser.add_argument("--expr_space",
                        type=str,
                        default='./template',
                        help='the path of the experiment')
    args = parser.parse_args()
    
    cfg_path = join(args.expr_space, 'config.yaml')
    if not exists(cfg_path):
        raise ValueError
    with open(cfg_path) as f:
        cfg = yaml.load(f, Loader=yaml.Loader)
    
    cfg['train']['lr'] = float(cfg['train']['lr'])
    cfg['output'] = join(args.expr_space, 'output')
    cfg['path'] = args.expr_space
    os.makedirs(cfg['output'], exist_ok=True)
    
    print(js.dumps(cfg, indent=4))
    
    return cfg
