# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : mpe.py
############################
import copy
import logging

import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import random_split, DataLoader
from model import ResModel, BertModel

try:
    import lightning as L
    from lightning.callbacks import Callback
except:
    import pytorch_lightning as L
    from pytorch_lightning.callbacks import Callback
import torchmetrics

try:
    from utils.MPE import BBE_estimator, scott_estimator
except ImportError:
    from mpe import BBE_estimator
    from scott import ScottsEstimator

from model.cnn import *
from model.resnet import Linear

logging.getLogger("pytorch_lightning").setLevel(logging.WARNING)


def probs(net, data_loader, device='cuda'):
    net.eval()
    p_probs = None
    u_probs = None
    
    with torch.no_grad():
        for batch_idx, (data, target, label_mask) in enumerate(data_loader):
            data = data.to(device)
            outputs, _ = net(data)
            probs = outputs.sigmoid()
            
            if p_probs is None:
                p_probs = probs[label_mask].detach().cpu().numpy().squeeze()
            else:
                p_probs = np.concatenate((p_probs, probs[label_mask].detach().cpu().numpy().squeeze()),
                                         axis=0)
            
            if u_probs is None:
                u_probs = probs[~label_mask].detach().cpu().numpy().squeeze()
            else:
                u_probs = np.concatenate((u_probs, probs[~label_mask].detach().cpu().numpy().squeeze()),
                                         axis=0)
    
    return p_probs, u_probs


class PvUModel(L.LightningModule):
    def __init__(self, model, cfg, val_loader):
        super().__init__()
        self.model = model
        self.loss_func = nn.BCEWithLogitsLoss()
        self.train_acc = torchmetrics.Accuracy(task="multiclass",
                                               num_classes=10)
        self.val_acc = torchmetrics.Accuracy(task="multiclass",
                                             num_classes=10)
        self.cfg = cfg
        self.val_loader = val_loader
    
    def forward(self, x):
        output, _ = self.model(x)
        return output
    
    def training_step(self, batch, batch_idx):
        data, _, label_mask = batch
        # data = data[:, 0, :]
        # label_mask = label_mask[:, 0]
        output, features = self.model(data)
        label_mask = label_mask.float()
        
        loss = self.loss_func(output.flatten(), label_mask)
        
        self.log('training_loss', loss,
                 sync_dist=True, prog_bar=False,
                 logger=False)
        
        with torch.no_grad():
            predicted_labels = (output > 0).long().flatten()
            acc = self.train_acc(predicted_labels, label_mask)
            self.log("train_acc", self.train_acc,
                     on_epoch=True, on_step=False,
                     prog_bar=False, logger=False
                     )
        
        return {
            'loss'     : loss,
            'train_acc': acc
        }
    
    def validation_step(self, batch, batch_idx):
        data, _, label_mask = batch
        # data = data[:, 0, :]
        output, _ = self.model(data)
        # label_mask = label_mask[:, 0]
        
        label_mask = label_mask.to(torch.long)
        
        predicted_labels = (output > 0).long().flatten()
        
        self.val_acc(predicted_labels, label_mask)
        
        self.log(
            'val_acc', self.val_acc,
            prog_bar=False,
            logger=False,
        )
    
    def configure_optimizers(self):
        optimizer = torch.optim.SGD(self.model.parameters(),
                                    lr=self.cfg['mpe']['lr'],
                                    momentum=0.9,
                                    weight_decay=self.cfg['mpe'].get('weight_decay', 0.0))
        return optimizer


class EstimateTracker(Callback):
    
    def __init__(self, device):
        self.collection = []
        self.device = device
    
    def on_validation_epoch_end(self, trainer, module):
        # if trainer.current_epoch % 3 == 0 and trainer.current_epoch > 5:
        if trainer.current_epoch % 1 == 0 and trainer.current_epoch > 0:
            p_probs, u_probs = probs(module.model, module.val_loader, device=self.device)
            bbe_mpe_estimate, _, _ = BBE_estimator(p_probs, u_probs)
            self.log('bbe_estimate', bbe_mpe_estimate,
                     prog_bar=False, logger=False)
            
            # scotts_mpe_estimate = scott_estimator(p_probs, u_probs)
            # self.log('scotts_estimate', scotts_mpe_estimate,
            #          prog_bar=True, logger=True)
            self.collection.append(bbe_mpe_estimate)


def mpe_estimate(train_loader, cfg):
    # 1. split dataset into train and val
    dataset = train_loader.dataset
    train_set, val_set = \
        random_split(dataset, [int(0.5 * len(dataset)), int(0.5 * len(dataset))])
    # random_split(dataset, [0.5, 0.5])
    # random_split(dataset, [int(0.5 * len(dataset)), int(0.5 * len(dataset))])
    
    train_loader = DataLoader(train_set,
                              batch_size=128,
                              shuffle=True,
                              num_workers=4)
    val_loader = DataLoader(val_set,
                            batch_size=128,
                            shuffle=False,
                            num_workers=4)
    
    # 2. train a domain discriminator
    model = eval(cfg['mpe']['model']['name']) \
        (**cfg['mpe']['model']['kwargs'])
    warped_model = PvUModel(model, cfg, val_loader)
    
    estimate_tracker = EstimateTracker()
    trainer = L.Trainer(
        accelerator="gpu" if torch.cuda.is_available() else "cpu",
        max_epochs=5,
        precision=16,
        # logger=L.loggers.TensorBoardLogger(
        #     save_dir=cfg['output'],
        #     name='mpe',
        #     version=cfg.get('version', None),
        # ),
        callbacks=[estimate_tracker],
        logger=False,
        enable_progress_bar=False,
        enable_model_summary=False,
    )
    
    trainer.fit(warped_model, train_loader, val_loader)
    
    # print('MPE Estimation', estimate_tracker.collection)
    
    return np.mean(estimate_tracker.collection)


class online_mpe_estimate:
    def __init__(self):
        self.re_estimation = None
    
    def online_mpe(self, dataset, cfg):
        # re_estimation = None
        
        # if estimated_label_prior is None:
        #     estimated_label_prior = np.ones(10) / 10
        
        beta = cfg['mpe']['beta']  # weight decay of window mpe, default=0.7
        # 1. split dataset into train and val
        # for train_loader in loaders:
        # dataset = train_loader.dataset
        # train_set, val_set = \
        #     random_split(dataset, [int(0.9 * len(dataset)), int(0.1 * len(dataset))])
        
        epoch = cfg['mpe']['epoch']
        train_set = copy.deepcopy(dataset)
        val_set = copy.deepcopy(dataset)
        train_loader = DataLoader(train_set,
                                  batch_size=100,
                                  shuffle=True,
                                  num_workers=0,
                                  drop_last=False)
        val_loader = DataLoader(val_set,
                                batch_size=100,
                                shuffle=False,
                                num_workers=0,
                                drop_last=False)
        
        # 2. train a domain discriminator
        model = eval(cfg['mpe']['model']['name']) \
            (**cfg['mpe']['model']['kwargs'])
        warped_model = PvUModel(model, cfg, val_loader)
        
        # device = "gpu" if torch.cuda.is_available() else "cpu"
        device = "cpu"
        estimate_tracker = EstimateTracker(device=device)
        trainer = L.Trainer(
            accelerator=device,
            max_epochs=epoch,
            precision=16,
            logger=False,
            # logger=L.loggers.TensorBoardLogger(
            #     save_dir=cfg['output'],
            #     name='mpe',
            #     version=cfg.get('version', None),
            # ),
            callbacks=[estimate_tracker],
            enable_progress_bar=False,
            enable_model_summary=False,
        )
        
        trainer.fit(warped_model, train_loader, val_loader)
        
        # print('MPE Estimation', estimate_tracker.collection)
        tmp_estimation = np.mean(estimate_tracker.collection)
        
        if self.re_estimation is None:
            self.re_estimation = tmp_estimation
        else:
            self.re_estimation = (1 - beta) * self.re_estimation + tmp_estimation * beta
        
        return self.re_estimation
