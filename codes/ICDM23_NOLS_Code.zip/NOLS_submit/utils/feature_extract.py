import pickle
import random
from datetime import datetime

import torch
import numpy as np
import argparse
from wildtime import dataloader
import os
import sys
from torchvision import datasets, transforms
from PIL import Image
from torch import nn, optim
from torch.utils.tensorboard import SummaryWriter

sys.path.append('../')
sys.path.append('./')

# sys.path.append('../../')
from tqdm import trange, tqdm
# from model.yearbook_net import YearbookNetwork
from model.FMoW_net import FMoWNetwork
from logger import MyLogger


def random_sample_idx(num, len_dataset):
    num = min(num, len_dataset)
    data_sample_id = np.random.choice(range(len_dataset), num, replace=False)
    # data_sample_id = torch.from_numpy(data_sample_id)
    return data_sample_id


class LabeledDataset():
    """
    For labeled dataset
    """
    
    def __init__(self, data, label, years=None, num_classes=2, transform=None, label_transform=None, desc=''):
        self.data = data
        self.labels = label
        self.transform = transform
        self.label_transform = label_transform
        self.num_classes = num_classes
        self.desc = desc
        self.years = years
        if self.desc == 'FMoW':
            self.imgs = []
            for img_idx in tqdm(data):
                img = Image.open('./datasets/fmow_v1.1/images/rgb_img_{}.png'.format(img_idx))
                img = np.array(img).astype(np.float32)
                img = img / 255.0
                self.imgs.append(img)
            self.data = self.imgs
    
    def _pre_process(self, img):  # Pre-processing one image.
        img = np.array(img).astype(np.float32)
        return img
    
    def __getitem__(self, idx):
        img, target = self.data[idx], int(self.labels[idx])
        # doing this so that it is consistent with all other datasets
        # to return a PIL Image
        
        img = self._pre_process(img)
        
        if self.transform is not None:
            img = self.transform(img)
        
        if self.label_transform is not None:
            target = self.label_transform(target)
        if self.years is None:
            return img, target
        else:
            return img, target, int(self.years[idx])
    
    def __len__(self):
        return len(self.data)


def get_data(dataset_name):
    all_data = []
    all_label = []
    all_years = []
    if dataset_name == 'yearbook':
        configs = argparse.Namespace(dataset='yearbook', device=0, random_seed=random.randint(1, 1000), reduced_train_prop=None, data_dir='./datasets', mini_batch_size=1, method='erm')
        data = dataloader.getdata(configs)
        for i in trange(1930, 2013 + 1):
            # for i in trange(1930, 1940):
            # Only use OOD Data (Mix of all times)
            images = data.datasets[i][0]['images']
            labels = data.datasets[i][0]['labels']
            for idx in range(len(images)):
                all_data.append(images[idx])
                all_label.append(labels[idx])
                all_years.append(i)
    elif dataset_name == 'FMoW':
        configs = argparse.Namespace(dataset='fmow', device=0, random_seed=random.randint(1, 1000), reduced_train_prop=None, data_dir='./datasets', mini_batch_size=1, method='erm')
        data = dataloader.getdata(configs)
        for i in trange(0, 15 + 1):
            # for i in trange(1930, 1940):
            # Only use OOD Data (Mix of all times)
            images = data.datasets[i][0]['image_idxs']
            labels = data.datasets[i][0]['labels']
            for idx in range(len(images)):
                all_data.append(images[idx])
                all_label.append(labels[idx])
                all_years.append(i)
    else:
        raise NotImplementedError
    
    return all_data, all_label, all_years


def train(args, train_dataset, test_dataset, net, optimizer, criterion, writer, logger):
    net.train()
    train_sampler = torch.utils.data.RandomSampler(train_dataset)
    train_dataloader = torch.utils.data.DataLoader(
        train_dataset,  # pass the dataset to the dataloader
        batch_size=args.batchsize,  # a large batch size helps with the learning
        sampler=train_sampler,  # shuffling is important!
        drop_last=True,
        num_workers=8)  # apply transformations to the input images
    
    n_total = len(train_dataloader)
    print("Starting Training")
    loss = torch.randn(32, 0)
    for epoch in range(args.num_epoch):
        total_loss = 0.0
        num_iter = 0
        last_loss = 0.0
        correct_num = 0
        # progress_bar = tqdm(dataloader)
        for step, batch in enumerate(tqdm(train_dataloader, desc='Train | epoch:{} | loss:{}'.format(epoch + 1, last_loss))):
            # if distributed:
            #     dist.barrier()
            x, y = batch
            x = x.cuda()
            y = y.cuda()
            # print(x.shape)
            
            optimizer.zero_grad()
            y_hat = net(x)
            
            loss = criterion(y_hat, y)
            last_loss = torch.mean(loss.detach()).item()
            total_loss += last_loss
            loss.backward()
            optimizer.step()
            num_iter += 1
            cur_step = epoch * n_total + step
            
            _, predicted = y_hat.max(1)
            # real_prec = (y == real_predicted).sum().data[0] / batch_size
            correct_num += (y == predicted).sum().item()
            
            if cur_step % args.display_iter == 0:
                writer.add_scalar('Train/lr', optimizer.state_dict()['param_groups'][0]['lr'], cur_step)
                writer.add_scalar('Train/loss', last_loss, cur_step)
                writer.add_scalar('Train/acc', correct_num / (step + 1) / args.batchsize, cur_step)
                # print(torch.mean(loss).item())
            if cur_step % args.test_iter == 0:
                args.cur_step = cur_step
                args.epoch = epoch
                test(args, train_dataset, test_dataset, net, optimizer, criterion, writer, logger)
            
            # if cur_step % 300 == 0:
            #     torch.save(net.state_dict(), '{}/saved_{}.pth'.format(, cur_step))
            #     logger.info('Saving pretrain model Success! at {}'.format('{}/saved_{}_{}.pth'.format(os.path.join(config.checkpoint_dir, config.save_path), config.model, cur_step)))
            # if cur_step % 2000 == 0:
            #     if scheduler == 'MultiStepLR':
            #         scheduler.step()
        avg_prec = correct_num / len(train_dataset)
        avg_loss = total_loss / len(train_dataloader)
        logger.info(f"Train: epoch: {epoch + 1:>02}, cur_step: {cur_step}, loss: {avg_loss:.5f}, acc: {avg_prec:.5f}")


def test(args, train_dataset, test_dataset, net, optimizer, criterion, writer, logger):
    net.eval()
    test_dataloader = torch.utils.data.DataLoader(
        test_dataset,  # pass the dataset to the dataloader
        # batch_size=args.batchsize,  # a large batch size helps with the learning
        batch_size=128,  # a large batch size helps with the learning
        sampler=torch.utils.data.SequentialSampler(test_dataset),  # shuffling is important!
        drop_last=False,
        num_workers=4)  # apply transformations to the input images
    
    total_loss = 0.0
    last_loss = 0.0
    # all_output_representation = None
    # all_output_label = None
    dict_representation_label = {}
    correct_num = 0
    
    for step, batch in enumerate(tqdm(test_dataloader, desc='Test | cur_step:{} | loss:{}'.format(args.cur_step + 1, last_loss))):
        # if distributed:
        #     dist.barrier()
        x, y, year = batch
        x = x.cuda()
        y = y.cuda()
        
        # optimizer.zero_grad()
        y_hat = net(x)
        x_representation = net(x, mode='representation')  # output the representation
        # print(x_representation.shape)
        loss = criterion(y_hat, y)
        
        _, predicted = y_hat.max(1)
        # real_prec = (y == real_predicted).sum().data[0] / batch_size
        correct_num += (y == predicted).sum().item()
        
        last_loss = torch.mean(loss.detach()).item()
        total_loss += last_loss
        x_representation = x_representation.detach().cpu()
        y = y.detach().cpu()
        year = year.detach().cpu()
        # print(year)
        for i in range(x_representation.shape[0]):
            if year[i].item() not in dict_representation_label.keys():
                dict_representation_label[year[i].item()] = {}
                dict_representation_label[year[i].item()]['feature'] = []
                dict_representation_label[year[i].item()]['label'] = []
            dict_representation_label[year[i].item()]['feature'].append(x_representation[i].view(-1).numpy())
            dict_representation_label[year[i].item()]['label'].append(y[i].item())
    
    avg_prec = correct_num / len(test_dataset)
    avg_loss = total_loss / len(test_dataloader)
    logger.info(f"Test: epoch: {args.epoch + 1:>02}, cur_step: {args.cur_step}, loss: {avg_loss:.5f}, acc: {avg_prec:.5f}")
    writer.add_scalar('Test/loss', avg_loss, args.cur_step)
    writer.add_scalar('Test/acc', avg_prec, args.cur_step)
    net.train()
    
    f_save = open('{}/data_dict_{}.pkl'.format(args.save_dir, args.cur_step), 'wb')
    pickle.dump(dict_representation_label, f_save)
    f_save.close()


if __name__ == '__main__':
    # dataset_name = 'yearbook'
    dataset_name = 'FMoW'
    args = argparse.Namespace()
    
    os.environ['CUDA_VISIBLE_DEVICES'] = '2'
    
    args.num_epoch = 500
    args.learning_rate = 1e-3
    # args.num_train = 1676 + 2279 + 1755  # 3 years for FMoW, 1 year for Yearbook
    args.num_train = 1676 + 2279 + 2512 + 3155 + 1497 + 2261 + 7439
    # args.num_train = 1676 + 2279 + 2512
    # args.num_train = 1676 + 2279
    # args.num_train = 1676
    # args.batchsize = 50
    args.batchsize = 192
    args.display_iter = 10
    # args.test_iter = min(args.num_train // 20, 100)
    args.test_iter = 100
    args.front_sample = True
    
    # if dataset_name == 'yearbook':
    #     net = YearbookNetwork(num_input_channels=3,
    #                           num_classes=2)
    if dataset_name == 'FMoW':
        net = FMoWNetwork()
    else:
        raise NotImplementedError
    
    net = net.cuda()
    timenow = datetime.now().strftime('%m-%d_%H:%M:%S')
    save_dir = './log/{}_{}_{}'.format(timenow, dataset_name, args.num_train)
    if args.front_sample:
        save_dir = './log/{}_{}_front_{}'.format(timenow, dataset_name, args.num_train)
    os.makedirs(save_dir)
    
    writer = SummaryWriter(
        log_dir=save_dir
    )
    logger = MyLogger('{}/{}'.format(save_dir, 'log.txt'))
    logger.info(str(save_dir))
    args.save_dir = save_dir
    all_data, all_label, all_years = get_data(dataset_name)
    
    sampled_idx = random_sample_idx(args.num_train, len(all_data))
    if args.front_sample:
        sampled_idx = list(range(args.num_train))
    
    # sampled_idx = random_sample_idx(len(all_data), len(all_data))
    # Only use 3000 examples to train representation
    train_dataset = LabeledDataset(data=[all_data[i] for i in sampled_idx],
                                   label=[all_label[i] for i in sampled_idx],
                                   transform=transforms.Compose([
                                       transforms.ToTensor(),
                                   ]),
                                   num_classes=2,
                                   desc=dataset_name)
    
    test_dataset = LabeledDataset(data=all_data,
                                  label=all_label,
                                  years=all_years,
                                  # data=all_data[:10000],
                                  # label=all_label[:10000],
                                  # years=all_years[:10000],
                                  transform=transforms.Compose([
                                      transforms.ToTensor(),
                                  ]),
                                  num_classes=2,
                                  desc=dataset_name)
    
    optimizer = optim.Adam(
        # optimizer_grouped_parameters
        net.parameters(),
        lr=args.learning_rate,
        # weight_decay=weight_decay,
        # betas=
    )
    
    criterion = nn.CrossEntropyLoss()
    
    train(args, train_dataset, test_dataset, net, optimizer, criterion, writer, logger)
