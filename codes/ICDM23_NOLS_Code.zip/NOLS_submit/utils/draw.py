#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021-12-13 10:42

# @File    : draw.py
############################

import matplotlib

matplotlib.use('AGG')

import matplotlib.pyplot as plt
import numpy as np
from os.path import join


def draw_acc(train_acc, test_acc, epoch, output=None):
    plt.plot(np.arange(epoch), train_acc, label='train')
    plt.plot(np.arange(epoch), test_acc, label='test')
    plt.legend()
    
    if output is not None:
        plt.savefig(join(output, 'acc.pdf'), bbox_inches="tight")
    else:
        plt.show()
