#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : utils.py
############################
import time
import torch

try:
    from lightning.callbacks import Callback
    # from lightning.utilities.decorators import rank_zero_only
except:
    from pytorch_lightning.callbacks import Callback
    # from pytorch_lightning.utilities.decorators import rank_zero_only

import yaml
from collections import defaultdict

class Timer(object):
    def __init__(self):
        self.tik()

    def tik(self):
        self.timestamp = time.time()

    def tok(self, desc=''):
        history = self.timestamp
        self.tik()
        print('>>> [{}] Cost time: {:.4f} seconds'.format(desc, self.timestamp - history))

class OnCheckpointHparams(Callback):
    def on_save_checkpoint(self, trainer, pl_module, checkpoint):
        # only do this 1 time
        if trainer.current_epoch == 0 \
                and trainer.global_rank == 0:
            file_path = f"{trainer.logger.log_dir}/hparams.yaml"
            print(f"Saving hparams to file_path: {file_path}")
            with open(file_path, "w") as fp:
                yaml.dump(pl_module.cfg, fp, indent=4)


class MetricsTracker(Callback):

    def __init__(self):
        self.collection = defaultdict(dict)

    def on_train_batch_end(self, trainer, pl_module,
                           outputs, batch, batch_idx):

        for k, v in outputs.items():
            outputs[k] = v.item() if isinstance(v, torch.Tensor) else v

        self.collection['train'][batch_idx] = outputs

    def on_validation_epoch_end(self, trainer, module):
        self.collection['val'][trainer.current_epoch] = \
            {'ACC': trainer.logged_metrics.get('val_acc', torch.tensor(0)).item()}


class Pipeline(object):
    def __init__(self, *funcs):
        self.funcs = funcs

    def __call__(self, data):
        for func in self.funcs:
            data = func(data)

        return data

    def add_func(self, func):
        self.funcs += func


def get_optimizer(model, cfg):
    if 'multi_lr' not in cfg:
        params = model.parameters()
    else:
        param_backbone, param_classifier = [], []
        cls_para_name = cfg['multi_lr']['cls_para']
        for name, sub_model in model.named_children():
            if name in cls_para_name:
                param_classifier += sub_model.parameters()
            else:
                param_backbone += sub_model.parameters()
        params = [
            {'params': param_backbone, 'lr': cfg['lr']},
            {'params': param_classifier, 'lr': cfg['lr'] * cfg['multi_lr']['lr_mul']}
        ]

    opt_name = cfg.get('optimizer', 'AdamW')
    if opt_name == 'AdamW':
        optimizer = torch.optim.AdamW(params, lr=cfg['lr'])
    elif opt_name == 'SGD':
        optimizer = torch.optim.SGD(params, lr=cfg['lr'], momentum=0.9,
                                    weight_decay=cfg['weight_decay'])
    else:
        raise NotImplementedError

    return optimizer





if __name__ == "__main__":
    time_helper = Timer()
    time_helper.tik()
    time.sleep(5)
    time_helper.tok()