# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : tsne.py
############################
from os.path import join
from os import makedirs

from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
import numpy as np
import matplotlib
matplotlib.use('AGG')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
plt.rc('font',family='Times New Roman')


class TsneHelper(object):
    def __init__(self, **kwargs):
        self.pca = kwargs.get('pca', False)
        self.pca_n = kwargs.get('pca_n', 100)
        self.n_components = kwargs.get('n_components', 2)
        self.perplexity = kwargs.get('perplexity', 50)
        self.learning_rate = kwargs.get('learning_rate', 200)
        self.early_exaggeration = kwargs.get('early_exaggeration', 24)
        self.random_state = 2020
        self.n_jobs = kwargs.get('n_jobs', 4)

    def __call__(self, data):
        if self.pca:
            data = self.use_pca(data)
        res = TSNE(n_components=self.n_components,
                   perplexity=self.perplexity,
                   learning_rate=self.learning_rate,
                   early_exaggeration=self.early_exaggeration,
                   init='pca',
                   verbose=1,
                   random_state=self.random_state,
                   n_jobs=self.n_jobs,
                   ).fit_transform(data)

        return res

    def use_pca(self, data):
        pca_helper = PCA(n_components=self.pca_n,
                         random_state=self.random_state)
        data = pca_helper.fit_transform(data)
        
        return data


def draw_tsne(features, labels, epoch, output):
    tsne_helper = TsneHelper(pca=False, pca_n=100, n_components=2)
    fig = plt.figure()

    # ax = fig.add_subplot(111, projection='3d')
    ax = fig.add_subplot(111)
    plt.title('T-SNE for Epoch {:0>3d}'.format(epoch))
    tsne_data = tsne_helper(features)
    x_min, x_max = tsne_data.min(0), tsne_data.max(0)
    tsne_data = (tsne_data - x_min) / (x_max - x_min)

    colors = ['black', 'tab:orange', 'tab:blue']
    keys = ['unlabel_known' , 'unlabel_aug', 'labeled']
    alphas = [0.7, 0.3, 0.3]
    markers = ['^', 'o', 'o']
    for idx, k in enumerate(keys):
        X_data = tsne_data[labels[k] == 1]
        np.random.shuffle(X_data)
        num = min(500, len(X_data))
        X_data = X_data[:num]
        ax.scatter(X_data[:, 0], X_data[:, 1], label=k,
                   alpha=alphas[idx],
                   color=colors[idx],
                   marker=markers[idx])

    ax.legend()
    output = join(output, 't-sne')
    makedirs(output, exist_ok=True)
    plt.savefig(join(output, '{:0>3d}.png'.format(epoch)))
