# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : custom_loader.py
############################

import torch.utils.data as data
import numpy as np

# try:
from data.data_utils import split_data, load_vision_dataset


# except ImportError:
#     from utils import split_data, load_vision_dataset


class CustomDataset(data.Dataset):
    def __init__(self, features, labels,
                 cfg, cls_map, transform=None):
        self.cfg = cfg
        self.transform = transform
        self.features, self.real_labels = features, labels
        self.label_mask = self.gen_label_mask()
        
        self.cls_map = cls_map
    
    def gen_label_mask(self):
        raise NotImplementedError
    
    def __getitem__(self, index):
        feat = self.features[index]
        real_label = self.cls_map[self.real_labels[index]]
        label_mask = self.label_mask[index]
        
        # transform data
        if self.transform is not None:
            feat = self.transform(feat)
        
        return feat, real_label, label_mask
    
    def __len__(self):
        return len(self.features)


class TrainSet(CustomDataset):
    def __init__(self, features, labels, cfg, cls_map, transform=None):
        super(TrainSet, self).__init__(features, labels, cfg, cls_map, transform)
    
    def gen_label_mask(self):
        pu_ratio = self.cfg['train']['pu_ratio']
        theta = self.cfg['train']['theta']
        
        idx_new, idx_known = [], []
        for idx, label in enumerate(self.real_labels):
            if label in self.cfg['new_class']:
                idx_new.append(idx)
            else:
                idx_known.append(idx)
        
        num_new, num_known = len(idx_new), len(idx_known)
        num_u = int(min(num_known // (theta + pu_ratio), num_new // (1 - theta)))
        num_u_known = int(num_u * theta)
        num_u_new = num_u - num_u_known
        num_l_known = int(num_u * pu_ratio)
        
        idx_u_known, idx_l_known = split_data(idx_known, num_u_known, num_l_known)
        idx_u_new, _ = split_data(idx_new, num_u_new)
        
        label_mask = np.zeros(len(self.features), dtype=np.bool_)
        label_mask[idx_l_known] = True
        
        idx_use = np.concatenate([idx_u_known,
                                  idx_u_new, idx_l_known])
        
        self.features = [self.features[idx] for idx in idx_use]
        self.real_labels = self.real_labels[idx_use]
        
        return label_mask[idx_use]


class TestSet(CustomDataset):
    def __init__(self, features, labels, cfg, cls_map, transform=None):
        super(TestSet, self).__init__(features, labels, cfg, cls_map, transform)
    
    def gen_label_mask(self):
        return np.ones(len(self.features), dtype=np.bool_)
