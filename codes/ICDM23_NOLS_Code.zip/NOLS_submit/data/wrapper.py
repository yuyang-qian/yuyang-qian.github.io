# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : wrapper.py
############################

from torch.utils.data import DataLoader

import sys

sys.path.append('../EULAC')
sys.path.append('../')
sys.path.append('')

# try:
from data.data_utils import *
from data.custom_loader import TrainSet, TestSet


# except ImportError:
#     from utils import *
#     from custom_loader import TrainSet, TestSet


def get_data_loader(cfg):
    type = cfg.get('type', 'vision')
    if type == 'vision':
        data = load_vision_dataset(cfg)
    elif type == 'text':
        data = load_text_dataset(cfg)
    else:
        raise NotImplementedError
    
    cls_map = gen_cls_map(cfg)
    
    train_set = TrainSet(data['train_features'], data['train_labels'],
                         cfg, cls_map, transform=data['train_transform'])
    test_set = TestSet(data['test_features'], data['test_labels'],
                       cfg, cls_map, transform=data['test_transform'])
    on_test_set = TestSet(data['on_features'], data['on_labels'],
                          cfg, cls_map, transform=data['test_transform'])
    train_loader = DataLoader(train_set,
                              batch_size=cfg['train_batch_size'],
                              shuffle=True,
                              num_workers=cfg['num_workers'])
    test_loader = DataLoader(test_set,
                             batch_size=cfg['test_batch_size'],
                             shuffle=False,
                             num_workers=cfg['num_workers'])
    on_test_loader = DataLoader(on_test_set,
                                batch_size=cfg['test_batch_size'],
                                shuffle=False,
                                num_workers=cfg['num_workers'])
    return train_loader, test_loader, on_test_loader


# write test code here
if __name__ == '__main__':
    # test CustomTrainSet
    cfg = {
        'name'            : 'CIFAR10',
        'path'            : './tmp',
        'type'            : 'vision',
        'use_vision'      : True,
        'new_class'       : [0, 1, 2, 3, 4],
        'known_class'     : [5, 6, 7, 8, 9],
        'train'           : {
            'pu_ratio': 0.5,
            'theta'   : 0.5
        },
        'preprocess'      : {
            'normalize': ((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
            'crop'     : 32,
        },
        'test_size'       : 0.2,
        'train_batch_size': 128,
        'test_batch_size' : 128,
        'num_workers'     : 2,
        'random_state'    : 2023,
    }
    print(cfg)
    train_loader, test_loader, on_test_loader = get_data_loader(cfg)
    for i, (img, real_label, label_mask) in enumerate(train_loader):
        # from IPython import embed;
        
        # embed()
        print(i)
        break
