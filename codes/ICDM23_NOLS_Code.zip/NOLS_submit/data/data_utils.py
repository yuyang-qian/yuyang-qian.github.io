# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : utils.py
############################
from datasets import load_dataset
from transformers import AutoTokenizer

import torchvision.datasets as vis_datasets
import torchvision.transforms as transforms

import numpy as np
import torch

# from utils.utils import Pipeline
from utils.utils import Pipeline
from sklearn.model_selection import train_test_split

try:
    from data.randaugment import RandAugment
except ImportError:
    from randaugment import RandAugment


## text datasets with huggingface datasets
def load_text_dataset(cfg):
    off_data = load_dataset(cfg['name'], split='train')
    on_data = load_dataset(cfg['name'], split='test')
    
    train_transform = Pipeline(Tokenize())
    test_transform = Pipeline(Tokenize())
    
    train_features, off_test_features, train_labels, off_test_labels = \
        train_test_split(off_data['text'], off_data['label'],
                         test_size=cfg['test_size'],
                         random_state=cfg['random_state'])
    
    return {
        'train_features' : train_features,
        'train_labels'   : np.array(train_labels),
        'train_transform': train_transform,
        'test_features'  : off_test_features,
        'test_labels'    : np.array(off_test_labels),
        'test_transform' : test_transform,
        'on_features'    : on_data['text'],
        'on_labels'      : np.array(on_data['label']),
    }


class Tokenize(object):
    def __init__(self):
        self.tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased")
    
    def __call__(self, text):
        token_res = self.tokenizer(text, padding='max_length', truncation=True)
        inputs = torch.stack([torch.tensor(token_res['input_ids']),
                              torch.tensor(token_res['attention_mask'])], dim=-1)
        
        return inputs


## vision datasets with torchvision

def load_vision_dataset(cfg):
    path = cfg['path']
    data_func = getattr(vis_datasets, cfg['name'])
    
    def load(is_train):
        dataset = data_func(root=path, train=is_train,
                            download=True, transform=None)
        features, labels = [], []
        for img, label in dataset:
            features.append(img)
            labels.append(label)
        
        return features, labels
    
    off_features, off_labels = load(is_train=True)
    on_features, on_labels = load(is_train=False)
    
    train_features, off_test_features, \
        train_labels, off_test_labels = train_test_split(off_features, off_labels,
                                                         test_size=cfg['test_size'],
                                                         random_state=cfg['random_state'])
    
    train_transform, test_transform = load_vision_transform(cfg['preprocess'])
    
    return {
        'train_features' : train_features,
        'train_labels'   : np.array(train_labels),
        'train_transform': train_transform,
        'test_features'  : off_test_features,
        'test_labels'    : np.array(off_test_labels),
        'test_transform' : test_transform,
        'on_features'    : on_features,
        'on_labels'      : np.array(on_labels),
    }


def load_vision_transform(cfg):
    transform_train = []
    
    if cfg.get('RandomResizedCrop', True):
        transform_train.append(transforms.RandomResizedCrop(cfg['crop']))
        transform_train.append(transforms.RandomHorizontalFlip())
    
    # TODO: Look more closely at this method
    if 'RandAugment' in cfg:
        transform_train.append(RandAugment(**cfg['RandAugment']))
    
    transform_train += [
        transforms.Resize(cfg['crop']),
        transforms.ToTensor(),
        transforms.Normalize(*cfg['normalize'])
    ]
    transform_train = transforms.Compose(transform_train)
    
    transform_test = transforms.Compose([
        transforms.Resize(cfg['crop']),
        transforms.CenterCrop(cfg['crop']),
        transforms.ToTensor(),
        transforms.Normalize(*cfg['normalize'])
    ])
    
    return transform_train, transform_test


## useful functions

def gen_cls_map(cfg):
    cls_map = {}
    for i, cls in enumerate(cfg['known_class']):
        cls_map[cls] = i
    cls_num = len(cls_map) + 1
    for cls in cfg['new_class']:
        cls_map[cls] = cls_num - 1
    
    print('map classes:', cls_map)
    
    return cls_map


def split_data(idx, part1_num, part2_num=0):
    idx_select = np.random.choice(idx, part1_num + part2_num, replace=False)
    idx_part1 = idx_select[:part1_num]
    idx_part2 = idx_select[part1_num:]
    return idx_part1, idx_part2
