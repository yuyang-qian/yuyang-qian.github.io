# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : fth.py
############################
from online.models.ogd import Base
import torch
import torch.nn as nn


class FTH(Base):
    def __init__(self, cfgs=None, seed=None, **alg_kwargs):
        super(FTH, self).__init__(cfgs, seed, **alg_kwargs)

    @torch.no_grad()
    def forward(self, target_data, prior_estimate, t):
        pred, estimate_loss, underlying_loss =\
            super(FTH, self).forward(target_data, prior_estimate, t)

        weights = self.model.get_weights()
        new_weights = (t * weights['priors'].data + prior_estimate) / (t+1)

        weights['priors'] = nn.Parameter(new_weights)
        self.model.load_state_dict(weights)
        # print('[Estimate]', prior_estimate)
        # print('[Avg Priors]', weights['priors'])
        return pred, estimate_loss, underlying_loss


class FTWH(Base):
    def __init__(self, cfgs=None, seed=None, **alg_kwargs):
        super(FTWH, self).__init__(cfgs, seed, **alg_kwargs)
        self.win_len = alg_kwargs.get("win_len", 100)
        self.queue = []
        print('Window length: {}'.format(self.win_len))

    @torch.no_grad()
    def forward(self, target_data, prior_estimate, t):
        pred, estimate_loss, underlying_loss = \
            super(FTWH, self).forward(target_data, prior_estimate, t)

        self.queue.append(prior_estimate)
        if len(self.queue) > self.win_len:
            self.queue.pop(0)

        weights = self.model.get_weights()
        new_weights = torch.stack(self.queue, dim=0).mean(dim=0)

        weights['priors'] = nn.Parameter(new_weights)
        self.model.load_state_dict(weights)

        return pred, estimate_loss, underlying_loss
