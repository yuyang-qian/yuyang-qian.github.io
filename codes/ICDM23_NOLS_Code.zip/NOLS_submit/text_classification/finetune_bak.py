# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : finetune.py
############################
import torch
from torch.utils.data import Dataset
from os.path import join
import numpy as np
import pandas as pd
import argparse

from sklearn.model_selection import train_test_split
from transformers import DistilBertForSequenceClassification, Trainer, TrainingArguments
from sklearn import preprocessing
from datasets import load_metric

class CustomDataset(Dataset):
    def __init__(self, encodings, labels):
        self.encodings = encodings
        self.labels = labels

    def __getitem__(self, idx):
        item = {key: torch.tensor(val[idx]).cuda() for key, val in self.encodings.items()}
        item['labels'] = torch.tensor(self.labels[idx]).cuda()
        return item

    def __len__(self):
        return len(self.labels)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--split_ratio",
                        type=float,
                        default=0.1)
    parser.add_argument('--output',
                        type=str,
                        default='tmp')
    parser.add_argument('--epoch',
                        type=int,
                        default=3)
    parser.add_argument('--warm_up',
                        type=int,
                        default=500)
    parser.add_argument('--nooverlap', action='store_true', default=False)
    args = parser.parse_args()

    root = './data/arxiv/bert/pretrain'
    tokens = torch.load(join(root, "token.bin"))['token']
    attention_mask = np.where(tokens != 0, 1, 0)
    infos = torch.load(join(root, "labels.bin"))
    labels = infos['labels']
    dates = infos['date']
    le = preprocessing.LabelEncoder()
    labels = le.fit_transform(labels)

    pd_data = pd.DataFrame({
        'idx': np.arange(tokens.shape[0]),
        'date': dates
    })
    pd_data = pd_data.sort_values(by='date')  # sort with time

    if args.nooverlap:

        pd_data.date = pd_data.date.astype(np.datetime64)
        data_train = pd_data[pd_data['date'].dt.day <= 5]

        data_train = data_train.groupby(data_train.date.dt.year).apply(
            lambda x: x.sample(n=min(len(x), 1500), replace=False, random_state=1214)).reset_index(drop=True)
        data_test = pd_data[pd_data['date'].dt.day > 25]
        data_test = data_test.groupby(data_test.date.dt.year).apply(
            lambda x: x.sample(n=min(len(x), 1500), replace=False, random_state=1214)).reset_index(drop=True)
        split_ratio = len(data_train) / len(pd_data)
        print('nooverlap')

    else:
        total_num = len(pd_data)
        split_ratio = args.split_ratio
        train_num = int(total_num * split_ratio)
        data_train, data_test = pd_data[:train_num], pd_data[train_num:min(len(pd_data), 2*train_num)]

    print('Train data: {}'.format(len(data_train)))
    print('Test data: {}'.format(len(data_test)))

    train_idx = data_train.idx.values
    test_idx = data_test.idx.values

    train_tokens, train_masks, train_labels = \
        tokens[train_idx], attention_mask[train_idx], labels[train_idx]
    test_tokens, test_masks, test_labels = \
        tokens[test_idx], attention_mask[test_idx], labels[test_idx]

    # train_tokens, test_tokens, \
    # train_masks, test_masks, \
    # train_labels, test_labels = train_test_split(tokens,
    #                                              attention_mask,
    #                                              labels,
    #                                              test_size=.2)

    train_dataset = CustomDataset(
        encodings={
            'input_ids': train_tokens,
            'attention_mask': train_masks,
        },
        labels=train_labels,
    )

    test_dataset = CustomDataset(
        encodings={
            'input_ids': test_tokens,
            'attention_mask': test_masks,
        },
        labels=test_labels,
    )

    metric = load_metric("accuracy")

    def compute_metrics(eval_pred):
        logits, labels = eval_pred
        predictions = np.argmax(logits, axis=-1)
        return metric.compute(predictions=predictions, references=labels)

    training_args = TrainingArguments(
        output_dir=args.output,  # output directory
        num_train_epochs=args.epoch,  # total number of training epochs
        per_device_train_batch_size=32,  # batch size per device during training
        per_device_eval_batch_size=64,  # batch size for evaluation
        warmup_steps=args.warm_up,  # number of warmup steps for learning rate scheduler
        weight_decay=0.01,  # strength of weight decay
        logging_dir='./logs',  # directory for storing logs
        logging_steps=10,
        dataloader_pin_memory=False,
        save_steps=500 // (0.5 / split_ratio),
        evaluation_strategy="epoch",
    )

    model = DistilBertForSequenceClassification.from_pretrained("distilbert-base-uncased", num_labels=23).cuda()

    trainer = Trainer(
        model=model,  # the instantiated 🤗 Transformers model to be trained
        args=training_args,  # training arguments, defined above
        train_dataset=train_dataset,  # training dataset
        eval_dataset=test_dataset,  # evaluation dataset
        compute_metrics = compute_metrics,
    )

    trainer.train()