# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : extract_feature.py
############################
import os
import pandas as pd
from os.path import join
from tqdm import tqdm
import torch
import torch.nn as nn
import numpy as np
from transformers import DistilBertForSequenceClassification
import argparse

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('model_path',
                        type=str,)
    parser.add_argument('output_path',
                        type=str, )
    args = parser.parse_args()
    root = '.'
    token_path = join(root, 'data/arxiv/bert/pretrain/token.bin')
    label_path = join(root, "data/arxiv/bert/pretrain/labels.bin")
    model_path = join(root, args.model_path)
    output_path = join(root, args.output_path)

    os.makedirs(output_path, exist_ok=True)

    padded = torch.load(token_path)['token']
    attention_mask = np.where(padded != 0, 1, 0)

    input_ids = torch.tensor(padded)
    attention_mask = torch.tensor(attention_mask)

    num = input_ids.shape[0]
    features = torch.zeros((num, 768), device='cuda')
    batch_size = 500

    model = DistilBertForSequenceClassification.from_pretrained(
                                        model_path, num_labels=23)
    model = model.cuda()
    input_ids = input_ids.cuda()
    attention_mask = attention_mask.cuda()

    with torch.no_grad():
        for i in tqdm(range(0, num, batch_size)):
            start = i
            end = min(i + batch_size, num)
            distilbert_output = model.distilbert(input_ids[start:end], attention_mask=attention_mask[start:end])
            hidden_state = distilbert_output[0]
            pooled_output = hidden_state[:, 0]
            pooled_output = model.pre_classifier(pooled_output)
            pooled_output = nn.ReLU()(pooled_output)
            features[start:end] = pooled_output

    labels = torch.load(label_path)

    torch.save({
        'features': features,
        'labels': labels['labels'],
        'date': labels['date']
    }, join(output_path, 'features.bin'))
