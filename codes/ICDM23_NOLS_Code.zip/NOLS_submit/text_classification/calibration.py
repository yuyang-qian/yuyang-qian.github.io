# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : calibration_bak.py
############################
import sys
sys.path.append("../EULAC")

import argparse
from os.path import join
import os
import torch
import numpy as np
import pandas as pd
from tqdm import tqdm

from torch.utils.data import DataLoader
from torch.utils.data import Dataset
from sklearn import preprocessing
from torch import nn, optim
import torch.nn.functional as F

from image_classification.temperature_scaling import ModelWithTemperature, _ECELoss
from transformers import DistilBertForSequenceClassification


class CustomDataset(Dataset):
    def __init__(self, encodings, labels):
        self.encodings = encodings
        self.labels = labels

    def __getitem__(self, idx):
        item = {key: torch.tensor(val[idx]) for key, val in self.encodings.items()}
        item['labels'] = torch.tensor(self.labels[idx])

        return item['input_ids'], item['attention_mask'], item['labels']

    def __len__(self):
        return len(self.labels)


class BertWithTemperature(ModelWithTemperature):
    def __init__(self, model):
        super(BertWithTemperature, self).__init__(model)

    def cal_logits(self, input_ids, attention_mask):
        distilbert_output = self.model.distilbert(input_ids, attention_mask=attention_mask)
        hidden_state = distilbert_output[0]
        pooled_output = hidden_state[:, 0]
        pooled_output = self.model.pre_classifier(pooled_output)
        pooled_output = nn.ReLU()(pooled_output)
        logits = self.model.classifier(pooled_output)

        return logits, pooled_output

    def forward(self, input):
        input_ids, attention_mask = input
        logits, features = self.cal_logits(input_ids, attention_mask)
        return self.temperature_scale(logits), features

    def set_temperature(self, valid_loader):
        """
        Tune the tempearature of the model (using the validation set).
        We're going to set it to optimize NLL.
        valid_loader (DataLoader): validation set loader
        """
        self.cuda()
        nll_criterion = nn.CrossEntropyLoss().cuda()
        ece_criterion = _ECELoss().cuda()

        # First: collect all the logits and labels for the validation set
        logits_list = []
        labels_list = []
        with torch.no_grad():
            for input_ids, attention_mask, label in tqdm(valid_loader):
                input_ids = input_ids.cuda()
                attention_mask = attention_mask.cuda()
                logits, _ = self.cal_logits(input_ids, attention_mask)
                logits_list.append(logits)
                labels_list.append(label)
            logits = torch.cat(logits_list).cuda()
            labels = torch.cat(labels_list).cuda()

        # Calculate NLL and ECE before temperature scaling
        before_temperature_nll = nll_criterion(logits, labels).item()
        before_temperature_ece = ece_criterion(logits, labels).item()
        print('Before temperature - NLL: %.3f, ECE: %.3f' % (before_temperature_nll, before_temperature_ece))

        # Next: optimize the temperature w.r.t. NLL
        optimizer = optim.LBFGS([self.temperature], lr=0.01, max_iter=50)

        def eval():
            optimizer.zero_grad()
            loss = nll_criterion(self.temperature_scale(logits), labels)
            loss.backward()
            return loss

        optimizer.step(eval)

        # Calculate NLL and ECE after temperature scaling
        after_temperature_nll = nll_criterion(self.temperature_scale(logits), labels).item()
        after_temperature_ece = ece_criterion(self.temperature_scale(logits), labels).item()
        print('Optimal temperature: %.3f' % self.temperature.item())
        print('After temperature - NLL: %.3f, ECE: %.3f' % (after_temperature_nll, after_temperature_ece))

        return self


def run(input_ids, attention_mask, labels, model):
    input_ids, attention_mask = input_ids.cuda(), attention_mask.cuda()
    labels = torch.from_numpy(labels).cuda()
    num = input_ids.shape[0]
    batch_size = 500

    _hard_preds = []
    _soft_preds = []
    _labels = []

    correct = 0

    with torch.no_grad():
        for i in tqdm(range(0, num, batch_size)):
            start = i
            end = min(i + batch_size, num)

            output, features = model([input_ids[start: end], attention_mask[start: end]])
            targets = labels[start: end]

            soft_pred = F.softmax(output, dim=-1)
            hard_pred = output.argmax(-1)

            _labels.append(targets)
            _soft_preds.append(soft_pred)
            _hard_preds.append(hard_pred)

            correct += hard_pred.eq(targets.view_as(hard_pred)).sum().item()

        print('\nAccuracy: {}/{} ({:.0f}%)'.format(
            correct, num,
            100. * correct / num))

    labels = torch.cat(_labels, 0)
    hard_preds = torch.cat(_hard_preds).cpu().detach()
    soft_preds = torch.cat(_soft_preds).cpu().detach()

    return labels, hard_preds, soft_preds

def get_data(path):
    data = torch.load(path)
    tokens, dates, labels = \
        data['token'], data['date'], data['label']
    attention_mask = np.where(tokens != 0, 1, 0)
    tokens = torch.tensor(tokens)
    attention_mask = torch.tensor(attention_mask)

    return tokens, attention_mask, dates, labels

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('model_path',
                        type=str, )
    parser.add_argument('output_path',
                        type=str, )
    args = parser.parse_args()
    root = './data/arxiv/bert/pretrain/splits_1'

    arxiv_tokens, arxiv_masks, arxiv_dates, arxiv_labels = \
        get_data(join(root, 'arxiv_data.pt'))

    val_tokens, val_masks, val_dates, val_labels = \
        get_data(join(root, 'val_data.pt'))

    le = preprocessing.LabelEncoder()
    arxiv_labels = le.fit_transform(arxiv_labels)
    val_labels = le.transform(val_labels)

    val_dataset = CustomDataset(
        encodings={
            'input_ids': val_tokens,
            'attention_mask': val_masks,
        },
        labels=val_labels,
    )
    val_dataloader = DataLoader(val_dataset,
                                num_workers=2,
                                batch_size=500,
                                shuffle=True,
                                pin_memory=True)

    model_path = join(root, args.model_path)
    output_path = join(root, args.output_path)

    os.makedirs(output_path, exist_ok=True)

    ori_model = DistilBertForSequenceClassification.from_pretrained(
        model_path, num_labels=23)

    model = BertWithTemperature(ori_model)
    model.set_temperature(val_dataloader)
    model.eval()

    labels, hard_preds, soft_preds = run(arxiv_tokens, arxiv_masks, arxiv_labels, model)

    torch.save({
        'soft_preds': soft_preds,
        'hard_preds': hard_preds,
        'ori_labels': arxiv_labels,
        'labels': labels,
        'date': arxiv_dates
    }, join(args.output_path, 'features.bin'))