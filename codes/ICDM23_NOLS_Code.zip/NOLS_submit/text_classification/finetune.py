# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : finetune.py
############################
import torch
from torch.utils.data import Dataset
from os.path import join
import numpy as np
import pandas as pd
import argparse

from sklearn.model_selection import train_test_split
from transformers import DistilBertForSequenceClassification, Trainer, TrainingArguments
from sklearn import preprocessing
from datasets import load_metric


class CustomDataset(Dataset):
    def __init__(self, encodings, labels):
        self.encodings = encodings
        self.labels = labels

    def __getitem__(self, idx):
        item = {key: torch.tensor(val[idx]).cuda() for key, val in self.encodings.items()}
        item['labels'] = torch.tensor(self.labels[idx]).cuda()
        return item

    def __len__(self):
        return len(self.labels)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input",
                        type=str
                        )
    parser.add_argument('--output',
                        type=str,
                        default='tmp')
    parser.add_argument('--epoch',
                        type=int,
                        default=3)
    parser.add_argument('--warm_up',
                        type=float,
                        default=0.2)
    parser.add_argument('--lr',
                        type=float,
                        default=5e-5)
    args = parser.parse_args()

    root = './data/arxiv/bert/pretrain'
    train_data = torch.load(join(root, args.input, 'train_data.pt'))
    val_data = torch.load(join(root, args.input, "val_data.pt"))
    train_tokens, train_dates, train_labels = \
        train_data['token'], train_data['date'], train_data['label']
    val_tokens, val_dates, val_labels = \
        val_data["token"], val_data["date"], val_data['label']

    train_masks = np.where(train_tokens != 0, 1, 0)
    val_masks = np.where(val_tokens != 0, 1, 0)

    le = preprocessing.LabelEncoder()
    train_labels = le.fit_transform(train_labels)
    val_labels = le.transform(val_labels)

    train_dataset = CustomDataset(
        encodings={
            'input_ids': train_tokens,
            'attention_mask': train_masks,
        },
        labels=train_labels,
    )

    test_dataset = CustomDataset(
        encodings={
            'input_ids': val_tokens,
            'attention_mask': val_masks,
        },
        labels=val_labels,
    )

    metric = load_metric("accuracy")

    def compute_metrics(eval_pred):
        logits, labels = eval_pred
        predictions = np.argmax(logits, axis=-1)
        return metric.compute(predictions=predictions, references=labels)

    training_args = TrainingArguments(
        output_dir=args.output,  # output directory
        num_train_epochs=args.epoch,  # total number of training epochs
        per_device_train_batch_size=32,  # batch size per device during training
        per_device_eval_batch_size=64,  # batch size for evaluation
        warmup_ratio=args.warm_up,  # number of warmup steps for learning rate scheduler
        weight_decay=0.01,  # strength of weight decay
        logging_dir='./logs',  # directory for storing logs
        logging_steps=10,
        dataloader_pin_memory=False,
        learning_rate=args.lr,
        save_strategy='epoch',
        evaluation_strategy="epoch",
        fp16=True,
    )

    model = DistilBertForSequenceClassification.from_pretrained("distilbert-base-uncased", num_labels=23).cuda()

    trainer = Trainer(
        model=model,  # the instantiated 🤗 Transformers model to be trained
        args=training_args,  # training arguments, defined above
        train_dataset=train_dataset,  # training dataset
        eval_dataset=test_dataset,  # evaluation dataset
        compute_metrics = compute_metrics,
    )

    trainer.train()
