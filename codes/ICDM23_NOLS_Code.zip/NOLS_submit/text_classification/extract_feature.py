# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : extract_feature.py
############################
import os
import pandas as pd
from os.path import join
from tqdm import tqdm
import torch
import torch.nn as nn
import numpy as np
from transformers import DistilBertForSequenceClassification
import argparse


def extract(args, path):
    root = './data/arxiv/bert'
    data_path = join(root, args.input_path, path)
    model_path = join(root, args.model_path)
    output_path = join(root, args.output_path)

    os.makedirs(output_path, exist_ok=True)

    data = torch.load(data_path)
    padded = data['token']
    attention_mask = np.where(padded != 0, 1, 0)

    input_ids = torch.tensor(padded)
    attention_mask = torch.tensor(attention_mask)

    num = input_ids.shape[0]
    features = torch.zeros((num, 768), device='cuda')
    batch_size = 500

    model = DistilBertForSequenceClassification.from_pretrained(
        model_path, num_labels=23)
    model = model.cuda()
    input_ids = input_ids.cuda()
    attention_mask = attention_mask.cuda()

    with torch.no_grad():
        for i in tqdm(range(0, num, batch_size)):
            start = i
            end = min(i + batch_size, num)
            distilbert_output = model.distilbert(input_ids[start:end], attention_mask=attention_mask[start:end])
            hidden_state = distilbert_output[0]
            pooled_output = hidden_state[:, 0]
            pooled_output = model.pre_classifier(pooled_output)
            pooled_output = nn.ReLU()(pooled_output)
            features[start:end] = pooled_output

    torch.save({
        'features': features,
        'labels': data['label'],
        'date': data['date']
    }, join(output_path, '{}_features.bin'.format(path.split('.')[0])))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--input_path',
                        type=str,
                        default="pretrain/splits_1")
    parser.add_argument('--model_path',
                        type=str,
                        default="expr_0217/splits_1/lr_1e-4_epoch_3_warmup_0.2/checkpoint-2157")
    parser.add_argument('--output_path',
                        type=str,
                        default="pretrain/splits_1/features/lr_1e-4_epoch_3_warmup_0.2/checkpoint-2157")
    args = parser.parse_args()

    for path in ['train_data.pt', 'val_data.pt', 'arxiv_data.pt']:
        extract(args, path)
