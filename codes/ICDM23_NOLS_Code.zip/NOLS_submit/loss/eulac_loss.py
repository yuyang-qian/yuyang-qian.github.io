# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : eulac_loss.py
############################

from torch import nn
import torch
import torch.nn.functional as F


def cal_loss_vector(output, func_name):
    if func_name == 'CE':
        loss = -F.log_softmax(output, dim=1)
    elif func_name == 'GCE':
        q = 0.7
        softmax = torch.softmax(output, dim=-1)
        loss = (1 - softmax.pow(q)) / q
    elif func_name == 'Sigmoid':
        num_classes = output.shape[1]
        logit_value = output
        loss = torch.zeros(output.size()).cuda()
        for k in range(num_classes):
            labels = -torch.ones(output.size()).cuda()
            labels[:, k] = 1
            loss_vector = torch.sigmoid(-labels * logit_value)
            coeff = torch.ones(output.size()).cuda() / (num_classes - 1)
            coeff[:, k] = 1
            loss[:, k] = (loss_vector * coeff).sum(dim=1)
    else:
        raise NotImplementedError

    return loss


class URELoss(nn.Module):
    """URE Loss.
    Attributes:
        num_classes (int): number of classes.
        loss_func (str): loss function.
        prior (float): prior probability of known class.
        start_ure (int): start epoch of URE.
        nn_correction (str): correction method.
    """
    def __init__(self, **kwargs):
        super(URELoss, self).__init__()
        self.num_classes = kwargs.get('num_classes', 7)
        self.loss_func = kwargs.get('func', 'Sigmoid')
        self.prior = kwargs['prior']

        self.sup_loss = nn.NLLLoss(reduction='mean')

        self.start_ure = kwargs.get('start_ure', 0)
        self.nn_correction = kwargs.get('nn_correction', None)

    def forward(self, output, target, label_mask, epoch):
        # here logits are non-negative
        logits = cal_loss_vector(output, self.loss_func)

        l_logits, l_target = \
            logits[label_mask], target[label_mask]
        u_logits = logits[~label_mask]

        # assert (l_target.unique().shape[0] ==
        #         self.num_classes - 1)

        # known classes
        # input of nll loss is negative values
        l_known_loss = self.sup_loss(-l_logits, l_target)

        # unknown class
        unknown_idx = self.num_classes - 1
        u_unknown_loss = u_logits[:, unknown_idx].mean()
        l_unknown_loss = l_logits[:, unknown_idx].mean()

        unknown_loss = u_unknown_loss - \
                       self.prior * l_unknown_loss
        if self.nn_correction is not None:
            unknown_loss = self.correction(unknown_loss)

        ure_loss = l_known_loss
        if epoch > self.start_ure:
            ure_loss = l_known_loss * self.prior +\
                       unknown_loss

        return {
            'known_loss': l_known_loss,
            'unknown_loss': unknown_loss,
            'loss': ure_loss,
        }

    def correction(self, risk):
        if risk < 0:
            if self.nn_correction == 'ABS':
                risk = -risk
            elif self.nn_correction == 'ReLU':
                risk = torch.max(risk, torch.tensor(0, device=risk.device))
            elif self.nn_correction == 'LReLU':
                risk = -self.l_relu_ratio * risk
            else:
                raise NotImplementedError

        return risk