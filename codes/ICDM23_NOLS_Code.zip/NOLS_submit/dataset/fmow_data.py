# /usr/bin/env python
# -*- coding: utf-8 -*-
import pickle
import torch
from tqdm import trange

from utils.shift_simulate import *


class FMoWTrainDataset():
    """
    For FMoW Train dataset
    """
    
    def __init__(self, cfgs, rng=None, years=None, num_classes=2, transform=None, label_transform=None, desc=''):
        
        if rng is None:
            rng = np.random.default_rng()
        self.rng = rng
        
        path = cfgs['source_data']['path']
        
        years_for_pretrain = cfgs['years_for_pretrain']
        years_start = cfgs['years_start']
        years_end = cfgs['years_end']
        # data = torch.load(path)
        f_read = open(path, 'rb')
        all_data = pickle.load(f_read)
        f_read.close()
        print('Reading data in {} finished.'.format(path))
        
        self.data = None
        self.labels = []
        for i in trange(years_start, years_start + years_for_pretrain, desc='Loading offline FMoW data'):
            for j in range(len(all_data[i]['feature'])):
                if self.data is None:
                    self.data = torch.from_numpy(all_data[i]['feature'][j]).reshape(1, -1)
                    self.labels.append(all_data[i]['label'][j])
                else:
                    self.data = torch.cat([self.data, torch.from_numpy(all_data[i]['feature'][j]).reshape(1, -1)], dim=0)
                    self.labels.append(all_data[i]['label'][j])
        self.labels = np.array(self.labels).reshape(-1, 1)
        # self.data = data
        
        self.transform = transform
        self.label_transform = label_transform
        self.num_classes = num_classes
        self.desc = desc
        self.years = years
        
        self.info = {
            'dim'    : all_data[years_start]['feature'][0].shape[0],
            'cls_num': 62,
            'is_cls' : True
        }
        self.label_mask = np.ones(len(self.data), dtype=np.bool_)
    
    def _pre_process(self, img):  # Pre-processing one image.
        # img = np.array(img).astype(np.float32)
        return img
    
    def __getitem__(self, idx):
        img, target = self.data[idx], int(self.labels[idx])
        # doing this so that it is consistent with all other datasets
        # to return a PIL Image
        
        img = self._pre_process(img)
        
        if self.transform is not None:
            img = self.transform(img)
        
        if self.label_transform is not None:
            target = self.label_transform(target)
        
        # return img, target, idx
        return img, target, self.label_mask[idx]
    
    def __len__(self):
        return len(self.data)


class FMoWTestDataset():
    """
    For FMoW Test dataset
    """
    
    def __init__(self, cfgs, info, rng=None, years=None, num_classes=2, transform=None, label_transform=None, desc=''):
        if rng is None:
            rng = np.random.default_rng()
        self.rng = rng
        
        path = cfgs['source_data']['path']
        
        years_for_pretrain = cfgs['years_for_pretrain']
        years_start = cfgs['years_start']
        years_end = cfgs['years_end']
        years_interval = cfgs['years_interval']
        # data = torch.load(path)
        f_read = open(path, 'rb')
        all_data = pickle.load(f_read)
        f_read.close()
        print('Reading data in {} finished.'.format(path))
        self.data = []
        self.labels = []
        self.years = []
        if cfgs['per_round_num'] >= 0:
            tmp_data = None
            tmp_label = []
            tmp_years = []
            tmp_num = 0
            for i in range(years_start + years_interval, years_end + 1):
                for j in range(len(all_data[i]['feature'])):
                    if tmp_data is None:
                        tmp_data = torch.from_numpy(all_data[i]['feature'][j]).reshape(1, -1)
                        tmp_label.append(all_data[i]['label'][j])
                        tmp_years.append([i])
                    else:
                        tmp_data = torch.cat([tmp_data, torch.from_numpy(all_data[i]['feature'][j]).reshape(1, -1)], dim=0)
                        tmp_label.append(all_data[i]['label'][j])
                        tmp_years.append([i])
                    tmp_num += 1
                    
                    if tmp_num == cfgs['per_round_num']:
                        tmp_label = torch.tensor(tmp_label).reshape(-1, 1)
                        tmp_years = torch.tensor(tmp_years).reshape(-1, 1)
                        self.data.append(tmp_data)
                        self.labels.append(tmp_label)
                        self.years.append(tmp_years)
                        tmp_data = None
                        tmp_label = []
                        tmp_years = []
                        tmp_num = 0
        else:
            for i in range(years_start + years_for_pretrain, years_end + 1):
                tmp_data = None
                tmp_label = []
                tmp_years = []
                for j in range(len(all_data[i]['feature'])):
                    if tmp_data is None:
                        tmp_data = torch.from_numpy(all_data[i]['feature'][j]).reshape(1, -1)
                        tmp_label.append(all_data[i]['label'][j])
                        tmp_years.append([i])
                    else:
                        tmp_data = torch.cat([tmp_data, torch.from_numpy(all_data[i]['feature'][j]).reshape(1, -1)], dim=0)
                        tmp_label.append(all_data[i]['label'][j])
                        tmp_years.append([i])
                tmp_label = torch.tensor(tmp_label).reshape(-1, 1)
                tmp_years = torch.tensor(tmp_years).reshape(-1, 1)
                self.data.append(tmp_data)
                self.labels.append(tmp_label)
                self.years.append(tmp_years)
        
        self.transform = transform
        self.label_transform = label_transform
        self.num_classes = num_classes
        self.desc = desc
        # self.years = years
        
        self.info = info
        self.label_mask = np.zeros(len(self.data), dtype=np.bool_)
    
    def _pre_process(self, img):  # Pre-processing one image.
        # img = np.array(img).astype(np.float32)
        return img
    
    def __getitem__(self, idx):
        img, target = self.data[idx], self.labels[idx]
        # doing this so that it is consistent with all other datasets
        # to return a PIL Image
        
        # img = self._pre_process(img)
        #
        # if self.transform is not None:
        #     img = self.transform(img)
        #
        # if self.label_transform is not None:
        #     target = self.label_transform(target)
        
        # return img, target, self.years[idx]
        return img, target, np.zeros(img.shape[0], dtype=np.bool_)
    
    def __len__(self):
        return len(self.data)
    
    def get_eval(self, t):
        img, target = self.data[t], self.labels[t]
        # doing this so that it is consistent with all other datasets
        # to return a PIL Image
        
        # img = self._pre_process(img)
        #
        # if self.transform is not None:
        #     img = self.transform(img)
        #
        # if self.label_transform is not None:
        #     target = self.label_transform(target)
        
        return img, target, self.years[t]
        # return data, label, priors
