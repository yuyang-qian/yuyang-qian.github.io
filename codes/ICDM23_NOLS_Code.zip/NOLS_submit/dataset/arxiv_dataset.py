# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : arxiv_dataset.py
############################
import numpy as np
import pandas as pd
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from collections import defaultdict

import torch
import torch.utils.data as data

from utils.shift_simulate import *


class CustomDataset(data.Dataset):
    def __init__(self, data, labels, datetime):
        self.data = data
        self.labels = labels
        self.datetime = datetime.astype(np.datetime64)
        
        if isinstance(self.data, np.ndarray):
            self.data = torch.from_numpy(self.data)
        self.data = self.data.float()
    
    def __getitem__(self, index):
        pass
    
    def __len__(self):
        return len(self.data)


class TrainDataset(CustomDataset):
    def __init__(self, data, labels, datetime, **kwargs):
        super(TrainDataset, self).__init__(data, labels, datetime)
        
        if 'sample' in kwargs:
            self.rng = np.random.default_rng(kwargs.get("seed", 1214))
            sample_num = kwargs['sample']
            idx = self.rng.permutation(len(self.data))[:sample_num]
            
            self.data = self.data[idx]
            self.labels = self.labels[idx]
            self.datetime = self.datetime[idx]
    
    def __getitem__(self, index):
        return self.data[index], self.labels[index]


class TestDataset(CustomDataset):
    def __init__(self, data, labels, datetime, **kwargs):
        super(TestDataset, self).__init__(data, labels, datetime)
        self.agrr_by = kwargs.get('agrr_by', 'number')  # number or day
        self.interval = kwargs.get("interval", 30)
        self.ptr = 0
        print('Online Batch Size: {}'.format(self.interval))
        if isinstance(self.labels, np.ndarray):
            self.labels = torch.from_numpy(self.labels)
        
        if self.agrr_by in ['date', 'month']:
            self.pd_data = pd.DataFrame({
                'datetime': self.datetime,
                'index'   : np.arange(len(self.datetime)),
                'label'   : self.labels,
            })
            self.dates = sorted(np.unique(self.datetime))
            self.cache = []
        
        if self.agrr_by == 'month':
            day_interval = kwargs.get("day_interval", 30)
            day_interval = np.timedelta64(day_interval, 'D')
            self.dates_interval = np.arange(start=self.dates[0],
                                            stop=self.dates[-1],
                                            step=day_interval)
    
    def __getitem__(self, t):
        if self.agrr_by == 'number':
            X = self.data[self.ptr:self.ptr + self.interval]
            y = self.labels[self.ptr:self.ptr + self.interval]
            self.ptr += self.interval
        elif self.agrr_by == 'date':
            if len(self.cache) == 0:
                sample_data = self.pd_data[self.pd_data['datetime'] ==
                                           self.dates[self.ptr]]
                self.cache = self.stratified_split(sample_data, self.interval)
                self.ptr += 1
            
            data = self.cache.pop(0)
            idx = data['index'].values
            X = self.data[idx]
            y = self.labels[idx]
        elif self.agrr_by == "month":
            if len(self.cache) == 0:
                curr_interval = np.arange(start=self.dates_interval[self.ptr],
                                          stop=self.dates_interval[self.ptr + 1],
                                          step=np.timedelta64(1, 'D'))
                self.ptr += 1
                sample_data = self.pd_data[self.pd_data['datetime'].isin(curr_interval)]
                self.cache = self.stratified_split(sample_data, self.interval)
            
            data = self.cache.pop(0)
            idx = data['index'].values
            X = self.data[idx]
            y = self.labels[idx]
        else:
            raise NotImplementedError
        
        return X, y, None
    
    def stratified_split(self, data, num_samples):
        num_parts = len(data) // num_samples
        
        results = []
        if num_parts <= 1:
            results.append(data)
        else:
            reserved = data
            try:
                for i in range(num_parts - 1):
                    stratified_sample, reserved = train_test_split(reserved, train_size=num_samples,
                                                                   stratify=reserved[['label']])
                    results.append(stratified_sample)
            except BaseException:
                pass
            finally:
                results.append(reserved)
        
        return results


class SimulateTestDataset(CustomDataset):
    def __init__(self, data, labels, datetime, **kwargs):
        super(SimulateTestDataset, self).__init__(data, labels, datetime)
        self.rng = np.random.default_rng(kwargs.get("seed", 1214))
        self.shift_gen = eval(kwargs['shift']['type'])(rng=self.rng,
                                                       **kwargs['shift']['kwargs'])
        self.batch_size = kwargs['batch_size']
        
        self.data_menu = {}
        for i in np.unique(self.labels):
            self.data_menu[i] = np.where(self.labels == i)[0]
    
    def __getitem__(self, t):
        priors = self.shift_gen(t)
        cls_num = len(priors)
        dim = self.data.shape[1]
        priors /= np.sum(priors)
        labels = self.rng.choice(cls_num, size=self.batch_size, p=priors)
        data = torch.zeros((self.batch_size, dim), device=self.data.device)
        
        for i in range(cls_num):
            idx = (labels == i)
            num = idx.sum()
            data_idx_idx = self.rng.choice(len(self.data_menu[i]), size=num, replace=False)
            
            data_idx = self.data_menu[i][data_idx_idx]
            data[idx] = self.data[data_idx]
        
        return data, torch.from_numpy(labels), priors


class SmoothTestDataset(CustomDataset):
    def __init__(self, data, labels, datetime, **kwargs):
        super(SmoothTestDataset, self).__init__(data, labels, datetime)
        self.rng = np.random.default_rng(kwargs.get("seed", 1214))
        self.pd_data = pd.DataFrame({
            'datetime': self.datetime,
            'index'   : np.arange(len(self.datetime)),
            'label'   : self.labels,
        })
        # months = self.pd_data.datetime.dt.to_period("M")
        # self.grouped_data = self.pd_data.groupby(months)
        years = self.pd_data.datetime.dt.to_period("Y")
        self.grouped_data = self.pd_data.groupby(years)
        self.iterator = iter(self.grouped_data)
        # next(self.iterator)
        
        self.batch_size = kwargs.get("batch_size", 100)
        self.round = kwargs.get('T', 10000)
        # self.iter_num = self.round // (len(self.grouped_data) - 1) + 1
        self.iter_num = self.round // (len(self.grouped_data)) + 1
        print('Iter num: {}'.format(self.iter_num))
        self.cls_num = kwargs.get("cls_num", 23)
        self.dim = self.data.shape[1]
        
        self.start_priors = self.count_priors(
            self.pd_data[self.pd_data.datetime.dt.year == 2013].label.values
        )
        self.end_priors = self.count_priors(
            self.pd_data[self.pd_data.datetime.dt.year == 2021].label.values
        )
        kwargs['shift']['kwargs'].update(
            {
                'q1': self.start_priors,
                'q2': self.end_priors,
            }
        )
        print(kwargs['shift']['kwargs'])
        self.shift_gen = eval(kwargs['shift']['type'])(rng=self.rng,
                                                       **kwargs['shift']['kwargs'])
        self.combine_ratio = kwargs.get('combine_ratio', 0.5)
        
        self.month_priors = None
        self.data_menu = {}
        self.ptr = 0
    
    def count_priors(self, labels):
        count = np.bincount(labels, minlength=self.cls_num)
        return count / count.sum()
    
    def __getitem__(self, t):
        if t % self.iter_num == 0:
            data = next(self.iterator)[1]
            idx = data.index.values
            month_labels = self.labels[idx]
            
            self.month_priors = self.count_priors(month_labels)
            
            self.data_menu = defaultdict(list)
            for i in np.unique(self.labels):
                self.data_menu[i] = idx[month_labels == i]
        
        aux_priors = self.shift_gen(t)
        priors = self.month_priors * self.combine_ratio + \
                 aux_priors * (1 - self.combine_ratio)
        
        results = self.sample_batch(priors)
        
        return results
        # return None, None, priors
    
    def sample_batch(self, priors):
        priors /= np.sum(priors)
        labels = self.rng.choice(self.cls_num, size=self.batch_size, p=priors)
        data = torch.zeros((self.batch_size, self.dim), device=self.data.device)
        
        for i in range(self.cls_num):
            idx = (labels == i)
            num = idx.sum()
            replace = (len(self.data_menu[i]) < num)
            data_idx_idx = self.rng.choice(len(self.data_menu[i]), size=num, replace=replace)
            
            data_idx = self.data_menu[i][data_idx_idx]
            data[idx] = self.data[data_idx]
        
        return data, torch.from_numpy(labels), priors


def label_encode(labels, discretization=False):
    if discretization:
        decrease = ['cs.AI', 'cs.IT', 'cs.LO', 'cs.NI']
        increase = ['cs.CL', 'cs.CV', 'cs.LG']
        results = np.zeros(len(labels)).astype(np.int64)
        
        for cls in decrease:
            results[labels == cls] = 1
        for cls in increase:
            results[labels == cls] = 2
        labels = results
        cls_names = ['FIX', 'DECREASE', 'INCREASE']
    else:
        le = preprocessing.LabelEncoder()
        labels = le.fit_transform(labels)
        cls_names = le.classes_
    
    return labels, cls_names


def get_data(labels, features, dates, sort_idx, cfgs, bbox=False):
    total_num = len(sort_idx)
    split_ratio = cfgs.get("train_ratio", 0.5)
    print('Split ratio: {}'.format(split_ratio))
    train_num = int(total_num * split_ratio)
    idx_train, idx_test = sort_idx[:train_num], sort_idx[train_num:]
    
    features_train, features_test = features[idx_train], features[idx_test]
    labels_train, labels_test = labels[idx_train], labels[idx_test]
    dates_train, dates_test = dates[idx_train], dates[idx_test]
    
    train_set = TrainDataset(
        data=features_train,
        labels=labels_train,
        datetime=dates_train,
        **cfgs['source_data'],
    )
    
    if bbox:
        test_set = TrainDataset(
            data=features_test,
            labels=labels_test,
            datetime=dates_test,
        )
    else:
        dataset_type = cfgs['online_data'].get('type', 'TestDataset')
        test_set = eval(dataset_type)(
            data=features_test,
            labels=labels_test,
            datetime=dates_test,
            seed=cfgs['seed'],
            **cfgs['online_data']
        )
        # if 'shift' in cfgs['online_data']:
        #     test_set = SimulateTestDataset(
        #         data=features_test,
        #         labels=labels_test,
        #         datetime=dates_test,
        #         **cfgs['online_data']
        #     )
        # else:
        #     test_set = TestDataset(
        #         data=features_test,
        #         labels=labels_test,
        #         datetime=dates_test,
        #         **cfgs['online_data']
        #     )
    
    cls_num = cfgs['online_data'].get('cls_num', 23)
    count = np.bincount(labels_train, minlength=cls_num)
    priors = count / count.sum()
    
    return train_set, test_set, priors


def get_tfidf_data(cfgs, bbox=False):
    data = np.load(cfgs['source_data']['path'], allow_pickle=True)  # load npz
    features = data['features'][()].todense()
    dates = data['datetime'][()]
    labels, cls_name = label_encode(data['labels'][()])
    
    pd_data = pd.DataFrame({
        'idx' : np.arange(features.shape[0]),
        'date': dates
    })
    pd_data = pd_data.sort_values(by='date')  # sort with time
    sort_idx = pd_data.idx.values
    
    train_set, test_set, init_priors = get_data(labels=labels,
                                                features=features,
                                                dates=dates,
                                                sort_idx=sort_idx,
                                                cfgs=cfgs,
                                                bbox=bbox)
    
    info = {
        'cls_name'   : cls_name,
        'cls_num'    : len(cls_name),
        'dim'        : features.shape[1],
        'init_priors': init_priors,
    }
    
    print('Train data: {}'.format(len(train_set)))
    print('Test data: {}'.format(len(test_set)))
    print(info)
    
    return train_set, test_set, info


def get_bert_data(cfgs, bbox=False, nooverlap=False):
    data = torch.load(cfgs['source_data']['path'], map_location='cpu')
    if 'soft_preds' in data:
        features = data['soft_preds']
    else:
        features = data['features']
    dates = data['date']
    labels = data['labels']
    
    if 'filter' in cfgs:
        masks = np.isin(labels, cfgs['filter'])
        features, dates, labels = features[masks], dates[masks], labels[masks]
    
    pd_data = pd.DataFrame({
        'idx' : np.arange(features.shape[0]),
        'date': dates.astype(np.datetime64),
    })
    
    if cfgs.get("label_encode", True):
        labels, cls_name = label_encode(labels, discretization=cfgs.get("discretization", False))
    else:
        cls_name = np.unique(labels)
    print(cls_name)
    # if nooverlap:
    #     print('Remove Day 1 - 5')
    #     pd_data = pd_data[pd_data.date.dt.day > 5]
    
    pd_data = pd_data.sort_values(by='date')  # sort with time
    sort_idx = pd_data.idx.values
    
    train_set, test_set, init_priors = get_data(labels=labels,
                                                features=features,
                                                dates=dates,
                                                sort_idx=sort_idx,
                                                cfgs=cfgs,
                                                bbox=bbox)
    
    info = {
        'cls_name'   : cls_name,
        'cls_num'    : len(cls_name),
        'dim'        : features.shape[1],
        'init_priors': init_priors,
    }
    
    print('Train data: {}'.format(len(train_set)))
    print('Test data: {}'.format(len(test_set)))
    print(info)
    
    return train_set, test_set, info


if __name__ == "__main__":
    # cfgs = {
    #     'source_data':
    #         {
    #             'path': './data/arxiv/tfidf/arxiv.npz'
    #         },
    #     'online_data':
    #         {
    #             'agrr_by': 'number',
    #             'interval': 10,
    #         }
    # }
    #
    # train_set, test_set, info = get_tfidf_data(cfgs)
    
    cfgs = {
        'source_data':
            {
                'path': './data/arxiv/bert/finetune/data_finetune.bin'
            },
        'online_data':
            {
                'type'         : 'SmoothTestDataset',
                'agrr_by'      : 'number',
                'interval'     : 10,
                'batch_size'   : 100,
                'T'            : 10000,
                'shift'        : {
                    'type'  : 'HybridShift',
                    'kwargs': {
                        'T'        : 10000,
                        'amptitude': 0.5,
                        'noise_amp': 0.1,
                        'period'   : 20,
                        'q1'       : np.ones(23) / 23,
                        'q2'       : np.array([0] * 22 + [1])
                    }
                },
                'combine_ratio': 0,
            },
        'train_ratio': 0.1
    }
    
    train_set, test_set, info = get_bert_data(cfgs)
    
    from tqdm import tqdm
    
    all_priors = []
    for i in tqdm(range(10000)):
        data, labels, priors = test_set[i]
        all_priors.append(priors)
    
    diff = np.abs(np.diff(all_priors, axis=0))
    print(np.sum(diff))
