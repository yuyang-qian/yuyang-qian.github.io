# /usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : wrapper.py
############################
from dataset.toy_data import ToyTrainSet, ToyTestSet
from dataset.arxiv_dataset import get_tfidf_data, get_bert_data
from dataset.table_data import get_table_data
from dataset.image_data import get_img_data
from dataset.fmow_data import FMoWTrainDataset, FMoWTestDataset


def get_dataset(name, cfgs, rng):
    train_set, test_set, info = None, None, {}
    if name == 'toy':
        train_set = ToyTrainSet(cfgs, rng=rng)
        info = train_set.info
        test_set = ToyTestSet(cfgs, info, rng=rng)
    elif name == 'arxiv':
        type = cfgs.get('type', 'bert')
        if type == "bert":
            train_set, test_set, info = get_bert_data(cfgs,
                                                      nooverlap=cfgs.get('nooverlap', False))
        elif type == "tfidf":
            train_set, test_set, info = get_tfidf_data(cfgs)
        else:
            raise NotImplementedError
    elif name == "table":
        train_set, test_set, info = get_table_data(cfgs)
    elif name == "image":
        train_set, test_set, info = get_img_data(cfgs)
    elif name == 'FMoW':
        train_set = FMoWTrainDataset(cfgs, rng=rng)
        info = train_set.info
        test_set = FMoWTestDataset(cfgs, info, rng=rng)
    
    else:
        raise NotImplementedError
    
    return train_set, test_set, info
