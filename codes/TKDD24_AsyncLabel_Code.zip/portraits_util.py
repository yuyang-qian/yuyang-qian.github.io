import numpy as np
import torch
from scipy import io
import os
from torchvision import datasets, transforms

from data import LabeledDataset


def shuffle(xs, ys):
    indices = list(range(len(xs)))
    np.random.shuffle(indices)
    return xs[indices], ys[indices]


def get_datasets(filename, t_u, E_delay, expected, args):
    X, Y = load_portraits_data(filename, t_u)
    train_datasets = []
    test_datasets = []
    # received_datasets = []
    dataset_num = len(t_u)
    
    s_point = 0
    for i in range(dataset_num):
        # test_num = t_u[i] // 10
        train_dataset = LabeledDataset(
            X[s_point: s_point + t_u[i]],
            Y[s_point: s_point + t_u[i]],
            domain_idx=i,
            transform=transforms.Compose(_PORTRAITS_TRAIN_TRANSFORMS),
            num_classes=2
        )
        
        s_point += t_u[i]
        
        train_datasets.append(train_dataset)
        # if i >= delay:
        # 	received_datasets.append(train_datasets[i - delay])
        # else:
        # 	received_datasets.append(None)
    
    if not expected:
        received_datasets = [None] * E_delay + train_datasets
    else:
        # receives = [None] * (len(train_datasets) + delay + 10)
        # received_datasets = []
        # for i in range(len(train_datasets)):
        # 	tmp = np.random.randint(delay - 2, delay + 3)
        # 	if receives[i + tmp] is None:
        # 		receives[i + tmp] = [train_datasets[i]]
        # 	else:
        # 		receives[i + tmp].append(train_datasets[i])
        #
        # for i, rs in enumerate(receives):
        # 	if i < delay and rs is None:
        # 		received_datasets.append(None)
        # 		continue
        # 	if rs:
        # 		for r in rs:
        # 			while r.domain_idx >= len(received_datasets):
        # 				received_datasets.append(None)
        # 			received_datasets.append(r)
        
        T = len(train_datasets)
        delays = []
        x_or_y_delay = []
        # E_delay = args.delay
        for i in range(T):
            tmp = np.random.randint(E_delay - 2, E_delay + 3)
            delays.append(tmp)
            if np.random.rand() > 0.8:
                x_or_y_delay.append(0)
            else:
                x_or_y_delay.append(1)
        # x_or_y_delay.append(np.random.randint(0, 2))  # 0 means x delay and 1 means y delay
        
        ys = [None] * (len(train_datasets) + E_delay + 5)
        xs = [None] * (len(train_datasets) + E_delay + 5)
        for i in range(T):
            if x_or_y_delay[i] == 0:
                if xs[i + delays[i]] is None:
                    xs[i + delays[i]] = [train_datasets[i]]
                else:
                    xs[i + delays[i]].append(train_datasets[i])
            else:
                if ys[i + delays[i]] is None:
                    ys[i + delays[i]] = [train_datasets[i]]
                else:
                    ys[i + delays[i]].append(train_datasets[i])
        
        train_datas = [None] * len(train_datasets)
        received_datas = [None] * len(train_datasets)
        
        for i in range(len(train_datasets)):  # guarantee for every t, at least one part is received
            if x_or_y_delay[i] == 0:
                received_datas[i] = train_datasets[i]  # received y
            else:
                train_datas[i] = train_datasets[i]  # received x
        
        last_x = 0
        last_y = 0
        for i in range(len(train_datasets)):
            if train_datas[i] is None:
                for j in range(last_x, i + E_delay):
                    # for j in range(0, len(train_datasets)):
                    find = False
                    if xs[j] is not None:
                        for k in range(len(xs[j])):
                            if xs[j][k] not in train_datas and xs[j][k].domain_idx <= i:
                                train_datas[i] = xs[j][k]
                                find = True
                                last_x = j
                                break
                    if find:
                        break
            if received_datas[i] is None:
                for j in range(last_y, i + E_delay):
                    # for j in range(i, len(train_datasets)):
                    find = False
                    if ys[j] is not None:
                        for k in range(len(ys[j])):
                            if ys[j][k] not in received_datas and ys[j][k].domain_idx <= i:
                                received_datas[i] = ys[j][k]
                                find = True
                                last_y = j
                                break
                    if find:
                        break
        return train_datasets, train_datas, received_datas
        
        # return train_datasets, received_datasets


def load_portraits_data(filename, t_u):
    interval = 1000
    data = io.loadmat(filename)
    xs = np.squeeze(data['Xs'])
    ys = data['Ys'][0]
    num_domains = len(t_u)
    num = sum(t_u)
    idx = 0
    X = []
    Y = []
    for i in range(num_domains):
        shuffled = shuffle(xs[idx:idx + t_u[i]], ys[idx:idx + t_u[i]])
        X = X + [shuffled[0]]
        Y = Y + [shuffled[1]]
        print('Domain', i, 'image indices range from', idx, 'to', idx + t_u[i] - 1)
        idx += interval
    X = np.concatenate(X)
    Y = np.concatenate(Y)
    
    return torch.reshape(torch.from_numpy(X), (num, -1)), torch.from_numpy(Y).long()


_PORTRAITS_TRAIN_TRANSFORMS = _MNIST_M_TEST_TRANSFORMS = [
    transforms.ToTensor(),
    transforms.ToPILImage(),
    # transforms.Pad(2),
    transforms.ToTensor(),
]

if __name__ == '__main__':
    # config = '2'
    # if config == '0':
    # 	t_u = [512, 256, 128, 64, 32]
    # elif config == '1':
    # 	t_u = [32, 64, 128, 256, 512]
    # else:
    # 	t_u = [200, 200, 200, 200, 200]
    # X, Y = load_portraits_data('datasets/portraits/dataset_32x32.mat', t_u)
    #
    # from matplotlib import pyplot as plt
    #
    # plt.imshow(X[1].reshape((32, 32)), interpolation='nearest')
    # plt.show()
    
    ori, train_datasets, received_datasets = get_datasets(
        'datasets/portraits/dataset_32x32.mat',
        t_u=[2000] * 9,
        E_delay=3,
        expected=True
    )
