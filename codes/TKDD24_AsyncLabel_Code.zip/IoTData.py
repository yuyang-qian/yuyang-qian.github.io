import pickle

import torch
import sys
import numpy as np
import pandas as pd
from data import LabeledDataset

# standardize numerical columns
from portraits_util import shuffle


def standardize(df, col):
    df[col] = (df[col] - df[col].mean()) / df[col].std()


class load_mod:
    def __init__(self, text='load part {} finished'):
        self.num = 1
        self.text = text
    
    def record(self):
        print(self.text.format(self.num))
        self.num += 1


def loadIoTData(frac_factor=1.0):
    lm = load_mod()
    
    benign = pd.read_csv('./dataset/IoT/5.benign.csv')
    lm.record()
    g_c = pd.read_csv('./dataset/IoT/5.gafgyt.combo.csv')
    lm.record()
    g_j = pd.read_csv('./dataset/IoT/5.gafgyt.junk.csv')
    lm.record()
    g_s = pd.read_csv('./dataset/IoT/5.gafgyt.scan.csv')
    lm.record()
    g_t = pd.read_csv('./dataset/IoT/5.gafgyt.tcp.csv')
    lm.record()
    g_u = pd.read_csv('./dataset/IoT/5.gafgyt.udp.csv')
    lm.record()
    m_a = pd.read_csv('./dataset/IoT/5.mirai.ack.csv')
    lm.record()
    m_sc = pd.read_csv('./dataset/IoT/5.mirai.scan.csv')
    lm.record()
    m_sy = pd.read_csv('./dataset/IoT/5.mirai.syn.csv')
    lm.record()
    m_u = pd.read_csv('./dataset/IoT/5.mirai.udp.csv')
    lm.record()
    m_u_p = pd.read_csv('./dataset/IoT/5.mirai.udpplain.csv')
    lm.record()
    
    benign = benign.sample(frac=frac_factor * 0.25, replace=False)
    g_c = g_c.sample(frac=frac_factor * 0.25, replace=False)
    g_j = g_j.sample(frac=frac_factor * 0.5, replace=False)
    g_s = g_s.sample(frac=frac_factor * 0.5, replace=False)
    g_t = g_t.sample(frac=frac_factor * 0.15, replace=False)
    g_u = g_u.sample(frac=frac_factor * 0.15, replace=False)
    m_a = m_a.sample(frac=frac_factor * 0.25, replace=False)
    m_sc = m_sc.sample(frac=frac_factor * 0.15, replace=False)
    m_sy = m_sy.sample(frac=frac_factor * 0.25, replace=False)
    m_u = m_u.sample(frac=frac_factor * 0.1, replace=False)
    m_u_p = m_u_p.sample(frac=frac_factor * 0.27, replace=False)
    
    benign['type'] = 'benign'
    m_u['type'] = 'mirai_udp'
    g_c['type'] = 'gafgyt_combo'
    g_j['type'] = 'gafgyt_junk'
    g_s['type'] = 'gafgyt_scan'
    g_t['type'] = 'gafgyt_tcp'
    g_u['type'] = 'gafgyt_udp'
    m_a['type'] = 'mirai_ack'
    m_sc['type'] = 'mirai_scan'
    m_sy['type'] = 'mirai_syn'
    m_u_p['type'] = 'mirai_udpplain'
    
    data = pd.concat([benign, m_u, g_c, g_j, g_s, g_t, g_u, m_a, m_sc, m_sy, m_u_p],
                     axis=0, sort=False, ignore_index=True)
    
    labels_full = pd.get_dummies(data['type'], prefix='type')
    # labels_full =  data['type']
    
    data = data.drop(columns='type')
    
    data_st = data.copy()
    for i in (data_st.iloc[:, :-1].columns):
        standardize(data_st, i)
    
    train_data_st = data_st.values
    labels = labels_full.values
    labels = np.argmax(labels, axis=1)
    
    return train_data_st, labels


def load_iot_data(T, frac_factor=1.0):
    xs, ys = loadIoTData(frac_factor=frac_factor)
    xs, ys = shuffle(xs, ys)
    num = xs.shape[0]
    return torch.reshape(torch.from_numpy(xs), (num, -1)).to(torch.float32), torch.from_numpy(ys).long()


def generate_iot_data(T, E_delay, expected=True, frac_factor=1.0):
    if frac_factor == 0.01:
        # train_datasets, train_datas, received_datas
        with open('./subsampling_IoT/train_datasets.pkl', 'rb') as file:
            train_datasets = pickle.load(file)
        with open('./subsampling_IoT/train_datas.pkl', 'rb') as file:
            train_datas = pickle.load(file)
        with open('./subsampling_IoT/received_datas.pkl', 'rb') as file:
            received_datas = pickle.load(file)
        return train_datasets, train_datas, received_datas
    
    X, Y = load_iot_data(T, frac_factor=frac_factor)
    
    t_u = X.shape[0] // T
    train_datasets = []
    test_datasets = []
    # received_datasets = []
    dataset_num = T
    
    s_point = 0
    for i in range(dataset_num):
        # test_num = t_u[i] // 10
        train_dataset = LabeledDataset(
            X[s_point: s_point + t_u],
            Y[s_point: s_point + t_u],
            domain_idx=i,
            transform=None,
            num_classes=11
        )
        
        s_point += t_u
        
        train_datasets.append(train_dataset)
        # if i >= delay:
        # 	received_datasets.append(train_datasets[i - delay])
        # else:
        # 	received_datasets.append(None)
    
    if not expected:
        received_datas = [None] * E_delay + train_datasets
    else:
        # receives = [None] * (len(train_datasets) + delay + 10)
        # received_datasets = []
        # for i in range(len(train_datasets)):
        # 	tmp = np.random.randint(delay - 2, delay + 3)
        # 	if receives[i + tmp] is None:
        # 		receives[i + tmp] = [train_datasets[i]]
        # 	else:
        # 		receives[i + tmp].append(train_datasets[i])
        #
        # for i, rs in enumerate(receives):
        # 	if i < delay and rs is None:
        # 		received_datasets.append(None)
        # 		continue
        # 	if rs:
        # 		for r in rs:
        # 			while r.domain_idx >= len(received_datasets):
        # 				received_datasets.append(None)
        # 			received_datasets.append(r)
        
        T = len(train_datasets)
        delays = []
        x_or_y_delay = []
        # E_delay = args.delay
        for i in range(T):
            tmp = np.random.randint(E_delay - 2, E_delay + 3)
            delays.append(tmp)
            if np.random.rand() > 0.7:
                x_or_y_delay.append(0)
            else:
                x_or_y_delay.append(1)
        # x_or_y_delay.append(np.random.randint(0, 2))  # 0 means x delay and 1 means y delay
        
        ys = [None] * (len(train_datasets) + E_delay + 5)
        xs = [None] * (len(train_datasets) + E_delay + 5)
        for i in range(T):
            if x_or_y_delay[i] == 0:
                if xs[i + delays[i]] is None:
                    xs[i + delays[i]] = [train_datasets[i]]
                else:
                    xs[i + delays[i]].append(train_datasets[i])
            else:
                if ys[i + delays[i]] is None:
                    ys[i + delays[i]] = [train_datasets[i]]
                else:
                    ys[i + delays[i]].append(train_datasets[i])
        
        train_datas = [None] * len(train_datasets)
        received_datas = [None] * len(train_datasets)
        
        for i in range(len(train_datasets)):  # guarantee for every t, at least one part is received
            if x_or_y_delay[i] == 0:
                received_datas[i] = train_datasets[i]  # received y
            else:
                train_datas[i] = train_datasets[i]  # received x
        
        last_x = 0
        last_y = 0
        for i in range(len(train_datasets)):
            if train_datas[i] is None:
                for j in range(last_x, i + E_delay):
                    # for j in range(0, len(train_datasets)):
                    find = False
                    if xs[j] is not None:
                        for k in range(len(xs[j])):
                            if xs[j][k] not in train_datas and xs[j][k].domain_idx <= i:
                                train_datas[i] = xs[j][k]
                                find = True
                                last_x = j
                                break
                    if find:
                        break
            if received_datas[i] is None:
                for j in range(last_y, i + E_delay):
                    # for j in range(i, len(train_datasets)):
                    find = False
                    if ys[j] is not None:
                        for k in range(len(ys[j])):
                            if ys[j][k] not in received_datas and ys[j][k].domain_idx <= i:
                                received_datas[i] = ys[j][k]
                                find = True
                                last_y = j
                                break
                    if find:
                        break
    return train_datasets, train_datas, received_datas
    
    # return train_datasets, received_datasets


if __name__ == '__main__':
    # data, label = loadIoTData()
    train_datasets, train_datas, received_datas = generate_iot_data(T=30, E_delay=5, frac_factor=0.01)
    file = open('./subsampling_IoT/train_datasets.pkl', 'wb')
    pickle.dump(train_datasets, file)
    file.close()
    file = open('./subsampling_IoT/train_datas.pkl', 'wb')
    pickle.dump(train_datas, file)
    file.close()
    file = open('./subsampling_IoT/received_datas.pkl', 'wb')
    pickle.dump(received_datas, file)
    file.close()
