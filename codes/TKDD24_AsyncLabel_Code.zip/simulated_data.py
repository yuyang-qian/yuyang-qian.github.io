import copy
from abc import ABC, abstractmethod
import numpy as np
import math
from sklearn import linear_model
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import mean_squared_error
import torch
import torch.nn.functional as F

from data import LabeledDataset


class DataGenerator(ABC):
    
    def __init__(self, seed=None):
        self._seed = seed
        pass
    
    @abstractmethod
    def generate_data(self, T, dimension, stage):
        raise NotImplementedError()


class LinearRegressionGenerator(DataGenerator):
    
    def __init__(self, seed=None):
        super().__init__(seed)
    
    def generate_data(self, T, dimension, stage=10, radius=1, Gamma=1, model_var=0.05, mode='abrupt'):
        # model_var: for abrupt change
        # np.random.seed(self._seed)
        # generate new seeds
        seeds = np.random.randint(1e6, size=2 * T + 4)
        np.random.seed(seeds[-1])
        random_directions = np.random.normal(size=(dimension, T))
        random_directions /= np.linalg.norm(random_directions, axis=0)
        np.random.seed(seeds[-2])
        random_radii = np.random.random(T) ** (1 / dimension)
        X = Gamma * (random_directions * random_radii).T
        np.random.seed(seeds[-3])
        random_vec = np.random.randn(dimension)
        np.random.seed(seeds[-4])
        w = random_vec / np.linalg.norm(random_vec) * radius * np.random.rand()
        y = np.zeros(T)
        step = math.ceil(T / stage)
        w_ori = copy.deepcopy(w)
        for t in range(T):
            if mode == 'abrupt':
                if t % step == 0:
                    np.random.seed(seeds[2 * t])
                    random_vec = np.random.randn(dimension)
                    np.random.seed(seeds[2 * t + 1])
                    w = random_vec / np.linalg.norm(random_vec) * radius * np.random.rand()
            elif mode == 'slow':
                np.random.seed(seeds[2 * t])
                random_vec = np.random.randn(dimension)
                np.random.seed(seeds[2 * t + 1])
                w += random_vec / np.linalg.norm(random_vec) * model_var
                if np.linalg.norm(w) > radius:
                    w = w / np.linalg.norm(w) * radius * np.random.rand()
            elif mode == 'slow_vt':
                # if t >= 1:
                # 	X[t] = X[t - 1] + np.random.normal(size=(dimension)) * model_var * 0.1
                # 	X[t] = X[t] / np.linalg.norm(X[t])
                #   print(X[t])
                if t % step == 0:
                    w = w_ori
                np.random.seed(seeds[2 * t])
                random_vec = np.random.randn(dimension)
                np.random.seed(seeds[2 * t + 1])
                w += random_vec / np.linalg.norm(random_vec) * model_var
                if np.linalg.norm(w) > radius:
                    w = w / np.linalg.norm(w) * radius * np.random.rand()
            else:
                raise TypeError()
            y[t] = np.dot(X[t], w)
        return X, y
    
    def generate_batch_data(self, T, dimension, stage=10, radius=1, Gamma=1, model_var=0.05, mode='abrupt',
                            batchsize=100):
        # model_var: for abrupt change
        # np.random.seed(self._seed)
        # generate new seeds
        T = T * batchsize
        seeds = np.random.randint(1e6, size=2 * T + 4)
        np.random.seed(seeds[-1])
        random_directions = np.random.normal(size=(dimension, T))
        random_directions /= np.linalg.norm(random_directions, axis=0)
        np.random.seed(seeds[-2])
        random_radii = np.random.random(T) ** (1 / dimension)
        X = Gamma * (random_directions * random_radii).T
        np.random.seed(seeds[-3])
        random_vec = np.random.randn(dimension)
        np.random.seed(seeds[-4])
        w = random_vec / np.linalg.norm(random_vec) * radius * np.random.rand()
        y = np.zeros(T)
        step = math.ceil(T / batchsize / stage)
        w_ori = copy.deepcopy(w)
        for t in range(T):
            if t % batchsize != 0:
                y[t] = np.dot(X[t], w)
                continue
            tmp_t = t // batchsize
            if mode == 'abrupt':
                if tmp_t % step == 0:
                    np.random.seed(seeds[2 * tmp_t])
                    random_vec = np.random.randn(dimension)
                    np.random.seed(seeds[2 * tmp_t + 1])
                    w = random_vec / np.linalg.norm(random_vec) * radius * np.random.rand()
            elif mode == 'slow':
                np.random.seed(seeds[2 * tmp_t])
                random_vec = np.random.randn(dimension)
                np.random.seed(seeds[2 * tmp_t + 1])
                w += random_vec / np.linalg.norm(random_vec) * model_var
                if np.linalg.norm(w) > radius:
                    w = w / np.linalg.norm(w) * radius * np.random.rand()
            elif mode == 'slow_vt':
                if tmp_t % step == 0:
                    w = w_ori
                np.random.seed(seeds[2 * tmp_t])
                random_vec = np.random.randn(dimension)
                np.random.seed(seeds[2 * tmp_t + 1])
                w += random_vec / np.linalg.norm(random_vec) * model_var
                if np.linalg.norm(w) > radius:
                    w = w / np.linalg.norm(w) * radius * np.random.rand()
            else:
                raise TypeError()
            y[t] = np.dot(X[t], w)
        return X, y


def generate_simulated_labeleddatset(T, dimension, delay, stage=1, model_var=0.05, mode='abrupt'):
    train_datasets = []
    receive_datasets = []
    a = LinearRegressionGenerator()
    X, y = a.generate_data(T, dimension, stage=stage, model_var=model_var, mode=mode)
    w_star = linear_model.LinearRegression()
    w_star.fit(X, y)
    y_pred_star = w_star.predict(X)
    
    errs_star = []
    errs_stars = F.mse_loss(torch.tensor(y), torch.tensor(y_pred_star), reduction='none')
    
    for i in range(T):
        tmp_x = X[i, :].reshape(1, -1).astype(np.float32)
        tmp_y = float(y[i])
        train_datasets.append(LabeledDataset(tmp_x, tmp_y, i, num_classes=1, remark='sim'))
        errs_star.append(errs_stars[i].item())
    receive_datasets = [None] * delay + train_datasets
    
    return train_datasets, receive_datasets, errs_star


def generate_simulated_labeleddatset_expected_delay(T, dimension, E_delay, stage=1,
                                                    model_var=0.05, mode='abrupt'):
    '''
    Generate Expected delay simulated dataset
    '''
    train_datasets = []
    received_datasets = []
    a = LinearRegressionGenerator()
    X, y = a.generate_data(T, dimension, stage=stage, model_var=model_var, mode=mode)
    w_star = linear_model.LinearRegression()
    w_star.fit(X, y)
    y_pred_star = w_star.predict(X)
    
    errs_star = []
    errs_stars = F.mse_loss(torch.tensor(y), torch.tensor(y_pred_star), reduction='none')
    
    for i in range(T):
        tmp_x = X[i, :].reshape(1, -1).astype(np.float32)
        tmp_y = float(y[i])
        train_datasets.append(LabeledDataset(tmp_x, tmp_y, i, num_classes=1, remark='sim'))
        errs_star.append(errs_stars[i].item())
    
    receives = [None] * (len(train_datasets) + E_delay + 50)
    received_datasets = []
    for i in range(T):
        delay = np.random.randint(E_delay - 10, E_delay + 10)
        
        if receives[i + delay] is None:
            receives[i + delay] = [train_datasets[i]]
        else:
            receives[i + delay].append(train_datasets[i])
    
    for i, rs in enumerate(receives):
        if i < E_delay and rs is None:
            received_datasets.append(None)
            continue
        if rs:
            for r in rs:
                received_datasets.append(r)
    
    return train_datasets, received_datasets, errs_star


def generate_simulated_labeleddatset_asynchronous_delay(T, dimension, E_delay, stage=1,
                                                        model_var=0.05, mode='abrupt'):
    '''
    Generate Expected delay simulated dataset
    '''
    train_datasets = []
    received_datasets = []
    a = LinearRegressionGenerator()
    X, y = a.generate_data(T, dimension, stage=stage, model_var=model_var, mode=mode)
    w_star = linear_model.LinearRegression()
    w_star.fit(X, y)
    y_pred_star = w_star.predict(X)
    
    errs_star = []
    errs_stars = F.mse_loss(torch.tensor(y), torch.tensor(y_pred_star), reduction='none')
    
    for i in range(T):
        tmp_x = X[i, :].reshape(1, -1).astype(np.float32)
        tmp_y = float(y[i])
        train_datasets.append(LabeledDataset(tmp_x, tmp_y, i, num_classes=1, remark='sim'))
        errs_star.append(errs_stars[i].item())
    
    delays = []
    x_or_y_delay = []
    for i in range(T):
        tmp = np.random.randint(E_delay - 10, E_delay + 10)
        delays.append(tmp)
        x_or_y_delay.append(np.random.randint(0, 2))  # 0 means x delay and 1 means y delay
    
    ys = [None] * (len(train_datasets) + E_delay + 50)
    xs = [None] * (len(train_datasets) + E_delay + 50)
    for i in range(T):
        if x_or_y_delay[i] == 0:
            if xs[i + delays[i]] is None:
                xs[i + delays[i]] = [train_datasets[i]]
            else:
                xs[i + delays[i]].append(train_datasets[i])
        else:
            if ys[i + delays[i]] is None:
                ys[i + delays[i]] = [train_datasets[i]]
            else:
                ys[i + delays[i]].append(train_datasets[i])
    
    train_datas = [None] * len(train_datasets)
    received_datas = [None] * len(train_datasets)
    
    for i in range(len(train_datasets)):  # guarantee for every t, at least one part is received
        if x_or_y_delay[i] == 0:
            received_datas[i] = train_datasets[i]  # received y
        else:
            train_datas[i] = train_datasets[i]  # received x
    
    last_x = 0
    last_y = 0
    for i in range(len(train_datasets)):
        if train_datas[i] is None:
            for j in range(last_x, i):
                # for j in range(0, len(train_datasets)):
                find = False
                if xs[j] is not None:
                    for k in range(len(xs[j])):
                        if xs[j][k] not in train_datas:
                            train_datas[i] = xs[j][k]
                            find = True
                            last_x = j
                            break
                if find:
                    break
        if received_datas[i] is None:
            for j in range(last_y, i):
                # for j in range(i, len(train_datasets)):
                find = False
                if ys[j] is not None:
                    for k in range(len(ys[j])):
                        if ys[j][k] not in received_datas:
                            received_datas[i] = ys[j][k]
                            find = True
                            last_y = j
                            break
                if find:
                    break
    
    return train_datasets, train_datas, received_datas, errs_star


def generate_simulated_batchdata(T, dimension, delay, stage=1, model_var=0.05, mode='abrupt', batchsize=100):
    train_datasets = []
    receive_datasets = []
    a = LinearRegressionGenerator()
    X, y = a.generate_batch_data(T, dimension, stage=stage, model_var=model_var, mode=mode, batchsize=batchsize)
    w_star = linear_model.LinearRegression()
    w_star.fit(X, y)
    y_pred_star = w_star.predict(X)
    
    errs_star = []
    errs_stars = F.mse_loss(torch.tensor(y), torch.tensor(y_pred_star), reduction='none')
    
    for i in range(T):
        tmp_x = X[i * batchsize:(i + 1) * batchsize, :].astype(np.float32)
        tmp_y = y[i * batchsize:(i + 1) * batchsize].astype(np.float32)
        train_datasets.append(LabeledDataset(tmp_x, tmp_y, i, num_classes=1, remark='sim_batch'))
        errs_star.append(torch.sum(errs_stars[i * batchsize:(i + 1) * batchsize]).item())
    receive_datasets = [None] * delay + train_datasets
    
    return train_datasets, receive_datasets, errs_star


class ClassificationDataset_2d():
    def __init__(self):
        self.info = []
        self.data = None
        self.labels = None
        self.data_v = None
        self.labels_v = None
        
        self.selected_nums = None
    
    def gen_data_with_center(self, centers, cov, priors=None, sample_num=1000):
        f'''
		:param centers: np.array, size: cls_num * dim;
		:param cov: np.array, size: dim * dim
		:param priors: list, size: cls_num
		:param sample_num: int
		:return:
		'''
        cls_num = centers.shape[0]
        if priors is None:
            priors = np.ones(cls_num) / cls_num
        dim = centers.shape[1]
        labels = np.random.choice(cls_num, size=sample_num, p=priors)
        data = np.zeros((sample_num, dim))
        for i in range(cls_num):
            idx = (labels == i)
            num = idx.sum()
            values = np.random.multivariate_normal(centers[i], cov, size=num)
            data[idx] = values
        
        return data, labels
    
    def generate_data(self, T, stage=10, model_var=0.05, diameter=1.0, sample_num=32):
        centers = np.zeros((4, 2))
        centers[0, :] = np.array([1.0, 1.0])
        centers[1, :] = np.array([-1.0, 1.0])
        centers[2, :] = np.array([-1.0, -1.0])
        centers[3, :] = np.array([1.0, -1.0])
        centers *= diameter
        
        # w = np.random.randn(2, 4)
        w = np.array([[1.0, -1.0, -1.0, 1.0], [1.0, 1.0, -1.0, -1.0]])
        
        w0 = copy.deepcopy(w)
        
        data_list = []
        label_list = []
        
        for i in range(T):
            # for j in range(4):
            # 	random_vec = np.random.randn(2)
            # 	shift = random_vec / np.linalg.norm(random_vec) * model_var
            # 	centers += shift
            
            # if i % stage == 0:
            # 	centers[0, :] = np.array([1.0, 1.0])
            # 	centers[1, :] = np.array([-1.0, 1.0])
            # 	centers[2, :] = np.array([-1.0, -1.0])
            # 	centers[3, :] = np.array([1.0, -1.0])
            
            if i % stage == 0:
                # print('{} set to w0'.format(i))
                w = w0
            
            # make a shift: 1
            random_vec = np.random.randn(2, 4)
            shift = random_vec / np.linalg.norm(random_vec) * model_var
            w += shift
            
            random_vec = np.random.randn(4, 2)
            shift = random_vec / np.linalg.norm(random_vec) * model_var * 10.0
            # shift = random_vec / np.linalg.norm(random_vec) * model_var
            centers += shift
            
            # # make a shift: 2
            # random_vec = np.random.randn(2)
            # shift = random_vec / np.linalg.norm(random_vec) * model_var
            # w[:, 0] += shift
            # x = copy.deepcopy(w[:, 0])
            # w[0, 1] = -x[0]
            # w[1, 1] = x[1]
            # w[0, 2] = x[0]
            # w[1, 2] = -x[1]
            # w[0, 3] = -x[0]
            # w[1, 3] = -x[1]
            
            data, _ = self.gen_data_with_center(centers=centers,
                                                cov=np.array([[0.8, 0.2], [0.3, 0.7]]),
                                                sample_num=sample_num)
            labels = np.argmax(data @ w, axis=1)
            data_list.append(data)
            label_list.append(labels)
        return data_list, label_list
    
    def generate_asynchronous_data(self, T, E_delay, stage=10, model_var=0.05, diameter=1.0, sample_num=32):
        X_list, y_list = self.generate_data(T, stage=stage, model_var=model_var,
                                            diameter=diameter, sample_num=sample_num)
        
        X = np.concatenate(X_list, axis=0)
        y = np.concatenate(y_list, axis=0)
        
        print('111', X.shape, X[:5])
        print('222', y.shape, y[:10])
        w_star = linear_model.LogisticRegression()
        w_star.fit(X, y)
        y_pred_star = w_star.predict_log_proba(X)
        # y_pred_star = w_star.predict_proba(X)
        
        print('333', y_pred_star.shape, y_pred_star[:5])
        train_datasets = []
        
        errs_star = []
        # errs_stars = F.cross_entropy(torch.tensor(y_pred_star), torch.tensor(y), reduction='none')
        errs_stars = F.nll_loss(torch.tensor(y_pred_star), torch.tensor(y), reduction='none')
        
        for i in range(T):
            tmp_x = X[i * sample_num:(i + 1) * sample_num, :].astype(np.float32)
            tmp_y = y[i * sample_num:(i + 1) * sample_num]
            train_datasets.append(LabeledDataset(tmp_x, tmp_y, i, num_classes=4, remark='syn'))
            # errs_star.append(errs_stars[i * sample_num:(i + 1) * sample_num].sum() * 2.0)
            errs_star.append(errs_stars[i * sample_num:(i + 1) * sample_num].sum())
        
        delays = []
        x_or_y_delay = []
        for i in range(T):
            tmp = np.random.randint(E_delay - 10, E_delay + 10)
            delays.append(tmp)
            x_or_y_delay.append(np.random.randint(0, 2))  # 0 means x delay and 1 means y delay
        
        ys = [None] * (len(train_datasets) + E_delay + 50)
        xs = [None] * (len(train_datasets) + E_delay + 50)
        for i in range(T):
            if x_or_y_delay[i] == 0:
                if xs[i + delays[i]] is None:
                    xs[i + delays[i]] = [train_datasets[i]]
                else:
                    xs[i + delays[i]].append(train_datasets[i])
            else:
                if ys[i + delays[i]] is None:
                    ys[i + delays[i]] = [train_datasets[i]]
                else:
                    ys[i + delays[i]].append(train_datasets[i])
        
        train_datas = [None] * len(train_datasets)
        received_datas = [None] * len(train_datasets)
        
        for i in range(len(train_datasets)):  # guarantee for every t, at least one part is received
            if x_or_y_delay[i] == 0:
                received_datas[i] = train_datasets[i]  # received y
            else:
                train_datas[i] = train_datasets[i]  # received x
        
        last_x = 0
        last_y = 0
        for i in range(len(train_datasets)):
            if train_datas[i] is None:
                for j in range(last_x, i):
                    # for j in range(0, len(train_datasets)):
                    find = False
                    if xs[j] is not None:
                        for k in range(len(xs[j])):
                            if xs[j][k] not in train_datas:
                                train_datas[i] = xs[j][k]
                                find = True
                                last_x = j
                                break
                    if find:
                        break
            if received_datas[i] is None:
                for j in range(last_y, i):
                    # for j in range(i, len(train_datasets)):
                    find = False
                    if ys[j] is not None:
                        for k in range(len(ys[j])):
                            if ys[j][k] not in received_datas:
                                received_datas[i] = ys[j][k]
                                find = True
                                last_y = j
                                break
                    if find:
                        break
        
        return train_datasets, train_datas, received_datas, errs_star
    
    def get_base_models(self, data, label):
        model = LogisticRegression(solver='lbfgs', fit_intercept=False)
        model.fit(data, label)
        return model


if __name__ == '__main__':
    # ori, xs, ys, errs_star = generate_simulated_labeleddatset_asynchronous_delay(3000, 10, E_delay=20,
    # 																			 mode='slow_vt')
    # c = list(range(3000))
    # b = [x.domain_idx if x is not None else -1 for x in ys]
    # a = [x.domain_idx if x is not None else -1 for x in xs]
    # for i in range(3000):
    # 	if a[i] == b[i] and b[i] == c[i]:
    # 		print(i, 'match')
    # 	if a[i] != c[i] and b[i] != c[i]:
    # 		print(i, 'miss')
    
    gen = ClassificationDataset_2d()
    T = 3000
    train_datasets, xs, ys, errs_star = gen.generate_asynchronous_data(T=T, E_delay=20,
                                                                       stage=100, model_var=0.05,
                                                                       diameter=2.0, sample_num=32)
    c = list(range(T))
    b = [x.domain_idx if x is not None else -1 for x in ys]
    a = [x.domain_idx if x is not None else -1 for x in xs]
    for i in range(T):
        if a[i] == b[i] and b[i] == c[i]:
            print(i, 'match')
        if a[i] != c[i] and b[i] != c[i]:
            print(i, 'miss')
# centers = np.zeros((4, 2))
# centers[0, :] = np.array([1.0, 1.0])
# centers[1, :] = np.array([-1.0, 1.0])
# centers[2, :] = np.array([-1.0, -1.0])
# centers[3, :] = np.array([1.0, -1.0])
# centers *= 1.5
# data, labels = gen.gen_data_with_center(centers=centers, cov=np.array([[0.8, 0.2], [0.3, 0.7]]), sample_num=1000)
#
# model = gen.get_base_models(data, labels)
