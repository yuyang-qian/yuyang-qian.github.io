"""
Functions to write the x,y data to a npy file
"""
import numpy as np
import torch


def tfrecord_filename(dataset_name, postfix):
	""" Filename for tfrecord files, e.g. ucihar_1_train.tfrecord """
	return "%s_%s.tfrecord" % (dataset_name, postfix)


def nprecord_filename(dataset_name, postfix):
	""" Filename for tfrecord files, e.g. ucihar_1_train.tfrecord """
	return "%s_%s.npy" % (dataset_name, postfix)


def load_nprecord(dataset_names, dataset_names_labels):
	if len(dataset_names) == 0:
		return None, None
	
	datas = None
	labels = None
	for dataset_name in dataset_names:
		data = np.load(dataset_name)
		t_data = torch.from_numpy(data)
		if datas is None:
			datas = t_data
		else:
			datas = torch.cat((datas, t_data), dim=0)
	
	for dataset_name_label in dataset_names_labels:
		label = np.load(dataset_name_label)
		t_label = torch.from_numpy(label)
		if labels is None:
			labels = t_label
		else:
			labels = torch.cat((labels, t_label), dim=0)
	
	return datas, labels
