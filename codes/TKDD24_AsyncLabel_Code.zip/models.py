import math
from functools import reduce
import torch
from torch import nn, autograd, optim
from torch.autograd import Variable

import dgr
import utils
from torch.autograd import Function

import numpy as np
from LinearModelwithProjection import LinearModelwithProjection, DenseLinearModel


class SimpleCNN(nn.Module):
    def __init__(self, image_size,
                 image_channel_size, classes,
                 depth, channel_size, reducing_layers=3):
        super(SimpleCNN, self).__init__()
        
        self.image_size = image_size
        self.image_channel_size = image_channel_size
        self.classes = classes
        self.depth = depth
        self.channel_size = channel_size
        self.reducing_layers = reducing_layers
        
        # layers
        self.layers = nn.ModuleList([nn.Conv2d(
            self.image_channel_size, self.channel_size // (2 ** (depth - 2)),
            3, 1, 1
        )])
        
        for i in range(self.depth - 2):  # default depth = 3
            previous_conv = [
                l for l in self.layers if
                isinstance(l, nn.Conv2d)
            ][-1]
            self.layers.append(nn.Conv2d(
                previous_conv.out_channels,
                previous_conv.out_channels * 2,
                3, 1 if i >= reducing_layers else 2, 1
            ))
            self.layers.append(nn.BatchNorm2d(previous_conv.out_channels * 2))
            self.layers.append(nn.ReLU())
        
        self.layers.append(utils.LambdaModule(lambda x: x.view(x.size(0), -1)))
        self.layers.append(nn.Linear(
            (image_size // (2 ** reducing_layers)) ** 2 * channel_size,
            self.classes
        ))
    
    def forward(self, x):
        return reduce(lambda x, l: l(x), self.layers, x)


class BasicCNN(nn.Module):
    def __init__(self, image_size=32,
                 image_channel_size=3, classes=10,
                 depth=5, channel_size=32, reducing_layers=3):
        super(BasicCNN, self).__init__()
        
        self.feat_layers = []
        # self.c_layers.append(nn.Dropout2d())
        # c_layers_out_c = 256  # default = 1024
        # c_layers_out_c = previous_conv.out_channels * 2
        self.feat_layers.append(nn.Conv2d(image_channel_size, 32, kernel_size=5, stride=2))
        self.feat_layers.append(nn.Conv2d(32, 64, kernel_size=5, stride=2))
        self.feat_layers.append(nn.Conv2d(64, 128, kernel_size=5, stride=2))
        self.feat_layers.append(nn.Dropout(0.5))
        self.feat_layers.append(utils.LambdaModule(lambda x: x.view(x.size(0), -1)))
        self.feat_layers = nn.Sequential(*self.feat_layers)
        
        self.c_layers = nn.Linear(128, classes)
        
        self.s_layers = nn.Linear(128, 5)
    
    def forward(self, x, alpha=1.0, out='C'):
        # print( x.shape)  # portraits: (batchsize, 1, 32, 32)
        batchsize = x.size(0)
        feat = self.feat_layers(x)
        # print(feat.shape)
        if out == 'C':
            # print(feat.shape)
            c_out = self.c_layers(feat)
            
            reverse_feat = GradReverse.apply(feat, alpha)
            s_out = self.s_layers(reverse_feat)
            return c_out, s_out
        if out == 'feat':
            return feat


class DANNSimpleCNN(nn.Module):
    def __init__(self, image_size=32,
                 image_channel_size=3, classes=10,
                 depth=5, channel_size=32, reducing_layers=3):
        super(DANNSimpleCNN, self).__init__()
        
        self.image_size = image_size
        self.image_channel_size = image_channel_size
        self.classes = classes
        self.depth = depth  # Default depth=5
        self.channel_size = channel_size
        self.reducing_layers = reducing_layers
        self.num_sources = 5
        
        # layers
        self.layers = nn.ModuleList([nn.Conv2d(
            self.image_channel_size, self.channel_size // (2 ** (depth - 2)),
            3, 1, 1
        )])
        
        for i in range(self.depth - 3):
            previous_conv = [
                l for l in self.layers if
                isinstance(l, nn.Conv2d)
            ][-1]
            self.layers.append(nn.Conv2d(
                previous_conv.out_channels,
                previous_conv.out_channels * 2,
                3, 1 if i >= reducing_layers else 2, 1
            ))
            self.layers.append(nn.BatchNorm2d(previous_conv.out_channels * 2))
            self.layers.append(nn.ReLU())
        i = self.depth - 3
        previous_conv = [
            l for l in self.layers if
            isinstance(l, nn.Conv2d)
        ][-1]
        
        self.c_layers = []
        # self.c_layers.append(nn.Dropout2d())
        # c_layers_out_c = 256  # default = 1024
        c_layers_out_c = previous_conv.out_channels * 2
        self.c_layers.append(nn.Conv2d(
            previous_conv.out_channels,
            c_layers_out_c,
            3, 1 if i >= reducing_layers else 2, 1
        ))
        self.c_layers.append(nn.BatchNorm2d(c_layers_out_c))
        self.c_layers.append(nn.ReLU())
        self.c_layers.append(utils.LambdaModule(lambda x: x.view(x.size(0), -1)))
        # self.c_layers.append(nn.Dropout())
        self.c_layers.append(nn.Linear(
            c_layers_out_c * 16,
            self.classes
        ))
        self.c_layers = nn.Sequential(*self.c_layers)
        
        self.s_layers = []
        # self.s_layers.append(nn.Dropout2d())
        s_layers_out_c = 256  # default=1024
        # s_layers_out_c = previous_conv.out_channels * 2
        self.s_layers.append(nn.Conv2d(
            previous_conv.out_channels,
            s_layers_out_c,
            3, 1 if i >= reducing_layers else 2, 1
        ))
        self.s_layers.append(nn.BatchNorm2d(s_layers_out_c))
        self.s_layers.append(nn.ReLU())
        self.s_layers.append(utils.LambdaModule(lambda x: x.view(x.size(0), -1)))
        # self.s_layers.append(nn.Dropout())
        self.s_layers.append(nn.Linear(
            s_layers_out_c * 16,
            self.num_sources
        ))
        self.s_layers = nn.Sequential(*self.s_layers)
        self.feat_pool = nn.MaxPool2d(8)
    
    def forward(self, x, alpha=1.0, out='C'):
        # print( x.shape)  # portraits: (batchsize, 1, 32, 32)
        batchsize = x.size(0)
        feat = reduce(lambda x, l: l(x), self.layers, x)
        
        if out == 'C':
            # print(feat.shape)
            c_out = self.c_layers(feat)
            
            reverse_feat = GradReverse.apply(feat, alpha)
            s_out = self.s_layers(reverse_feat)
            return c_out, s_out
        if out == 'feat':
            out_feat = self.feat_pool(feat)
            return out_feat


class ts_DANNSimpleCNN(nn.Module):
    def __init__(self, image_size=32,
                 image_channel_size=3, classes=10,
                 depth=5, channel_size=32, reducing_layers=3, domain_classes=5):
        super(ts_DANNSimpleCNN, self).__init__()
        
        self.image_size = image_size
        self.image_channel_size = image_channel_size
        self.classes = classes
        self.depth = depth  # Default depth=5
        self.channel_size = channel_size
        self.reducing_layers = reducing_layers
        self.num_sources = 5
        
        self.feat_layers = nn.Sequential(
            nn.Conv1d(image_channel_size, 128, kernel_size=9, padding=4, bias=False),
            nn.BatchNorm1d(128),
            nn.ReLU(inplace=True),
            
            nn.Conv1d(128, 256, kernel_size=5, padding=2, bias=False),
            nn.BatchNorm1d(256),
            nn.ReLU(inplace=True),
            
            nn.Conv1d(256, 128, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm1d(128),
            nn.ReLU(inplace=True),
            
            nn.AvgPool1d(128)
        )
        
        self.c_layers = nn.Sequential(
            nn.Linear(128, classes)
        )
        
        self.s_layers = nn.Sequential(
            nn.Linear(128, 500, bias=False),
            nn.BatchNorm1d(500),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            
            nn.Linear(500, 500, bias=False),
            nn.BatchNorm1d(500),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            
            nn.Linear(500, domain_classes)
        )
    
    def forward(self, x, alpha=1.0, out='C'):
        x = x.permute(0, 2, 1)  # (32, 128, 3) -> (32, 3, 128)
        #         print(x.shape)
        batchsize = x.size(0)
        #         feat = reduce(lambda x, l: l(x), self.layers, x)
        feat = self.feat_layers(x)
        feat = feat.squeeze(2)
        #         print(feat.shape)
        if out == 'C':
            c_out = self.c_layers(feat)
            reverse_feat = GradReverse.apply(feat, alpha)
            s_out = self.s_layers(reverse_feat)
            return c_out, s_out
        if out == 'feat':
            return feat


# return feat.view(batchsize, -1)


class CNN_CV(dgr.Solver_Mine):
    def __init__(self,
                 image_size,
                 image_channel_size, classes,
                 depth, channel_size, reducing_layers=3):
        # configurations
        super().__init__()
        self.image_size = image_size
        self.image_channel_size = image_channel_size
        self.classes = classes
        self.depth = depth
        self.channel_size = channel_size
        self.reducing_layers = reducing_layers
        
        self.solver = SimpleCNN(image_size,
                                image_channel_size, classes,
                                depth, channel_size, reducing_layers=3)


class Solver_SSD(dgr.Solver_Mine):
    def __init__(self,
                 image_size,
                 image_channel_size, classes,
                 depth, channel_size, reducing_layers=3, experiment='', args=None):
        # configurations
        super().__init__()
        self.image_size = image_size
        self.image_channel_size = image_channel_size
        self.classes = classes
        self.depth = depth
        self.channel_size = channel_size
        self.reducing_layers = reducing_layers
        self.MMD_ALPHA = None
        self.solver = None
        self.experiemnt = experiment
        self.args = args
        
        if 'CONDOR' in args.method or 'OMD' in args.method:
            self.args.logger.info('Method: Ensemble Method. Building Model Pool...')
            self.modelpool = []
            self.modelpool_w = []
            self.betapool = []
            self.model_eta = 0.05
            self.correctness_w_pool = []
        if 'FF' == args.method:
            self.modelpool_w = []
            self.correctness_w_pool = []
        # Checking whether the (x, y) is available
        self.received_x_idx = []
        self.received_y_idx = []
        
        # self.x_label_mean = nn.Parameter(torch.randn_like(args.classes , ))
        # self.x_label_mean = nn.ParameterDict({})
        self.x_label_mean = [None] * args.classes
        
        self.solver, self.solver_name = self.new_model()
        
        self.args.logger.info(self.solver)
        
        if 'data.sim' in args.experiment or 'data.Bsim' in args.experiment:
            self.loss_class = torch.nn.MSELoss()
            self.loss_domain = torch.nn.MSELoss()
        else:
            self.loss_class = torch.nn.CrossEntropyLoss()
            self.loss_domain = torch.nn.CrossEntropyLoss()
    
    def new_model(self):
        experiment = self.experiemnt
        image_channel_size = self.image_channel_size
        image_size = self.image_size
        classes = self.classes
        depth = self.depth
        channel_size = self.channel_size
        if 'model.simple' in experiment:
            new_model = SSDCNN(image_channel_size)
            new_model_name = 'Simple'
        
        if 'model.DANN' in experiment:
            new_model = DANNSimpleCNN(image_size,
                                      image_channel_size, classes,
                                      depth, channel_size, reducing_layers=3)
            new_model_name = 'DANN'
        
        if 'model.ts-DANN' in experiment:
            new_model = ts_DANNSimpleCNN(image_size,
                                         image_channel_size, classes,
                                         depth, channel_size, reducing_layers=3)
            new_model_name = 'ts-DANN'
        
        if 'model.port-DANN' in experiment:
            # depth = 2
            new_model = DANNSimpleCNN(image_size,
                                      image_channel_size, classes,
                                      depth, channel_size, reducing_layers=3)
            # new_model = BasicCNN(image_size,
            # 					   image_channel_size, classes,
            # 					   depth, channel_size, reducing_layers=3)
            new_model_name = 'port-DANN'
        
        if 'model.linear' in experiment:
            new_model = LinearModelwithProjection(feat_num=image_size, D=1, classes=classes)
            new_model_name = 'linear'
        
        if 'model.dense' in experiment:
            new_model = DenseLinearModel(feat_num=image_size, classes=classes)
            new_model_name = 'dense'
        
        return new_model, new_model_name
    
    def solve(self, x):
        scores, _ = self.solver(x)
        _, predictions = torch.max(scores, 1)
        return predictions
    
    # Train CNN SSD
    def train_a_batch(self,
                      x_optimism=None, y_optimism=None, t_optimism=None,
                      y_op_true=None,
                      x_received=None, y_received=None, t_received=None,
                      x_re_op=None,
                      batch_index=0,
                      importance_of_new_task=.5, train_mode='',
                      alpha=1.0, current_idx=0, args=None, feat_table=None, txt_set=None):
        
        # if y_optimism is None and y_received is None:  # No Labeled data
        # 	return
        
        if y_received is not None and train_mode == 'receive_y':  # receive previous labeled data
            # Update \hat{w}_{t-d} -> \hat{w}_{t}
            if 'data.sim' in args.experiment:
                idx = t_received.item()
            else:
                idx = t_received[0].item()
            
            txt = '****** Received data from {} ******'.format(idx + 1)
            if txt not in txt_set:
                self.args.logger.info(txt)
                txt_set.add(txt)
            
            if 'OMD' in args.method:
                txt = 'OMD w_hat use model from t={}'.format(idx + 1)
                if txt not in txt_set:
                    self.args.logger.info(txt)
                    txt_set.add(txt)
                
                model = self.modelpool[idx]
                optimizer = optim.SGD(
                    model.parameters(),
                    lr=args.lr, weight_decay=args.weight_decay,
                )
            else:
                lr = args.lr
                if 'AdaDelay' in args.method:
                    lr = args.new_lr
                model = self.solver
                # optimizer = self.optimizer
                optimizer = optim.SGD(
                    model.parameters(),
                    lr=lr, weight_decay=args.weight_decay,
                )
            
            # clear gradients.
            optimizer.zero_grad()
            
            # Received Old Gradients (xl, yl):
            batch_size = x_received.size(0)
            class_output, _ = model(x_received, alpha=alpha)
            
            if 'data.sim' in args.experiment or 'data.Bsim' in args.experiment:
                class_output = class_output.to(torch.float32)
                y_received = y_received.to(torch.float32)
            
            err_received_label = self.loss_class(class_output, y_received)
            
            _, real_predicted = class_output.max(1)
            real_prec = (y_received == real_predicted).sum().item() / batch_size
            # err_s_domain = self.loss_domain(domain_output, s_xl)
            
            # if 'source-only' in args.method:
            # 	loss = err_received_label
            # elif 'target-only' in args.method:
            # 	loss = err_received_label
            # # return {'loss': loss.item(), 'precision': real_prec_}
            # else:
            loss = err_received_label
            
            precision = real_prec
            loss.backward()
            optimizer.step()
            if 'model.linear' in args.experiment:
                args.logger.info('Model Norm: {}'.format(model.get_norm()))
                model.project()
            
            if 'data.sim' in args.experiment:
                return {'loss': loss.item(), 'precision': loss.item()}
            else:
                return {'loss': loss.item(), 'precision': precision}
        
        if y_received is not None and train_mode == 'receive_x':  # receive previous labeled data
            # Update \hat{w}_{t-d} -> \hat{w}_{t}
            if 'data.sim' in args.experiment:
                idx = t_optimism.item()
            else:
                idx = t_optimism[0].item()
            
            txt = '****** Received data from {} ******'.format(idx + 1)
            if txt not in txt_set:
                self.args.logger.info(txt)
                txt_set.add(txt)
            
            if 'OMD' in args.method:
                txt = 'OMD w_hat use model from t={}'.format(idx + 1)
                if txt not in txt_set:
                    self.args.logger.info(txt)
                    txt_set.add(txt)
                
                model = self.modelpool[idx]
                optimizer = optim.SGD(
                    model.parameters(),
                    lr=args.lr, weight_decay=args.weight_decay,
                )
            else:
                lr = args.lr
                if 'AdaDelay' in args.method:
                    lr = args.new_lr
                model = self.solver
                # optimizer = self.optimizer
                optimizer = optim.SGD(
                    model.parameters(),
                    lr=lr, weight_decay=args.weight_decay,
                )
            
            # clear gradients.
            optimizer.zero_grad()
            
            # Received Old Gradients (xl, yl):
            batch_size = x_optimism.size(0)
            class_output, _ = model(x_optimism, alpha=alpha)
            
            if 'data.sim' in args.experiment or 'data.Bsim' in args.experiment:
                class_output = class_output.to(torch.float32)
                y_op_true = y_op_true.to(torch.float32)
            
            err_received_label = self.loss_class(class_output, y_op_true)
            
            _, real_predicted = class_output.max(1)
            real_prec = (y_op_true == real_predicted).sum().item() / batch_size
            # err_s_domain = self.loss_domain(domain_output, s_xl)
            
            # if 'source-only' in args.method:
            # 	loss = err_received_label
            # elif 'target-only' in args.method:
            # 	loss = err_received_label
            # # return {'loss': loss.item(), 'precision': real_prec_}
            # else:
            loss = err_received_label
            
            precision = real_prec
            loss.backward()
            optimizer.step()
            if 'model.linear' in args.experiment:
                args.logger.info('Model Norm: {}'.format(model.get_norm()))
                model.project()
            
            if 'data.sim' in args.experiment:
                return {'loss': loss.item(), 'precision': loss.item()}
            else:
                return {'loss': loss.item(), 'precision': precision}
        
        if y_optimism is not None and train_mode == 'w_x':
            # Update \hat{w}_{t} -> w_{t}
            model = self.solver
            optimizer = self.optimizer
            
            # clear gradients.
            optimizer.zero_grad()
            
            batch_size = x_optimism.size(0)
            class_output, _ = model(x_optimism, alpha=alpha)
            err_optimism_label = self.loss_class(class_output, y_optimism)
            
            _, real_predicted = class_output.max(1)
            real_prec = (y_optimism == real_predicted).sum().item() / batch_size
            # err_s_domain = self.loss_domain(domain_output, s_xl)
            
            # if 'source-only' in args.method:
            # 	loss = err_optimism_label
            # elif 'target-only' in args.method:
            # 	loss = err_optimism_label
            # # return {'loss': loss.item(), 'precision': real_prec_}
            # else:
            loss = err_optimism_label
            
            precision = real_prec
            loss.backward()
            optimizer.step()
            
            if 'model.linear' in args.experiment:
                args.logger.info('Model Norm: {}'.format(model.get_norm()))
                model.project()
            
            if 'data.sim' in args.experiment:
                return {'loss': loss.item(), 'precision': loss.item()}
            else:
                return {'loss': loss.item(), 'precision': precision}
        
        if x_re_op is not None and train_mode == 'w_y':
            # Update \hat{w}_{t} -> w_{t}
            model = self.solver
            optimizer = self.optimizer
            
            # clear gradients.
            optimizer.zero_grad()
            
            batch_size = x_re_op.size(0)
            
            class_output, _ = model(x_re_op, alpha=alpha)
            if 'data.sim' in args.experiment or 'data.Bsim' in args.experiment:
                class_output = class_output.to(torch.float32)
                y_received = y_received.to(torch.float32)
            err_optimism_label = self.loss_class(class_output, y_received)
            
            _, real_predicted = class_output.max(1)
            real_prec = (y_received == real_predicted).sum().item() / batch_size
            # err_s_domain = self.loss_domain(domain_output, s_xl)
            
            # if 'source-only' in args.method:
            # 	loss = err_optimism_label
            # elif 'target-only' in args.method:
            # 	loss = err_optimism_label
            # # return {'loss': loss.item(), 'precision': real_prec_}
            # else:
            loss = err_optimism_label
            
            precision = real_prec
            loss.backward()
            optimizer.step()
            
            if 'model.linear' in args.experiment:
                args.logger.info('Model Norm: {}'.format(model.get_norm()))
                model.project()
            
            if 'data.sim' in args.experiment:
                return {'loss': loss.item(), 'precision': loss.item()}
            else:
                return {'loss': loss.item(), 'precision': precision}
        
        # if xl is not None and xl_ is None:  # SSL Stage
        # 	# ARC_s
        # 	batch_size = xl.size(0)
        # 	self.optimizer.zero_grad()
        # 	# self.solver.zero_grad()
        # 	# s = (torch.ones(x.size(0)) * current_idx).long()
        # 	class_output, _ = self.solver(xl, alpha=alpha)
        # 	err_label = self.loss_class(class_output, yl)
        #
        # 	_, real_predicted = class_output.max(1)
        # 	real_prec = (yl == real_predicted).sum().item() / batch_size
        # 	loss = err_label
        #
        # 	precision = real_prec
        #
        # 	class_output_u, _ = self.solver(xu, alpha=alpha)
        #
        # 	L_mmd = torch.zeros_like(err_label)
        # 	mmd_mask_u = torch.zeros_like(err_label)
        #
        # 	if args.lambda_mmd > 0 and 'Consist' in args.method:
        # 		# if not ('data.ts' in args.experiment and current_idx == 1):
        # 		# and 'data.ts' not in args.experiment:
        #
        # 		feat_l = self.solver(xl, out='feat')
        # 		feat_u_w = self.solver(xu, out='feat')
        #
        # 		mmd_mask_l = feat_table[current_idx - 1].get_mask(class_output, threshold=args.mmd_threshold,
        # 														  num_class=args.classes)
        # 		mmd_mask_u = feat_table[current_idx - 1].get_mask(class_output_u, threshold=args.mmd_threshold,
        # 														  num_class=args.classes)
        # 		if mmd_mask_l.sum() > 0 and mmd_mask_u.sum() > 0:
        # 			cur_feat_l, cur_feat_u = feat_table[current_idx - 1].update_feat_table(
        # 				feat_l, feat_u_w,
        # 				args.mmd_feat_table_l,
        # 				args.mmd_feat_table_u,
        # 				mask_l=mmd_mask_l,
        # 				mask_u=mmd_mask_u
        # 			)
        #
        # 			if batch_index > args.reg_warmup and len(cur_feat_l) > 20:
        # 				L_mmd = mmd_criterion(cur_feat_l, cur_feat_u)
        #
        # 	if 'data.ts' in args.experiment or 'data.port' in args.experiment:
        # 		lambda_mmd = train_scheduler.exp_warmup(args.lambda_mmd, args.reg_warmup_iter, batch_index + 1)
        # 	else:
        # 		lambda_mmd = train_scheduler.linear_warmup(args.lambda_mmd, args.reg_warmup_iter,
        # 												   batch_index + 1)
        #
        # 	loss = err_label + lambda_mmd * L_mmd
        # 	loss.backward()
        # 	self.optimizer.step()
        # 	return {'loss': loss.item(), 'precision': precision}
        # # else:  # t > 1
        # if xl is not None and xl_ is not None:  # SSL + MSUDA Stage
        # 	# ARC_s + ARC_t
        # 	# clear gradients.
        # 	self.optimizer.zero_grad()
        # 	# self.solver.zero_grad()
        #
        # 	# Source:
        # 	batch_size = xl_.size(0)
        # 	class_output_, domain_output_ = self.solver(xl_, alpha=alpha)
        # 	err_s_label = self.loss_class(class_output_, yl_)
        #
        # 	_, real_predicted = class_output_.max(1)
        # 	real_prec_ = (yl_ == real_predicted).sum().item() / batch_size
        #
        # 	if ('Sketch' in args.method or 'KMeans' in args.method) and self.MMD_ALPHA is not None:
        # 		domain_weight_xl_ = torch.mean(MMD_ALPHA[s_xl_])
        # 		err_s_domain = self.loss_domain(domain_output_, s_xl_) * domain_weight_xl_
        # 	else:
        # 		err_s_domain = self.loss_domain(domain_output_, s_xl_)
        #
        # 	# Target:
        # 	batch_size = xl.size(0)
        #
        # 	class_output, domain_output = self.solver(xl, alpha=alpha)
        # 	err_t_label = self.loss_class(class_output, yl)
        #
        # 	_, real_predicted = class_output.max(1)
        # 	real_prec = (yl == real_predicted).sum().item() / batch_size
        #
        # 	err_t_domain = self.loss_domain(domain_output, t_xl)
        #
        # 	if 'source-only' in args.method:
        # 		loss = err_s_label
        # 	elif 'target-only' in args.method:
        # 		loss = err_t_label
        # 	elif 'GR' in args.method:
        # 		loss = err_t_label + err_t_domain + err_s_domain + err_s_label
        # 	elif 'SW' in args.method:
        # 		loss = err_t_label + err_s_label
        # 	else:
        # 		loss = err_t_label + err_s_label
        #
        # 	precision = (real_prec + real_prec_) / 2.0
        # 	loss.backward()
        # 	self.optimizer.step()
        # 	return {'loss': loss.item(), 'precision': precision}
        #
        # if xl is None and xl_ is not None:  # MSUDA Stage
        # 	# ARC_s + ARC_t
        # 	# clear gradients.
        # 	self.optimizer.zero_grad()
        # 	# self.solver.zero_grad()
        #
        # 	# Source:
        # 	batch_size = xl_.size(0)
        # 	class_output_, domain_output_ = self.solver(xl_, alpha=alpha)
        # 	err_s_label = self.loss_class(class_output_, yl_)
        #
        # 	_, real_predicted = class_output_.max(1)
        # 	real_prec_ = (yl_ == real_predicted).sum().item() / batch_size
        # 	err_s_domain = self.loss_domain(domain_output_, s_xl_)
        #
        # 	# Target:
        # 	batch_size = xu.size(0)
        #
        # 	_, domain_output = self.solver(xu, alpha=alpha)
        # 	err_t_domain = self.loss_domain(domain_output, s_xu)
        #
        # 	if 'source-only' in args.method:
        # 		loss = err_s_label
        # 	elif 'target-only' in args.method:
        # 		loss = err_s_label
        # 	# return {'loss': loss.item(), 'precision': real_prec_}
        # 	elif 'GR' in args.method:
        # 		loss = err_t_domain + err_s_domain + err_s_label
        # 	elif 'SW' in args.method:
        # 		loss = err_s_label
        # 	else:
        # 		loss = err_s_label
        #
        # 	precision = real_prec_
        # 	loss.backward()
        # 	self.optimizer.step()
        # 	return {'loss': loss.item(), 'precision': precision}


class ReverseLayerF(Function):
    
    @staticmethod
    def forward(ctx, x, alpha):
        ctx.alpha = alpha
        
        return x.view_as(x)
    
    @staticmethod
    def backward(ctx, grad_output):
        output = grad_output.neg() * ctx.alpha
        
        return output, None


class SSDCNN(nn.Module):
    def __init__(self, image_channel_size=3, n_class=10, source_num=5):
        super(SSDCNN, self).__init__()
        self.feature = nn.Sequential()
        self.feature.add_module('f_conv1', nn.Conv2d(image_channel_size, 64, kernel_size=5))
        self.feature.add_module('f_bn1', nn.BatchNorm2d(64))
        self.feature.add_module('f_pool1', nn.MaxPool2d(2))
        self.feature.add_module('f_relu1', nn.ReLU(True))
        self.feature.add_module('f_conv2', nn.Conv2d(64, 50, kernel_size=5))
        self.feature.add_module('f_bn2', nn.BatchNorm2d(50))
        self.feature.add_module('f_drop1', nn.Dropout2d())
        self.feature.add_module('f_pool2', nn.MaxPool2d(2))
        self.feature.add_module('f_relu2', nn.ReLU(True))
        
        self.class_classifier = nn.Sequential()
        self.class_classifier.add_module('c_fc1', nn.Linear(50 * 5 * 5, 100))
        self.class_classifier.add_module('c_bn1', nn.BatchNorm1d(100))
        self.class_classifier.add_module('c_relu1', nn.ReLU(True))
        self.class_classifier.add_module('c_drop1', nn.Dropout())
        self.class_classifier.add_module('c_fc2', nn.Linear(100, 100))
        self.class_classifier.add_module('c_bn2', nn.BatchNorm1d(100))
        self.class_classifier.add_module('c_relu2', nn.ReLU(True))
        self.class_classifier.add_module('c_fc3', nn.Linear(100, n_class))
        # self.class_classifier.add_module('c_softmax', nn.LogSoftmax(dim=1))
        
        self.domain_classifier = nn.Sequential()
        self.domain_classifier.add_module('d_fc1', nn.Linear(50 * 5 * 5, 100))
        self.domain_classifier.add_module('d_bn1', nn.BatchNorm1d(100))
        self.domain_classifier.add_module('d_relu1', nn.ReLU(True))
        self.domain_classifier.add_module('d_fc2', nn.Linear(100, source_num))
    
    def forward(self, input_data, alpha=1.0):
        # 		input_data = input_data.expand(input_data.data.shape[0], 3, 32, 32)
        batchsize = input_data.size(0)
        feature = self.feature(input_data)
        feature = feature.view(batchsize, -1)
        class_output = self.class_classifier(feature)
        reverse_feature = ReverseLayerF.apply(feature, alpha)
        domain_output = self.domain_classifier(reverse_feature)
        
        return class_output, domain_output


class GradReverse(Function):
    
    @staticmethod
    def forward(ctx, x, lamda):
        ctx.lamda = lamda
        
        return x.view_as(x)
    
    @staticmethod
    def backward(ctx, grad_output):
        output = (grad_output.neg() * ctx.lamda)
        
        return output, None
