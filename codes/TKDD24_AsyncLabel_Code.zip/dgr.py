import abc
import copy
import datetime
import math

import utils
from tqdm import tqdm
import torch
from torch import nn, optim
from torch.autograd import Variable
from torch.utils.data import ConcatDataset
import numpy as np


# ============
# Base Classes
# ============

class GenerativeMixin(object):
    """Mixin which defines a sampling iterface for a generative model."""
    
    def sample(self, size):
        raise NotImplementedError


class BatchTrainable(nn.Module, metaclass=abc.ABCMeta):
    """
    Abstract base class which defines a based training
    interface for a model.

    """
    
    @abc.abstractmethod
    def train_a_batch(self, x, y, x_=None, y_=None, idxs_=None, importance_of_new_task=.5):
        raise NotImplementedError


class Solver_Mine(BatchTrainable):
    """Abstract solver module of a scholar module"""
    
    def __init__(self):
        super().__init__()
        self.optimizer = None
        self.optimizer_hat = None
        self.criterion = None
        self.solver = None
    
    def solve(self, x):
        scores, _ = self.solver(x)
        _, predictions = torch.max(scores, 1)
        return predictions
    
    def set_optimizer(self, optimizer):
        self.optimizer = optimizer
    
    def set_optimizer_hat(self, optimizer_hat):
        self.optimizer_hat = optimizer_hat
    
    def set_criterion(self, criterion):
        self.criterion = criterion


class Stat():
    def __init__(self):
        self.stat_info = []
    
    def add(self, x):
        self.stat_info += [x]


def expWeight(correctness_list, gamma=0.1):
    tot = 0.0
    for c in correctness_list:
        tot += math.exp(-c * gamma)
    re = []
    for c in correctness_list:
        re.append(math.exp(-c * gamma) / tot)
    return re


class ConditionalScholar(GenerativeMixin, nn.Module):
    """Scholar for Deep Generative Replay with Conditional dependency on Source_H"""
    
    def __init__(self, label, solver, experiment, args):
        super().__init__()
        self.label = label
        # self.solver = None  # Solver = wgan.cirtic
        self.solver = solver
        self.SKETCH_pool = []
        self.source_H_pool = None
        self.beta_pool = None
        self.experiment = experiment
        self.args = args
        self.ALPHA = None
    
    def add_SKETCH(self, new_sketch, ALPHA):
        self.SKETCH_pool += [new_sketch]
        new_sketch_beta = new_sketch.beta.unsqueeze(0)
        if self.beta_pool is None:
            self.beta_pool = new_sketch_beta
        else:
            self.beta_pool = torch.cat((self.beta_pool, new_sketch_beta), dim=0)
        
        new_sketch_h = new_sketch.H
        new_sketch_h = new_sketch_h.unsqueeze(0)
        
        if ALPHA is not None:
            ALPHA = torch.cat((ALPHA, torch.tensor([1.0])), dim=0)
        self.args.logger.info('ALPHA: {}'.format(ALPHA))
        self.ALPHA = ALPHA
        self.solver.MMD_ALPHA = ALPHA
    
    def train_with_replay(
        self, current_dataset, scholar=None,
        received_labeled_dataset=None,
        importance_of_new_task=.5, batch_size=32,
        solver_iterations=1000,
        solver_training_callbacks=None,
        collate_fn=None,
        train_scholar=True,
        tot_result=None, feat_table=None, args=None,
        time_t=None, env=None, writer=None):
        # scholar and previous datasets cannot be given at the same time.
        # mutex_condition_infringed = all([
        # 	scholar is not None,
        # 	bool(previous_datasets)
        # ])
        # assert not mutex_condition_infringed, (
        # 	'scholar and previous datasets cannot be given at the same time'
        # )
        
        x_idx = current_dataset.domain_idx if current_dataset else -1
        y_idx = received_labeled_dataset.domain_idx if received_labeled_dataset else -1
        current_time = time_t - 1
        has_matched = -1
        
        if x_idx in self.solver.received_y_idx:
            has_matched = x_idx
            if 'AdaDelay' in args.method:
                lr = args.lr / math.sqrt(current_time - self.solver.received_y_idx.index(x_idx))
                args.new_lr = lr
                
                self.solver.optimizer = optim.SGD(
                    self.solver.solver.parameters(),
                    lr=lr, weight_decay=args.weight_decay,
                )
            self._train_batch_trainable_with_replay(
                self.solver, current_dataset, scholar,
                received_labeled_dataset=received_labeled_dataset,
                importance_of_new_task=importance_of_new_task,
                batch_size=batch_size,
                iterations=solver_iterations,
                training_callbacks=solver_training_callbacks,
                collate_fn=collate_fn,
                mode='receive_x',
                args=self.args,
                received_idx=x_idx,
                tot_result=None,
                feat_table=feat_table
            )
        
        if y_idx in self.solver.received_x_idx:
            has_matched = y_idx
            
            if 'AdaDelay' in args.method:
                lr = args.lr / math.sqrt(current_time - self.solver.received_x_idx.index(y_idx))
                args.new_lr = lr
                self.solver.optimizer = optim.SGD(
                    self.solver.solver.parameters(),
                    lr=lr, weight_decay=args.weight_decay,
                )
            
            self._train_batch_trainable_with_replay(
                self.solver, current_dataset, scholar,
                received_labeled_dataset=received_labeled_dataset,
                importance_of_new_task=importance_of_new_task,
                batch_size=batch_size,
                iterations=solver_iterations,
                training_callbacks=solver_training_callbacks,
                collate_fn=collate_fn,
                mode='receive_y',
                args=self.args,
                received_idx=y_idx,
                tot_result=None,
                feat_table=feat_table
            )
        
        if x_idx > 0:
            self.solver.received_x_idx.append(x_idx)
        
        if y_idx > 0:
            self.solver.received_y_idx.append(y_idx)
        
        # if received_labeled_dataset is not None:
        # 	# train the solver of the scholar.
        # 	self._train_batch_trainable_with_replay(
        # 		self.solver, current_dataset, scholar,
        # 		received_labeled_dataset=received_labeled_dataset,
        # 		importance_of_new_task=importance_of_new_task,
        # 		batch_size=batch_size,
        # 		iterations=solver_iterations,
        # 		training_callbacks=solver_training_callbacks,
        # 		collate_fn=collate_fn,
        # 		mode='w_hat',
        # 		args=self.args,
        # 		received_idx=received_labeled_dataset.domain_idx if received_labeled_dataset else 0,
        # 		tot_result=None,
        # 		feat_table=feat_table
        # 	)
        if has_matched >= 0:
            if 'OMD' in args.method:
                self.solver.solver_hat = copy.deepcopy(self.solver.modelpool[has_matched])
                
                self.solver.modelpool.append(copy.deepcopy(self.solver.solver_hat))
                
                print()
                args.logger.info('Receive matching data, modelpool length: {}'.format(len(self.solver.modelpool)))
                
                self.solver.solver = copy.deepcopy(self.solver.modelpool[-1])
                if 'OMDLastOp' in args.method:
                    self.solver.optimizer = optim.SGD(
                        self.solver.solver.parameters(),
                        lr=args.lr / 8.0, weight_decay=args.weight_decay,
                    )
                else:
                    lr = args.lr
                    if 'data.port' in args.experiment and "OMDEnsemble_LACH" in args.method:
                        lr = lr / 10.0
                    self.solver.optimizer = optim.SGD(
                        self.solver.solver.parameters(),
                        lr=lr, weight_decay=args.weight_decay,
                    )
        
        if has_matched < 0:  # not received (x,y) pair:
            if 'OMD' in args.method:
                # Not received any data, create a new \hat{w}
                new_w_hat, _ = self.solver.new_model()
                
                cuda = torch.cuda.is_available() and args.cuda
                if cuda:
                    new_w_hat = new_w_hat.cuda()
                    new_w_hat = nn.DataParallel(new_w_hat)
                self.solver.solver_hat = copy.deepcopy(new_w_hat)
                
                self.solver.modelpool.append(copy.deepcopy(self.solver.solver_hat))
                
                print()
                args.logger.info('Not receive matching Data, modelpool length: {}'.format(len(self.solver.modelpool)))
                
                self.solver.solver = copy.deepcopy(self.solver.modelpool[-1])
                if 'OMDLastOp' in args.method:
                    self.solver.optimizer = optim.SGD(
                        self.solver.solver.parameters(),
                        lr=args.lr / 5.0, weight_decay=args.weight_decay,
                    )
                else:
                    lr = args.lr
                    if 'data.port' in args.experiment and "OMDEnsemble_LACH" in args.method:
                        lr = lr / 10.0
                    self.solver.optimizer = optim.SGD(
                        self.solver.solver.parameters(),
                        lr=lr, weight_decay=args.weight_decay,
                    )
        
        self_train_solver_iterations = solver_iterations
        
        if ('data.ts' in args.experiment or 'data.port' in args.experiment) and \
            ('OMD' in args.method or 'OGDSelfTraining' in args.method or 'FF' == args.method):
            self_train_solver_iterations = 10
        
        if ('data.port' in args.experiment) and \
            ('OMD' in args.method or 'OGDSelfTraining' in args.method or 'FF' == args.method):
            self_train_solver_iterations = 5
        
        if ('data.iot' in args.experiment) and \
            ('OMD' in args.method or 'OGDSelfTraining' in args.method or 'FF' == args.method):
            self_train_solver_iterations = 10
        
        if 'data.Bsim' in args.experiment and 'OGDSelfTraining' in args.method:
            self_train_solver_iterations = self_train_solver_iterations * args.selftraining_times
        
        # args.logger.info('{} {} {}'.format(current_time + 1, x_idx, y_idx))
        
        if x_idx == current_time:
            if ('OMD' in args.method and 'OMDNoOp' not in args.method and 'NoX' not in args.method) \
                or 'OGDSelfTraining' in args.method or 'FF' == args.method:  # if OMD, then use Optimism to update w
                # if 'data.loan' not in args.experiment or time_t <= 60:
                self._train_batch_trainable_with_replay(
                    self.solver, current_dataset, scholar,
                    received_labeled_dataset=received_labeled_dataset,
                    importance_of_new_task=importance_of_new_task,
                    batch_size=batch_size,
                    iterations=self_train_solver_iterations,
                    training_callbacks=solver_training_callbacks,
                    collate_fn=collate_fn,
                    mode='w_x',  # has x but missing y
                    args=self.args,
                    received_idx=x_idx,
                    tot_result=None,
                    feat_table=feat_table,
                    time_t=time_t,
                    tot_T=args.tot_T,
                )
        else:
            # if ('OMD' in args.method and 'OMDNoOp' not in args.method) \
            # 	or 'OGDSelfTraining' in args.method:  # if OMD, then use Optimism to update w
            if "OMDEnsemble_LACH" in args.method and 'NoY' not in args.method:
                # if 'data.loan' not in args.experiment or time_t <= 60:
                self._train_batch_trainable_with_replay(
                    self.solver, current_dataset, scholar,
                    received_labeled_dataset=received_labeled_dataset,
                    importance_of_new_task=importance_of_new_task,
                    batch_size=batch_size,
                    iterations=self_train_solver_iterations,
                    training_callbacks=solver_training_callbacks,
                    collate_fn=collate_fn,
                    mode='w_y',  # has y but missing x
                    args=self.args,
                    received_idx=y_idx,
                    tot_result=None,
                    feat_table=feat_table,
                    time_t=time_t,
                    tot_T=args.tot_T,
                )
        
        if 'OMD' in args.method or 'FF' == args.method:
            self.solver.modelpool_w.append(copy.deepcopy(self.solver.solver))
            self.solver.correctness_w_pool.append(0)
        
        # Calculate Accumulated Regret of {w}_t on current data xt, yt
        for callback in (solver_training_callbacks or []):
            callback(self.solver, result=None, progress=time_t, batch_index=None, remark='AccumulateRegret')
    
    @property
    def name(self):
        return self.label
    
    def _get_confidence_q(self, confidence_q_min, confidence_q_max, batch_index, iterations):
        start_ratio = 0.3
        conf_q = confidence_q_max - max(
            min(1 / (1 - start_ratio) * (batch_index / iterations - start_ratio), 1.0), 0.0) * \
                 (confidence_q_max - confidence_q_min)
        return conf_q
    
    def _get_alpha(self, batch_index, iterations, get_alpha_rate):
        p = float(batch_index / iterations)
        # alpha = 2.0 / (1.0 + np.exp(-5.0 * p)) - 1.0
        alpha = 2.0 / (1.0 + np.exp(-get_alpha_rate * p)) - 1.0
        return alpha
    
    # return 1.0
    
    def _train_batch_trainable_with_replay(
        self, trainable, current_dataset, scholar=None,
        received_labeled_dataset=None,
        importance_of_new_task=.5, batch_size=32, iterations=1000,
        training_callbacks=None, collate_fn=None, mode='', args=None,
        received_data=False, received_idx=None, tot_result=None, feat_table=None,
        time_t=0, tot_T=0):
        # do not train the model when given non-positive iterations.
        if iterations <= 0:
            return
        
        if ('OMD' in args.method or 'OGDSelfTraining' in args.method or 'FF' == args.method) and mode == 'w_x':
            # confidence_q = 0.95
            confidence_q_max = 1.0
            confidence_q_min = 0.4
            
            if 'data.port' in args.experiment:
                confidence_q_max = 1.0
                confidence_q_min = 0.85
            
            if 'data.ts' in args.experiment:
                confidence_q_max = 1.0
                confidence_q_min = 0.2
            
            if 'data.loan' or 'data.iot' in args.experiment:
                confidence_q_max = 1.0
                confidence_q_min = 0.7
            
            confidence_q = self._get_confidence_q(confidence_q_min, confidence_q_max, time_t, tot_T)
            
            # if 'FF' == args.method:
            # 	confidence_q = 0.5
            
            if hasattr(args, 'confidence_q'):
                confidence_q = args.confidence_q
            
            args.logger.info('confidence: {}/{}: {}'.format(time_t, tot_T, confidence_q))
        # create data loaders.
        if 'data.ts' in args.experiment:  # TS experiment
            get_alpha_rate = 5.0
        else:
            get_alpha_rate = 10.0
        
        if 'wisdm' in args.ts_dataset_name or 'data.loan' in args.experiment:
            tot_drop_last = False
        else:
            tot_drop_last = True
        
        args.logger.info('>> Len Tot_dataset:{}, Len Labeled Dataset: {}'.format(
            len(current_dataset) if current_dataset else 0,
            len(received_labeled_dataset) if received_labeled_dataset else 0))
        
        data_loader_current = iter(utils.get_data_loader(
            current_dataset, batch_size, cuda=self._is_on_cuda(),
            collate_fn=collate_fn, drop_last=tot_drop_last
        )) if current_dataset else None
        
        data_loader_received_labeled = iter(utils.get_data_loader(
            received_labeled_dataset, batch_size, cuda=self._is_on_cuda(),
            collate_fn=collate_fn, drop_last=False,
        )) if received_labeled_dataset else None
        
        # if data_loader_received_labeled is not None and (mode == 'receive_x' or mode == 'receive_y'):
        # 	args.logger.info('>> Mode: Received previous data: (Train w_hat with labeled data)')
        # 	args.logger.info('>> Train Mode: {}'.format(mode))
        
        # if data_loader_current is not None and mode == 'w_x':
        # 	# Optimism
        
        args.logger.info('>> Train Mode: {}'.format(mode))
        
        # define a tqdm progress bar.
        progress = tqdm(range(1, iterations + 1))
        
        txt_set = set()
        for batch_index in progress:
            # decide from where to sample the training data.
            from_scholar = scholar is not None
            # from_previous_datasets = bool(previous_datasets)
            cuda = self._is_on_cuda()
            if self.source_H_pool is None:
                source_idx = 1
            else:
                source_idx = self.source_H_pool.size(0) + 1
            
            # xu_ = _ = s_xu_ = None
            y_op_true = None
            
            if data_loader_current:
                try:
                    x_optimism, y_op_true, t_optimism = next(data_loader_current)
                except StopIteration:
                    data_loader_current = iter(utils.get_data_loader(
                        current_dataset, batch_size, cuda=self._is_on_cuda(),
                        collate_fn=collate_fn, drop_last=tot_drop_last
                    ))
                    x_optimism, y_op_true, t_optimism = next(data_loader_current)
            else:
                x_optimism = y_op_true = t_optimism = y_optimism = None
            
            x_optimism = Variable(x_optimism).cuda() if cuda else Variable(x_optimism)
            t_optimism = Variable(t_optimism).cuda() if cuda else Variable(t_optimism)
            y_op_true = Variable(y_op_true).cuda() if cuda else Variable(y_op_true)
            y_optimism = None
            
            if mode == 'w_x':
                txt = 'Original X_Op Shape: {}'.format(x_optimism.shape)
                if txt not in txt_set:
                    args.logger.info(txt)
                    txt_set.add(txt)
            
            if data_loader_received_labeled is not None:
                try:
                    x_received, y_received, t_received = next(data_loader_received_labeled)
                except StopIteration:
                    data_loader_received_labeled = iter(utils.get_data_loader(
                        received_labeled_dataset, batch_size, cuda=self._is_on_cuda(),
                        collate_fn=collate_fn, drop_last=False,
                    ))
                    x_received, y_received, t_received = next(data_loader_received_labeled)
                
                x_received = Variable(x_received).cuda() if cuda else Variable(x_received)
                y_received = Variable(y_received).cuda() if cuda else Variable(y_received)
                t_received = Variable(t_received).cuda() if cuda else Variable(t_received)
                x_re_op = None
            else:
                x_received = y_received = t_received = x_re_op = None
            # print(x_received, y_received)
            # xl_ = yl_ = s_xl_ = None
            
            if mode == 'receive_x' and x_optimism is not None:  # update correctness
                if "OMDEnsemble_LACH" in args.method:
                    for i in range(1, min(args.delay, current_dataset.domain_idx)):
                        probs, _ = self.solver.modelpool_w[-i](
                            x_optimism, None, out='C'
                        )
                        y_pred = probs.detach()
                        loss = self.solver.loss_class(y_pred, y_op_true).detach().item()
                        self.solver.correctness_w_pool[-i] = \
                            self.solver.correctness_w_pool[-i] * 0.8 + loss  # gamma=0.8
                    
                    # update label mean
                    for i in range(x_optimism.shape[0]):
                        if 'sim' in args.experiment:
                            y_now = 0
                        else:
                            y_now = y_op_true[i]
                        if self.solver.x_label_mean[y_now] is None:
                            self.solver.x_label_mean[y_now] = x_optimism[i]
                        else:
                            self.solver.x_label_mean[y_now] = self.solver.x_label_mean[y_now] * 0.5 \
                                                              + x_optimism[i] * 0.5
            
            if mode == 'receive_y' and x_received is not None:  # update correctness
                if "OMDEnsemble_LACH" in args.method:
                    for i in range(1, min(args.delay, received_labeled_dataset.domain_idx)):
                        probs, _ = self.solver.modelpool_w[-i](
                            x_received, None, out='C'
                        )
                        y_pred = probs.detach()
                        loss = self.solver.loss_class(y_pred, y_received).detach().item()
                        self.solver.correctness_w_pool[-i] = \
                            self.solver.correctness_w_pool[-i] * 0.8 + loss  # gamma=0.8
                    
                    # update label mean
                    for i in range(x_received.shape[0]):
                        if 'sim' in args.experiment:
                            y_now = 0
                        else:
                            y_now = y_received[i]
                        if self.solver.x_label_mean[y_now] is None:
                            self.solver.x_label_mean[y_now] = x_received[i]
                        else:
                            self.solver.x_label_mean[y_now] = self.solver.x_label_mean[y_now] * 0.5 \
                                                              + x_received[i] * 0.5
            
            if mode == 'w_x':
                if 'OMD' in args.method or 'OGDSelfTraining' in args.method or 'FF' == args.method:
                    # implement y_optimism
                    if 'OMDLastOp' in args.method:
                        if current_dataset.domain_idx - args.delay >= 0:
                            probs, _ = self.solver.modelpool_w[received_idx - args.delay](
                                x_optimism, None, out='C'  # Use Last Gradient
                            )
                            y_optimism = torch.softmax(probs.detach(), 1).detach()
                        
                        # probs, _ = self.solver.solver(
                        # 	x_optimism, None, out='C'
                        # )
                        
                        else:
                            y_optimism = None
                    if 'FF' == args.method:
                        weight = 1.0
                        weights = []
                        for i in range(1, min(len(self.solver.modelpool_w), 4)):
                            weights.append(weight)
                            weight *= 0.8
                        
                        weights = torch.tensor(weights)
                        weights = weights / (weights.sum() + 1e-7)
                        for i in range(1, min(len(self.solver.modelpool_w), 4)):
                            probs, _ = self.solver.modelpool_w[-i](
                                x_optimism, None, out='C'  # Use Last Gradient
                            )
                            
                            # args.logger.info('{} {}'.format(x_optimism.shape, probs.shape))
                            if y_optimism is None:
                                y_optimism = torch.softmax(probs.detach(), 1) * weights[i - 1]
                            else:
                                y_optimism += torch.softmax(probs.detach(), 1) * weights[i - 1]
                    
                    elif "OMDEnsemble_LACH" in args.method:
                        y_optimism = None
                        length = args.delay
                        if 'data.port' in args.experiment:
                            length = args.delay + 1
                        weights = expWeight(self.solver.correctness_w_pool[- min(length, current_dataset.domain_idx):])
                        for i in range(1, min(length, current_dataset.domain_idx)):
                            probs, _ = self.solver.modelpool_w[-i](
                                x_optimism, None, out='C'  # Use Last Gradient
                            )
                            
                            # args.logger.info('{} {}'.format(x_optimism.shape, probs.shape))
                            if y_optimism is None:
                                if 'data.sim' in args.experiment or 'data.Bsim' in args.experiment:
                                    y_optimism = probs.detach() * weights[-i]
                                else:
                                    y_optimism = torch.softmax(probs.detach(), 1) * weights[-i]
                            else:
                                if 'data.sim' in args.experiment or 'data.Bsim' in args.experiment:
                                    y_optimism += probs.detach() * weights[-i]
                                else:
                                    y_optimism += torch.softmax(probs.detach(), 1) * weights[-i]
                    # args.logger.info('{}'.format(y_optimism.shape))  # [128, 6]
                    elif 'OGDSelfTraining' in args.method:  # OMD Self-Training
                        probs, _ = self.solver.solver(
                            x_optimism, None, out='C'  # Use Last Gradient
                        )
                        y_optimism = torch.softmax(probs.detach(), 1).detach()
                    else:
                        y_optimism = None
                
                # convert y_optimism to class
                if y_optimism is not None:
                    y_op_all = copy.deepcopy(y_optimism.detach().cpu()).to(torch.float32)
                    x_all = copy.deepcopy(x_optimism.detach().cpu()).to(torch.float32)
                    y_true_all = copy.deepcopy(y_op_true.detach().cpu()).to(torch.float32)
                    conf_all = copy.deepcopy(y_optimism.detach().cpu()).to(torch.float32)
                    conf_op_filter = copy.deepcopy(y_optimism.detach().cpu()).to(torch.float32)
                    if 'data.sim' not in args.experiment and 'data.Bsim' not in args.experiment:
                        # args.logger.info('y_prob at t={}: {} {}'.format(time_t, y_optimism.shape, y_optimism))
                        conf, y = torch.max(y_optimism, 1)
                        y_op_all = copy.deepcopy(y.detach().cpu()).to(torch.float32)
                        threshold = torch.quantile(conf, confidence_q)
                        
                        conf_idx = (conf >= threshold)
                        if torch.sum(conf_idx) == 0:
                            conf_idx = [0]
                        
                        if 'data.ts' in args.experiment and torch.sum(
                            conf_idx) <= 1:  # arbitrary choose 2 index to be true
                            result = None
                            args.logger.info('Not Enough Pseudo-label, unable to train w.')
                            return
                        conf_all = copy.deepcopy(y_optimism.detach().cpu()).to(torch.float32)
                        conf_op_filter = copy.deepcopy(y_optimism[conf_idx].detach().cpu()).to(torch.float32)
                        # conf_idx[0] = True
                        # if torch.sum(conf_idx) <= 1:
                        # 	conf_idx[1] = True
                        
                        xq = x_optimism[conf_idx]
                        yq = y[conf_idx]
                        
                        # y_optimism = y
                        y_optimism = yq
                        x_optimism = xq
                        y_op_true = y_op_true[conf_idx]
                
                if y_optimism is not None:
                    txt = 'X_Op Shape: {}, Y_Op Shape: {}'.format(x_optimism.shape, y_optimism.shape)
                    if txt not in txt_set:
                        args.logger.info(txt)
                        txt_set.add(txt)
                    
                    received_data = {}
                    received_data['y_op_filter'] = y_optimism.detach().cpu().to(torch.float32)
                    received_data['y_true_filter'] = y_op_true.detach().cpu().to(torch.float32)
                    received_data['x_filter'] = x_optimism.detach().cpu().to(torch.float32)
                    received_data['conf_op_filter'] = conf_op_filter
                    
                    received_data['solver'] = self.solver.solver
                    if 'OMDLastOp' in args.method and 'data.loan' in args.experiment:
                        received_data['solver_op'] = self.solver.modelpool_w[received_idx - args.delay]
                    
                    received_data['conf_all'] = conf_all
                    received_data['y_op_all'] = y_op_all
                    received_data['x_all'] = x_all
                    received_data['y_true_all'] = y_true_all
                    
                    for callback in (training_callbacks or []):
                        callback(trainable, progress=time_t, batch_index=None,
                                 result=None,
                                 received_data=received_data,
                                 remark='Optimism')
            
            if mode == 'w_y':
                has_mean = True
                for i in range(args.classes):
                    if self.solver.x_label_mean[i] is None:
                        has_mean = False
                # 	estimate x_t by y_t
                if "OMDEnsemble_LACH" in args.method and has_mean:
                    
                    txt = 'Use Label Mean to Estimate X'
                    if txt not in txt_set:
                        args.logger.info(txt)
                        txt_set.add(txt)
                    
                    if 'sim' in args.experiment:
                        x_re_op = self.solver.x_label_mean[0]
                    else:
                        x_re_op = torch.zeros_like(x_received)
                        for i in range(x_received.shape[0]):
                            x_re_op[i] = self.solver.x_label_mean[y_received[i]]
            
            # if 'self-training' in args.method:
            # 	# real_prec = -1
            # 	# if source_idx > 1:  # time step t > 1, then unsupervised. Try Pseudo Label.
            # 	# print('>> Current step: {}, No Label!'.format(source_idx))
            # 	# self.experiment
            # 	y = None  # No label for t > 1
            # 	# NO PL NOW!!!
            # 	# true_y = y
            # 	# confidence_q = self._get_confidence_q(confidence_q_min, confidence_q_max, batch_index,
            # 	# 									  iterations)
            #
            # 	# print('\n\n', confidence_q)
            # 	# idxs = (torch.ones(xu.size(0)) * -1).long()
            # 	scores, _ = self.solver.solver(
            # 		x_optimism, None, out='C'
            # 	)
            # 	# print(scores[0])  # need to sigmoid,
            # 	conf, y = torch.max(torch.softmax(scores, 1), 1)
            # 	threshold = torch.quantile(conf, confidence_q)
            # 	conf_idx = (conf >= threshold)
            # 	if torch.sum(conf_idx) == 0:
            # 		conf_idx = [0]
            # 	xq = x_optimism[conf_idx]
            # 	yq = y[conf_idx]
            # 	sq = t_optimism[conf_idx]
            # 	if x_received is None:  # add self-training datas into labeled data
            # 		x_received = xq
            # 	else:
            # 		x_received = torch.cat((x_received, xq), dim=0)
            # 	if y_received is None:
            # 		y_received = yq
            # 	else:
            # 		y_received = torch.cat((y_received, yq), dim=0)
            # 	if t_received is None:
            # 		t_received = sq
            # 	else:
            # 		t_received = torch.cat((t_received, sq), dim=0)
            
            result = trainable.train_a_batch(  # Train Source Classifier
                x_optimism=x_optimism, y_optimism=y_optimism, t_optimism=t_optimism,
                y_op_true=y_op_true,
                x_received=x_received, y_received=y_received, t_received=t_received,
                x_re_op=x_re_op,
                importance_of_new_task=importance_of_new_task,
                alpha=self._get_alpha(batch_index, iterations, get_alpha_rate),
                batch_index=batch_index,
                current_idx=source_idx, args=args,
                feat_table=feat_table,
                train_mode=mode, txt_set=txt_set
            )
            # if batch_index % 100 == 0:
            # 	print(self._get_alpha(batch_index, iterations))
            
            # def cb(solver, progress, batch_index, result, received_data=False, remark=''):
            for callback in (training_callbacks or []):
                callback(trainable, progress, batch_index, result, received_data, remark=mode)
    
    def _is_on_cuda(self):
        return next(self.parameters()).is_cuda
