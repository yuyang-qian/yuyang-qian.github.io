import pickle

from torch.utils.tensorboard import SummaryWriter
import datetime
import os.path
import copy
import time
import torchvision
from torch import optim
from torch import nn
from torchvision import transforms
from feat_table import Feat_Tabel

import utils
import torch
import numpy as np
import torch.nn.functional as F
import torchvision.models as models
import os
from data import LabeledDataset, UnlabeledDataset
from sklearn.cluster import KMeans


def KMEANS(x, CLUSTER_NUM):
    estimator = KMeans(n_clusters=CLUSTER_NUM, max_iter=30)
    estimator.fit(x.numpy())
    centroids = estimator.cluster_centers_
    centroids = torch.from_numpy(centroids)
    
    TOTAL_NUMBER = len(x)
    
    re = []
    for j in range(CLUSTER_NUM):
        cluster_tmp = centroids[j, :].view(1, -1).repeat(TOTAL_NUMBER, 1)
        minus_tmp = x - cluster_tmp
        minus_tmp = minus_tmp.abs().sum(dim=1)
        id_choose = torch.argmin(minus_tmp)
        re += [id_choose.item()]
    
    re = torch.tensor(re).long()
    # print(re.shape)
    return re


class TotStat():
    def __init__(self):
        self.regret_info = []
        self.errs_star = None  # to compute the Regret
        self.dics = {}
    
    def add_regret(self, x):
        self.regret_info += [x]
    
    def add_by_name(self, x, name):
        if name not in self.dics.keys():
            self.dics[name] = []
        self.dics[name].append(x)
    
    def mean_name(self, start=0, name=''):
        stat_info = self.dics[name]
        if len(stat_info) == 0:
            return 0
        re = 0.0
        for i in range(start, len(stat_info)):
            re += np.mean(stat_info[i])
        return re / (len(stat_info) - start + 1e-16)
    
    def sum(self, start=0):
        if len(self.regret_info) == 0:
            return 0.0
        re = 0.0
        for i in range(start, len(self.regret_info)):
            re += np.mean(self.regret_info[i])
        return re
    
    def max(self, start=0):
        if len(self.regret_info) == 0:
            return 0
        re = 0.0
        for i in range(start, len(self.regret_info)):
            re += np.max(self.regret_info[i])
        return re / (len(self.regret_info) - start + 1e-16)
    
    def AccumulateRegret(self, start=0):
        if len(self.regret_info) == 0:
            return 0.0
        re = 0.0
        
        for i in range(start, len(self.regret_info)):
            re += np.mean(self.regret_info[i])
            if self.errs_star is not None:
                re -= self.errs_star[i]
        return re


def train(scholar, train_datasets, received_datasets, ori_datasets, replay_mode,
          solver_iterations=1000,
          importance_of_new_task=.5,
          batch_size=32,
          test_size=1024,
          sample_size=36,
          lr=1e-03, weight_decay=1e-05,
          solver_lr=-1,
          beta1=.5, beta2=.9,
          loss_log_interval=30,
          eval_log_interval=50,
          image_log_interval=100,
          sample_log_interval=300,
          sample_log=False,
          sample_dir='./samples',
          checkpoint_dir='./checkpoints',
          collate_fn=None,
          cuda=False,
          task_name='main',
          Sketch_M=100,
          N_l=200,
          SKETCH_gamma=1.0,
          numDim=512,
          dataset_config=None,
          args=None,
          errs_star=None):
    N_l = args.N_l
    args.logger.info('\n ****** {} ******\n'.format(task_name))
    writer = SummaryWriter('./log/{}'.format(task_name))
    
    if 'data.sim' in args.experiment or 'data.Bsim' in args.experiment:
        solver_criterion = nn.MSELoss()
    else:
        solver_criterion = nn.CrossEntropyLoss()
    
    # tot_stat_msuda = TotStat()
    # tot_stat_ssl = TotStat()
    tot_stat_regret = TotStat()
    tot_stat_regret.errs_star = errs_star
    
    if solver_lr == -1:
        solver_lr = lr
    
    # solver_optimizer = optim.Adam(
    # 	scholar.solver.solver.parameters(),
    # 	lr=solver_lr, weight_decay=weight_decay, betas=(beta1, beta2),
    # )
    
    solver_optimizer = optim.SGD(
        scholar.solver.solver.parameters(),
        lr=solver_lr, weight_decay=weight_decay,
    )
    # if 'OMD' in args.method:
    # 	solver_hat_optimizer = optim.SGD(
    # 		scholar.solver.solver_hat.parameters(),
    # 		lr=solver_lr, weight_decay=weight_decay,
    # 	)
    #
    # 	scholar.solver.set_optimizer_hat(solver_hat_optimizer)
    
    # scholar.solver.modelpool.append(scholar.solver.solver_hat)
    # scholar.solver.modelpool.append(scholar.solver.solver)
    
    scholar.solver.set_criterion(solver_criterion)
    scholar.solver.set_optimizer(solver_optimizer)
    ini_solver = copy.deepcopy(scholar.solver.solver)
    scholar.train()
    
    # define the previous scholar who will generate samples of previous tasks.
    previous_scholar = None
    previous_datasets = None
    previous_datasets_labeled = None
    
    feat_table = []
    
    for time_t, train_dataset in enumerate(train_datasets, 1):
        feat_table += [Feat_Tabel()]
        args.logger.info('t = {}:'.format(time_t))
        TRAINSCHOLAR = True if replay_mode == 'gan' else False
        if TRAINSCHOLAR and utils.check_checkpoint(scholar, checkpoint_dir, 'Scholar', 't={}'.format(time_t)):
            args.logger.info('\t>> Found pre-trained Scholar model. Loading...')
            TRAINSCHOLAR = False
            ori_scholar = copy.deepcopy(scholar)
            utils.load_checkpoint(ori_scholar, checkpoint_dir, 'Scholar', 't={}'.format(time_t))
        else:
            if TRAINSCHOLAR:
                args.logger.info('\t>> Pre-trained Scholar model not found!')
        # print(type(train_dataset))
        
        # train_data = train_dataset.data
        # train_label = train_dataset.labels
        
        # data_transform = train_dataset.transform
        # target_transform = train_dataset.target_transform
        
        # ori_train_data = copy.deepcopy(train_data)
        # ori_train_label = copy.deepcopy(train_label)
        
        # if torch.is_tensor(train_data):
        # 	train_data = train_data.clone().detach()
        # else:
        # 	train_data = torch.from_numpy(train_data)
        
        solver_training_callbacks = [_solver_training_callback(
            loss_log_interval=loss_log_interval,
            eval_log_interval=eval_log_interval,
            current_task=time_t,
            total_tasks=len(train_datasets),
            total_iterations=solver_iterations,
            # total_iterations=solver_iterations if task > 1 else 105,
            batch_size=batch_size,
            test_size=test_size,
            test_datasets=ori_datasets,
            replay_mode=replay_mode,
            cuda=cuda,
            collate_fn=collate_fn,
            env=scholar.name,
            writer=writer,
            tot_stat_regret=tot_stat_regret,
            args=args
        )]
        
        received_labeled_dataset = received_datasets[time_t - 1]
        if received_labeled_dataset is None:
            args.logger.info('***At t={}, not received dataset***'.format(time_t))
        else:
            args.logger.info(
                '***At t={}, received dataset from t={}***'.format(time_t, received_labeled_dataset.domain_idx + 1))
        
        # Train New model in SSL Mode.
        scholar.train_with_replay(
            current_dataset=train_dataset,
            received_labeled_dataset=received_labeled_dataset,  # Current Domain: Label+Unlabeled, SSL
            scholar=previous_scholar,
            importance_of_new_task=importance_of_new_task,
            batch_size=batch_size,
            solver_iterations=solver_iterations,
            solver_training_callbacks=solver_training_callbacks,
            collate_fn=collate_fn,
            train_scholar=False,
            tot_result=None,
            feat_table=feat_table,
            args=args,
            time_t=time_t,
            env=scholar.name,
            writer=writer,
        )
        
        previous_scholar = None
        previous_datasets = None
        previous_datasets_labeled = None
        
        # save the model after the experiment.
        print()
        if TRAINSCHOLAR:
            utils.save_checkpoint(scholar, checkpoint_dir, 'Scholar', 't={}'.format(time_t))
        
        # if 'CONDOR' in args.method or "OMDEnsemble_LACH" in args.method:
        # 	# Add model to CONDOR Model pool:
        # 	# tmp_model = copy.deepcopy(scholar.solver)
        # 	#
        # 	# tmp_optimizer = optim.SGD(
        # 	# 	tmp_model.parameters(),
        # 	# 	lr=solver_lr, weight_decay=weight_decay,
        # 	# )
        # 	# scholar.solver.modelpool.append(tmp_model)
        # 	# scholar.solver.optimizerpool.append(tmp_optimizer)
        # 	scholar.solver.betapool = [1.0 / time_t] * time_t
        
        # scholar.solver.solver = copy.deepcopy(ini_solver)
        # solver_optimizer = optim.SGD(
        # 	scholar.solver.solver.parameters(),
        # 	lr=solver_lr, weight_decay=weight_decay,
        # )
        # scholar.solver.set_criterion(solver_criterion)
        # scholar.solver.set_optimizer(solver_optimizer)
        
        args.logger.info('')
        print()
    
    # print(tot_stat_msuda.stat_info)
    args.logger.info(
        'Conclusion: | {method} | Prec: {sslavg:.2f} | AUC: {aucavg:.2f} | Regret: {regret:.2f}\n\n'.format(
            method=args.method,
            sslavg=tot_stat_regret.mean_name(start=0, name='prec') * 100.0,
            aucavg=tot_stat_regret.mean_name(start=0, name='auc') * 100.0,
            regret=tot_stat_regret.AccumulateRegret() * 1.0,
        ))


def _solver_training_callback(
    loss_log_interval,
    eval_log_interval,
    current_task,
    total_tasks,
    total_iterations,
    batch_size,
    test_size,
    test_datasets,
    cuda,
    replay_mode,
    collate_fn,
    env,
    writer,
    tot_stat_regret,
    args):
    def cb(solver, progress, batch_index, result, received_data=False, remark=''):
        
        # global acc_regret
        # acc_regret = 0.0
        
        if remark == 'AccumulateRegret':
            args.logger.info('Calculate Accumulated Regret on Dataset {}'.format(progress))
            test_dataset = test_datasets[progress - 1]
            lo, pr, others = utils.validate(
                solver, test_dataset, test_size=test_size,
                cuda=cuda, verbose=True, collate_fn=collate_fn,
                cal_regret=True, args=args
            )
            loss = lo
            precs = pr
            auc = others['auc_score']
            
            tot_stat_regret.add_regret(loss)
            tot_stat_regret.add_by_name(loss, 'loss')
            
            if progress > args.delay:
                tot_stat_regret.add_by_name(auc, 'auc')
                tot_stat_regret.add_by_name(pr, 'prec')
            
            writer.add_scalar(env + '/loss/Accumulate Regret', tot_stat_regret.AccumulateRegret(), progress)
            writer.add_scalar(env + '/loss/Accumulate Loss', tot_stat_regret.sum(), progress)
            writer.add_scalar(env + '/loss/Online Prec', pr, progress)
            writer.add_scalar(env + '/loss/Online AUC', auc, progress)
            
            args.logger.info(
                '** Delay={}, Var={}, t={}, ** Online Prec: {}'.format(args.delay, args.model_var, progress, precs))
            
            args.logger.info(
                '** Delay={}, Var={}, t={}, ** Online AUC: {}'.format(args.delay, args.model_var, progress, auc))
            
            args.logger.info(
                '** Delay={}, Var={}, t={}, ** Accumulate Loss: {}'.format(args.delay, args.model_var, progress,
                                                                           tot_stat_regret.sum()))
            args.logger.info(
                '** Delay={}, Var={}, t={}, ** Accumulate Regret: {}'.format(args.delay, args.model_var, progress,
                                                                             tot_stat_regret.AccumulateRegret()))
        
        elif remark == 'Optimism':
            # if test_datasets[0].remark == 'sim':
            y_op = received_data['y_op_filter']
            y = received_data['y_true_filter']
            
            writer.add_scalar(env + '/loss/||Y - Y_Op||', torch.norm(y - y_op, p=1) / len(y), progress)
            # writer.add_scalar(env + '/loss/||Y - Y_Op||', torch.norm(result - received_data), progress)
            # args.logger.info('Y_op at t={}: {}'.format(progress, y_op))
            if 'data.loan' in args.experiment:
                save_path = args.logger.parent_path + '/saved_optimism/'
                args.logger.info('Saving optimism in {}{}.pkl'.format(save_path, progress))
                
                if not os.path.exists(save_path):
                    os.makedirs(save_path)
                
                with open('{}{}.pkl'.format(save_path, progress), 'wb') as handle:
                    pickle.dump(received_data, handle, protocol=pickle.HIGHEST_PROTOCOL)
        
        else:
            iteration = max(2 * current_task - 3, 0) * total_iterations + batch_index
            if remark == 'w' and current_task != 1:
                iteration += total_iterations
            progress.set_description((
                '<CS> '
                't/T: {task}/{tasks} | '
                '[{trained}/{total}] {percentage:.0f}% | '
                'c_loss: {loss:.4} | '
                'c_prec: {prec:.4}'
            ).format(
                task=current_task,
                tasks=total_tasks,
                trained=batch_index * batch_size,
                total=total_iterations * batch_size,
                percentage=(100. * batch_index / total_iterations),
                loss=result['loss'] if result else 0.0,
                prec=result['precision'] if result else 0.0,
            ))
            
            # log the loss of the solver.
            if iteration % loss_log_interval == 0:
                # visual.visualize_scalar(
                # 	result['loss'], 'solver loss', iteration, env=env
                # )
                writer.add_scalar(env + '/loss/C_Train_Loss', result['loss'] if result else 0.0, iteration * batch_size)
            
            # evaluate the solver on multiple tasks.
            if iteration % eval_log_interval == 0:
                # names = ['task {}'.format(i + 1) for i in range(len(test_datasets))]
                
                # for i in range(len(test_datasets)):
                test_dataset = test_datasets[current_task - 1]
                lo, pr, others = utils.validate(
                    solver, test_dataset, test_size=test_size,
                    cuda=cuda, verbose=False, collate_fn=collate_fn, args=args
                )
                losses = lo
                precs = pr
                
                # print('Test at t={}, losses: {}, precs: {}'.format(current_task - 1, lo, pr))
                
                # Add to Stat info:
                # tot_prec.add_regret(precs)
                
                # title = 'C_Test_Prec({replay_mode})'.format(replay_mode=replay_mode)
                # scalar_dic = {}
                # for ii, name in enumerate(names):
                # name = names[current_task - 1]
                # scalar_dic[name] = precs
                
                # writer.add_scalars(env + '/' + title, scalar_dic, iteration * batch_size)
                writer.add_scalar(env + '/loss/Test_loss', losses, iteration * batch_size)
                writer.add_scalar(env + '/loss/Test_Precision', precs, iteration * batch_size)
    
    return cb
