import os
import pandas as pd
import numpy as np

from tqdm import tqdm

pd.set_option('display.max_columns', None)

columns = [
    "loan_amnt", "int_rate", "installment", "home_ownership",
    "annual_inc", "verification_status", 'term', "issue_d", "loan_status",
    "pymnt_plan", "dti", "delinq_2yrs", "inq_last_6mths",
    "open_acc", "pub_rec", "revol_bal", "total_acc",
    "initial_list_status", "out_prncp", "out_prncp_inv", "total_pymnt",
    "total_pymnt_inv", "total_rec_prncp", "total_rec_int", "total_rec_late_fee",
    "recoveries", "collection_recovery_fee", "last_pymnt_amnt", "next_pymnt_d",
    "collections_12_mths_ex_med", "policy_code", "application_type", "acc_now_delinq",
    "tot_coll_amt", "tot_cur_bal", "open_acc_6m", "open_act_il",
    "open_il_12m", "open_il_24m", "mths_since_rcnt_il", "total_bal_il",
    "il_util", "open_rv_12m", "open_rv_24m", "max_bal_bc",
    "all_util", "total_rev_hi_lim", "inq_fi", "total_cu_tl",
    "inq_last_12m", "acc_open_past_24mths", "avg_cur_bal", "bc_open_to_buy",
    "bc_util", "chargeoff_within_12_mths", "delinq_amnt", "mo_sin_old_il_acct",
    "mo_sin_old_rev_tl_op", "mo_sin_rcnt_rev_tl_op", "mo_sin_rcnt_tl", "mort_acc",
    "mths_since_recent_bc", "mths_since_recent_inq", "num_accts_ever_120_pd", "num_actv_bc_tl",
    "num_actv_rev_tl", "num_bc_sats", "num_bc_tl", "num_il_tl",
    "num_op_rev_tl", "num_rev_accts", "num_rev_tl_bal_gt_0",
    "num_sats", "num_tl_120dpd_2m", "num_tl_30dpd", "num_tl_90g_dpd_24m",
    "num_tl_op_past_12m", "pct_tl_nvr_dlq", "percent_bc_gt_75", "pub_rec_bankruptcies",
    "tax_liens", "tot_hi_cred_lim", "total_bal_ex_mort", "total_bc_limit",
    "total_il_high_credit_limit", "hardship_flag", "debt_settlement_flag",
    'fico_range_low', 'fico_range_high', 'last_fico_range_high', 'last_fico_range_low', "emp_length"
]

target = ["loan_status"]

df_ori = pd.read_csv('./dataset/All_Lending_Club_loan_data/accepted_2007_to_2018Q4.csv')

# df = df_ori
print(df_ori['loan_status'].value_counts())

df = df_ori.loc[:, columns].copy()
# Drop the null columns where all values are null
df = df.dropna(axis='columns', how='all')
# Drop the null rows
# df = df.dropna()
df[['loan_status']] = df[['loan_status']].fillna('Current')

# Remove the `Issued` loan status
issued_mask = df['loan_status'] != 'Current'
df = df.loc[issued_mask]

# issued_mask = df['loan_status'] != 0
# df = df.loc[issued_mask]
# convert interest rate to numerical

a = (df.columns)
print(a.tolist())

df[['emp_length']] = df[['emp_length']].fillna('0')
df['emp_length'] = df['emp_length'].str.replace('+', '')
df['emp_length'] = df['emp_length'].str.replace('<', '')
df['emp_length'] = df['emp_length'].str.replace(' ', '')
df['emp_length'] = df['emp_length'].str.replace('years', '')
df['emp_length'] = df['emp_length'].str.replace('year', '')
df['emp_length'] = df['emp_length'].astype('float')

df[['int_rate']] = df[['int_rate']].fillna('0')
df['int_rate'] = df['int_rate'].astype('float') / 100.0

# Convert the target column values to low_risk and high_risk based on their values
x = {'Fully Paid': 'low_risk'}
df = df.replace(x)
x = dict.fromkeys(['Late (31-120 days)', 'Late (16-30 days)', 'Default',
                   'In Grace Period', 'Charged Off',
                   'Does not meet the credit policy. Status:Fully Paid',
                   'Does not meet the credit policy. Status:Charged Off'], 'high_risk')
df = df.replace(x)

df.reset_index(inplace=True, drop=True)
df.head()

# print(df.info)
print(df['loan_status'].value_counts())

from imblearn.over_sampling import RandomOverSampler
from imblearn.under_sampling import RandomUnderSampler
from imblearn.under_sampling import ClusterCentroids
from imblearn.over_sampling import SMOTE
from imblearn.combine import SMOTEENN

# Importing Logistical Regression
from sklearn.linear_model import LogisticRegression

# Importing Evaluation Metrics
from sklearn.metrics import confusion_matrix
from sklearn.metrics import balanced_accuracy_score
from imblearn.metrics import classification_report_imbalanced

from collections import Counter
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

# le = LabelEncoder()
# # df1 = df.copy()
# df['home_ownership'] = le.fit_transform(df['home_ownership'])
#
# # df2 = df.copy()
# df['verification_status'] = le.fit_transform(df['verification_status'])
#
# # df3 = df2.copy()
# df['issue_d'] = le.fit_transform(df['issue_d'])
#
# # df4 = df3.copy()
# df['pymnt_plan'] = le.fit_transform(df['pymnt_plan'])
#
# # df5 = df4.copy()
# df['initial_list_status'] = le.fit_transform(df['initial_list_status'])
#
# # df6 = df5.copy()
# df['next_pymnt_d'] = le.fit_transform(df['next_pymnt_d'])
#
# # df7 = df6.copy()
# df['application_type'] = le.fit_transform(df['application_type'])
#
# # df8 = df7.copy()
# df['hardship_flag'] = le.fit_transform(df['hardship_flag'])
#
# # df9 = df8.copy()
# df['debt_settlement_flag'] = le.fit_transform(df['debt_settlement_flag'])
# df.head()


le = LabelEncoder()
df1 = df.copy()
df1['home_ownership'] = le.fit_transform(df1['home_ownership'])

df2 = df1.copy()
df2['verification_status'] = le.fit_transform(df2['verification_status'])

# df3 = df2.copy()
# df3['issue_d'] = le.fit_transform(df3['issue_d'])

df4 = df2.copy()
df4['pymnt_plan'] = le.fit_transform(df4['pymnt_plan'])

df5 = df4.copy()
df5['initial_list_status'] = le.fit_transform(df5['initial_list_status'])

df6 = df5.copy()
df6['next_pymnt_d'] = le.fit_transform(df6['next_pymnt_d'])

df7 = df6.copy()
df7['application_type'] = le.fit_transform(df7['application_type'])

df8 = df7.copy()
df8['hardship_flag'] = le.fit_transform(df8['hardship_flag'])

df9 = df8.copy()
df9['debt_settlement_flag'] = le.fit_transform(df9['debt_settlement_flag'])
df9.head()

df10 = df9.copy()
df10["loan_status_le"] = le.fit_transform(df10["loan_status"])
df10.head()

loan_status_types = {
    "high_risk": 0,
    "low_risk" : 1
}

df10["loan_status_risk_type"] = df10["loan_status"].apply(lambda x: loan_status_types[x])
df10.head()

df10.to_csv("preprocess_Data.csv")
