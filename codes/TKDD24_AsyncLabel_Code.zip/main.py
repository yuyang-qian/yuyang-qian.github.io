#!/usr/bin/env python3
import datetime

from torch.utils.tensorboard import SummaryWriter
import argparse
import os.path
import random
import time

import numpy as np
import torch
from torch.nn.parallel import DistributedDataParallel

import IoTData
import utils
from data import get_dataset, DATASET_CONFIGS
# toLabeledDataset
from train import train
from dgr import ConditionalScholar
from models import CNN_CV, Solver_SSD
import torch.nn as nn
import torch.distributed as dist
import load_ts_datasets
import load_loan_data
import portraits_util
from simulated_data import generate_simulated_labeleddatset, generate_simulated_batchdata, \
    generate_simulated_labeleddatset_expected_delay, generate_simulated_labeleddatset_asynchronous_delay, \
    ClassificationDataset_2d
import logger

parser = argparse.ArgumentParser(
    'PyTorch implementation for Learning AsynChronous labels with Hint (LACH) method'
)

parser.add_argument(
    '--experiment', type=str,
    default='data.ts_model.ts-DANN_SSD'
)
parser.add_argument('--mnist-permutation-number', type=int, default=5)
parser.add_argument('--mnist-permutation-seed', type=int, default=0)
parser.add_argument(
    '--replay-mode', type=str, default='none',
    choices=['none'],
)

parser.add_argument('--reg_warmup', type=int, default=10, )
parser.add_argument('--reg_warmup_iter', type=int, default=100, )  # 100
parser.add_argument('--lambda_mmd', type=float, default=50.0, help='data_mmd_loss_ratio')  # 50
parser.add_argument('--mmd_feat_table_l', type=int, default=128, help='feat size for mmd table')  # 128
parser.add_argument('--mmd_feat_table_u', type=int, default=128, help='feat size for mmd table')  # 128
parser.add_argument('--mmd_threshold', default=0.7, type=float, help='kd loss threshold in terms of outputs entropy')

parser.add_argument('--generator-lambda', type=float, default=10.)
parser.add_argument('--generator-z-size', type=int, default=100)
parser.add_argument('--generator-c-channel-size', type=int, default=64)
parser.add_argument('--generator-g-channel-size', type=int, default=64)
parser.add_argument('--solver-depth', type=int, default=5)
parser.add_argument('--solver-lr', type=float, default=1e-3)
parser.add_argument('--solver-reducing-layers', type=int, default=3)
parser.add_argument('--solver-channel-size', type=int, default=1024)
parser.add_argument('--thread-num', type=int, default=2)

parser.add_argument('--generator-c-updates-per-g-update', type=int, default=5)
parser.add_argument('--generator-iterations', type=int, default=3000)
parser.add_argument('--solver-iterations', type=int, default=1000)
parser.add_argument('--importance-of-new-task', type=float, default=.3)
parser.add_argument('--lr', type=float, default=1e-04)
parser.add_argument('--beta1', type=float, default=0.5)
parser.add_argument('--beta2', type=float, default=0.9)
# parser.add_argument('--weight-decay', type=float, default=1e-05)
parser.add_argument('--weight-decay', type=float, default=0.0)
parser.add_argument('--batch-size', type=int, default=32)
parser.add_argument('--test-size', type=int, default=1024)
parser.add_argument('--sample-size', type=int, default=48)
parser.add_argument('--SKETCH-M', type=int, default=200)

parser.add_argument('--delay', type=int, default=20)
parser.add_argument('--model-var', type=float, default=0.01)
# parser.add_argument('--model-var', type=float, default=0.10)
# parser.add_argument('--model-var', type=float, default=0.15)
parser.add_argument('--selftraining_times', type=int, default=1)

parser.add_argument('--sample-log', action='store_true')
parser.add_argument('--sample-log-interval', type=int, default=300)
parser.add_argument('--image-log-interval', type=int, default=100)
parser.add_argument('--eval-log-interval', type=int, default=50)
parser.add_argument('--loss-log-interval', type=int, default=30)
parser.add_argument('--seed', type=int, default=1234)
parser.add_argument('--checkpoint-dir', type=str, default='./checkpoints')
parser.add_argument('--gpu_id', type=str, default='None')
parser.add_argument('--sample-dir', type=str, default='./samples')
parser.add_argument('--no-gpus', action='store_false', dest='cuda')
parser.add_argument('--local_rank', default=-1, type=int, help='node rank for distributed training')

parser.add_argument('--ts-dataset-name', type=str, default='ucihar')
parser.add_argument('--ts-datasets-idx', type=str, default='1,2,3')

parser.add_argument('--port-dataset-name', type=str, default='portraits')

parser.add_argument(
    '--method', type=str, default='OGD',
    # choices=['self-training', 'OGD', 'OMDLastOp', "OMDEnsemble_LACH",
    # 'OMDNoOp', 'OGDSelfTraining', 'FF', 'AdaDelay']
)
'''
OGD: DOGD
OMDLastOp: Optimism set as last gradient
OMDEnsemble_LACH: our proposed LACH
'''
parser.add_argument('--remark', type=str, default='')
parser.add_argument('--task_name', type=str, default='')

main_command = parser.add_mutually_exclusive_group(required=True)
main_command.add_argument('--train', action='store_true')
main_command.add_argument('--test', action='store_false', dest='train')
parser.add_argument('--N_l', type=int, default=200)


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


if __name__ == '__main__':
    
    args = parser.parse_args()
    
    setup_seed(args.seed)
    experiment = args.experiment
    # %%
    ####################################################################
    # Initialize Logger
    label = '{experiment}-{replay_mode}'.format(
        experiment=experiment,
        replay_mode=args.replay_mode,
        importance_of_new_task=(
            1 if args.replay_mode == 'none' else
            args.importance_of_new_task
        ),
        method=args.method,
    )
    task_name = 'main'
    dt = datetime.datetime.now().strftime('%m%d_%H%M%S')
    # print(dt)
    # task_name = task_name + '_' + dt
    # print(scholar.name)
    if task_name == 'main':
        # task_name = dt + '_' + scholar.name + '_' + args.method + '_Nl=' + str(args.N_l)
        task_name = dt + '_' + label + '_' + args.method
    if args.remark != '':
        task_name += '_' + args.remark
    
    if args.task_name != '':
        task_name = args.task_name
    
    if not os.path.exists('./log/{}/'.format(task_name)):
        os.makedirs('./log/{}/'.format(task_name))
    args.task_name = task_name
    
    args.logger = logger.MyLogger('./log/{}/logger.txt'.format(task_name))
    
    ####################################################################
    # %%
    if args.gpu_id != 'None':
        os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu_id
    # decide whether to use cuda or not.
    cuda = torch.cuda.is_available() and args.cuda
    args.logger.info('CUDA condition: {} {}, GPU_ids: {}'.format(torch.cuda.is_available(), args.cuda, args.gpu_id))
    
    torch.set_num_threads(args.thread_num)
    errs_star = None
    
    if 'SSD' in experiment:
        if "data.ts" in experiment:
            args.delay = 3
            # args.delay = 2
            ori_datasets, train_datasets, received_datasets = load_ts_datasets.load_da(
                args.ts_dataset_name,
                args.ts_datasets_idx,
                E_delay=args.delay,
                expected=True,
                args=args
            )
            dataset_config = DATASET_CONFIGS[args.ts_dataset_name]
        
        if "data.syn" in experiment:
            # # args.delay = 10
            # args.delay = 20
            # # args.delay = 40
            # # args.delay = 100
            
            args.weight_decay = 0.0
            
            # args.model_var = 0.01  # mark
            # # args.model_var = 0.03  # mark
            # # args.model_var = 0.05  # mark
            # # args.model_var = 0.07  # mark
            
            args.confidence_q = 0.4
            
            gen = ClassificationDataset_2d()
            ori_datasets, train_datasets, received_datasets, errs_star = gen.generate_asynchronous_data(
                T=1200, E_delay=args.delay, stage=100,
                model_var=args.model_var,
                diameter=2.5 * (0.05 / args.model_var) ** (1 / 2),
                sample_num=8)
            
            dataset_config = DATASET_CONFIGS['syn']
        
        if "data.loan" in experiment:
            args.delay = 36
            ori_datasets, train_datasets, received_datasets, errs_star = load_loan_data.load_data()
            dataset_config = DATASET_CONFIGS['loan']
        
        if "data.port" in experiment:
            # args.delay = 2
            args.delay = 3
            t_u = [2000] * 9
            ori_datasets, train_datasets, received_datasets = portraits_util.get_datasets(
                'datasets/portraits/dataset_32x32.mat',
                t_u,
                E_delay=args.delay,
                expected=True,
                args=args
            )
            dataset_config = DATASET_CONFIGS[args.port_dataset_name]
        
        if "data.iot" in experiment:
            # args.delay = 5
            # ori_datasets, train_datasets, received_datasets = IoTData.generate_iot_data(T=100, E_delay=5)
            args.delay = 5
            ori_datasets, train_datasets, received_datasets = IoTData.generate_iot_data(T=30, E_delay=5, frac_factor=0.01)
            dataset_config = DATASET_CONFIGS['iot']
    else:
        raise RuntimeError('Given undefined experiment: {}'.format(experiment))
    args.tot_T = len(train_datasets)
    args.classes = dataset_config['classes']
    
    # train_datasets = toLabeledDataset(train_datasets)
    # received_datasets = toLabeledDataset(received_datasets)
    
    # define the models.
    cnn = wgan = None
    
    # Add Sketches first:
    
    if 'SSD' in experiment:
        
        cnn = Solver_SSD(
            image_size=dataset_config['size'],
            image_channel_size=dataset_config['channels'],
            classes=dataset_config['classes'],
            depth=args.solver_depth,
            channel_size=args.solver_channel_size,
            reducing_layers=args.solver_reducing_layers,
            experiment=experiment,
            args=args
        )
    
    else:
        cnn = CNN_CV(
            image_size=dataset_config['size'],
            image_channel_size=dataset_config['channels'],
            classes=dataset_config['classes'],
            depth=args.solver_depth,
            channel_size=args.solver_channel_size,
            reducing_layers=args.solver_reducing_layers
        )
    
    if cuda:
        args.logger.info('DataParrallel ON')
        
        if cnn is not None:
            cnn.solver = nn.DataParallel(cnn.solver)
    
    # args.logger.info('batch_size: {}', args.batch_size)
    
    # if 'SSD' in experiment:
    scholar = ConditionalScholar(label, solver=cnn, experiment=experiment, args=args)
    
    # initialize the model.
    utils.gaussian_intiailize(scholar, std=.02)
    
    # use cuda if needed
    if cuda:
        # scholar = nn.DataParallel(scholar)
        scholar.cuda()
    
    if 'data.sim' in args.experiment or 'data.Bsim' in args.experiment:
        collate_fn = None
    else:
        collate_fn = utils.label_squeezing_collate_fn
    
    args.logger.info(args)
    
    # run the experiment.
    if args.train:
        train(
            scholar=scholar,
            train_datasets=train_datasets,
            received_datasets=received_datasets,
            ori_datasets=ori_datasets,
            replay_mode=args.replay_mode,
            solver_iterations=args.solver_iterations,
            importance_of_new_task=args.importance_of_new_task,
            batch_size=args.batch_size,
            test_size=args.test_size,
            sample_size=args.sample_size,
            lr=args.lr, weight_decay=args.weight_decay,
            solver_lr=args.solver_lr,
            beta1=args.beta1, beta2=args.beta2,
            loss_log_interval=args.loss_log_interval,
            eval_log_interval=args.eval_log_interval,
            image_log_interval=args.image_log_interval,
            sample_log_interval=args.sample_log_interval,
            sample_log=args.sample_log,
            sample_dir=args.sample_dir,
            checkpoint_dir=args.checkpoint_dir,
            collate_fn=collate_fn,
            cuda=cuda,
            dataset_config=dataset_config,
            args=args,
            errs_star=errs_star,
            task_name=task_name
        )
    else:
        path = os.path.join(args.sample_dir, '{}-sample'.format(scholar.name))
        utils.load_checkpoint(scholar, args.checkpoint_dir)
        utils.test_model(scholar.generator, args.sample_size, path)
