# Pytorch LACH

This is a pytorch implementation for Learning AsynChronous labels with Hint (LACH) method.

## Code Structure

`main.py` is the entrance of the program. The code mainly contains the following three parts.

-   **subsampling_IoT**: The down-sampled version of IoT dataset.

-   **ts_datasets**: Reading the time series datasets.

-   **log**: Logs of the experiments.

## Requirements

-   pandas==1.1.5
-   torch==1.8.0
-   tensorboard==2.6.0
-   absl_py==0.11.0
-   scipy==1.5.4
-   numpy==1.19.5
-   torchvision==0.9.0
-   tqdm==4.59.0
-   imbalanced_learn==0.8.1
-   rarfile==4.0
-   matplotlib==3.3.2
-   seaborn==0.11.2
-   absl==0.0
-   imblearn==0.0
-   Pillow==9.0.0
-   scikit_learn==1.0.2

## Example of Running Experiments:

The full version IoT Data is a large dataset(about 7,062,606 entries, 8GB), and therefore we provide a
down-sampled version of IoT dataset (about 50MB) in `./subsampling_IoT/`.

Run our LACH method on real-world IoT Dataset:

```
python -u main.py --train \
  --experiment=data.iot_model.dense_SSD \
  --method="OMDEnsemble_LACH" \
  --replay-mode=none \
  --solver-iterations=200 \
  --lr=0.1 \
  --solver-lr=0.1 \
  --sample-log \
  --batch-size=48 \
  --no-gpus \
  --eval-log-interval=1 \
  --loss-log-interval=1 \
  --seed=1234
```

## Reference:

[1] Yu-Yang Qian, Zhen-Yu Zhang, Peng Zhao, and Zhi-Hua Zhou. Learning with Asynchronous Labels. IEEE Transaction on Knowledge and Data Engineering, 2024.
