# /usr/bin/env python
# -*- coding: utf-8 -*-

import torch

from models_pkg.MobileNet import MobileNetV2_10_rep
# from online.algorithms.ogd import Base, CustomOGD, OptOGD

from utils_pkg.exp_config import Config


def load_DNN_model(cfgs: Config, sub_cfgs, model_name, DNN_model_path):
    DNN_model = None
    if model_name == 'ResNet18':
        from models_pkg.backbone_network.resnet import resnet18
        DNN_model = resnet18()
    elif model_name == 'ResNet34':
        from models_pkg.backbone_network.resnet import resnet34
        DNN_model = resnet34()
    elif model_name == 'ResNet50':
        from models_pkg.backbone_network.resnet import resnet50
        DNN_model = resnet50()
    elif model_name == 'ResNet101':
        from models_pkg.backbone_network.resnet import resnet101
        DNN_model = resnet101()
    elif model_name == 'MLP':
        from models_pkg.rep_models import MLP
        DNN_model = MLP(
            input_dim=cfgs.data_cfgs.info['dim'],
            output_dim=sub_cfgs.kwargs['rep_output_dim'],
            hidden_dim=sub_cfgs.kwargs['rep_hidden_dim']
        )
    elif model_name == 'MobileNet_rep':
        DNN_model = MobileNetV2_10_rep()  # output rep dim: 1280
    elif model_name == 'Linear':
        from models_pkg.linear import Linear
        # DNN_model = Linear()
        if sub_cfgs.rep_model_name == 'None':
            DNN_model = Linear(
                input_dim=cfgs.data_cfgs.info['dim'],
                output_dim=cfgs.data_cfgs.info['cls_num'],
                R=cfgs.online_cfgs.kwargs['D'] / 2
            )
        else:
            DNN_model = Linear(
                input_dim=cfgs.online_cfgs.kwargs['rep_output_dim'],
                output_dim=cfgs.data_cfgs.info['cls_num'],
                R=cfgs.online_cfgs.kwargs['D'] / 2
            )
    elif model_name == 'None':
        DNN_model = None
    else:
        raise NotImplementedError
    
    # load DNN_model from checkpoint:
    if DNN_model_path != '':
        init = torch.load(DNN_model_path, map_location='cpu')
        DNN_model.load_state_dict(init)

    if DNN_model_path:
        print(f'[load_DNN_model] type={type(DNN_model)}, path={repr(DNN_model_path)}')
    else:
        print(f'[load_DNN_model] type={type(DNN_model)}, initialized from nothing')
    return DNN_model
