# /usr/bin/env python
# -*- coding: utf-8 -*-

import torch

from models_pkg.DNN_wrapper import load_DNN_model
from models_pkg.SENCForest_model import SENCForest_model
from models_pkg.linear import Linear
from models_pkg.simplex import Simplex
from utils_pkg import exp_config


def get_rep_model(cfgs: exp_config.Config, sub_cfgs, model_type, info, device, rep_model_name, rep_model_path):
    if rep_model_path != '':
        init = torch.load(rep_model_path, map_location='cpu')
    else:
        init = None
    rep_model = load_DNN_model(cfgs, sub_cfgs, rep_model_name, rep_model_path)
    
    if rep_model_path:
        print(f'[get_rep_model] type={type(rep_model)}, from={repr(rep_model_path)}')
    else:
        print(f'[get_rep_model] type={type(rep_model)}, initialized from nothing')
    return rep_model, init


def get_cls_model(cfgs: exp_config.Config, sub_cfgs, model_type, info, device, cls_model_name, cls_model_path):
    if cls_model_path != '':
        init = torch.load(cls_model_path, map_location='cpu')
    else:
        init = None
    
    # print('Init: {}'.format(init is not None))
    
    cfgs.data_cfgs.info = info
    # print('BBox model: {}'.format(model_type))
    # print(info)
    
    if model_type == 'Linear':
        model = Linear(
            input_dim=info['dim'],
            output_dim=info['cls_num'],
            R=cfgs.online_cfgs.kwargs['D'] / 2
        )
        
        if init is not None:
            if cfgs.offline_cfgs.type == model_type:
                model.load_state_dict(init)
    elif model_type == "Simplex":
        model = Simplex(
            # init_priors=info['init_priors']
            # uniform
            init_priors=torch.ones(info['cls_num'])
        )
        
        # if init is not None:
        #     if cfgs.offline_cfgs.type == model_type:
        #         model.load_state_dict(init)
    elif model_type == 'DNN':
        model = load_DNN_model(cfgs, sub_cfgs, cls_model_name, cls_model_path)
    elif model_type == 'SENCForest_model':
        model = SENCForest_model(cfgs)
    else:
        raise NotImplementedError
    
    if cls_model_path:
        print(f'[get_cls_model] type={type(model)}, from={repr(cls_model_path)}')
    else:
        print(f'[get_cls_model] type={type(model)}, initialized from nothing')
    return model.to(device), init
