import numpy as np

try:
    from data.randaugment import RandAugment
except ImportError:
    from randaugment import RandAugment


## useful functions

def gen_cls_map(cfg):
    cls_map = {}
    for i, cls in enumerate(cfg['known_class']):
        cls_map[cls] = i
    cls_num = len(cls_map) + 1
    for cls in cfg['new_class']:
        cls_map[cls] = cls_num - 1
    
    print('map classes:', cls_map)
    
    return cls_map


def split_data(idx, part1_num, part2_num=0):
    idx_select = np.random.choice(idx, part1_num + part2_num, replace=False)
    idx_part1 = idx_select[:part1_num]
    idx_part2 = idx_select[part1_num:]
    return idx_part1, idx_part2
