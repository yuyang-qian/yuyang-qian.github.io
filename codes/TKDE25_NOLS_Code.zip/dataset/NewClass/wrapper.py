# /usr/bin/env python
# -*- coding: utf-8 -*-
import numpy as np

# @File    : wrapper.py
############################
from dataset.NewClass.toy_data import ToyTrainSet, ToyTestSet
from dataset.NewClass.arxiv_dataset import get_tfidf_data, get_bert_data
from dataset.NewClass.table_data import get_table_data
from dataset.NewClass.image_data import get_img_data
from dataset.NewClass.wilds_data import get_wilds_data
from dataset.NewClass.wilds_data_for_Skyline import get_wilds_data_for_Skyline
from utils_pkg import exp_config


def get_dataset(name, cfgs: exp_config.Config, data_cfgs_kwargs, rng):
    train_set, test_set, info = None, None, {}
    if name == 'toy':
        train_set = ToyTrainSet(data_cfgs_kwargs, rng=rng)
        info = train_set.info
        test_set = ToyTestSet(data_cfgs_kwargs, info, rng=rng)
    elif name == 'arxiv':
        type = data_cfgs_kwargs.get('type', 'bert')
        if type == "bert":
            train_set, test_set, info = get_bert_data(data_cfgs_kwargs,
                                                      nooverlap=data_cfgs_kwargs.get('nooverlap', False))
        elif type == "tfidf":
            train_set, test_set, info = get_tfidf_data(data_cfgs_kwargs)
        else:
            raise NotImplementedError
    elif name == "table":
        train_set, test_set, info = get_table_data(cfgs, data_cfgs_kwargs)
    elif name == "image":
        train_set, test_set, info = get_img_data(cfgs, data_cfgs_kwargs)
    elif name == 'wilds':
        train_set, test_set, info = get_wilds_data(cfgs, data_cfgs_kwargs)
    elif name == 'wilds_for_skyline':
        train_set, test_set, info = get_wilds_data_for_Skyline(cfgs, data_cfgs_kwargs)
    else:
        raise NotImplementedError
    
    # if 'cfg' in data_cfgs_kwargs.keys():
    #     cfg = data_cfgs_kwargs['cfg']
    # else:
    #     cfg = {}
    
    # if 'new_class' in cfg:
    #     #     new class problem
    #     cls_map = gen_cls_map(cfg)
    
    return train_set, test_set, info


if __name__ == '__main__':
    # cfgs = exp_config.Config(config_path='./demos/NewClass/locomotion/DNNOGD_rep/config.yaml', remark='')
    # train_set, test_set, info = get_dataset('table', cfgs, cfgs.data_cfgs.kwargs, rng=np.random.default_rng(cfgs.seed))
    
    # cfgs = exp_config.Config(config_path='./demos/NewClass/image_data/MNIST/LinearShift/WavO/config.yaml', remark='')
    # train_set, test_set, info = get_dataset('image', cfgs, cfgs.data_cfgs.kwargs, rng=np.random.default_rng(cfgs.seed))
    
    # cfgs = exp_config.Config(config_path='./demos/NewClass/synthetic/Linear_Shift/DNNWav/config.yaml', remark='')
    # train_set, test_set, info = get_dataset('toy', cfgs, cfgs.data_cfgs.kwargs, rng=np.random.default_rng(cfgs.seed))
    
    # cfgs = exp_config.Config(config_path='./demos/NewClass/wilds/amazon/DNNOGD_rep/config.yaml', remark='')
    # train_set, test_set, info = get_dataset('wilds', cfgs, cfgs.data_cfgs.kwargs, rng=np.random.default_rng(cfgs.seed))
    
    # cfgs = exp_config.Config(config_path='./demos/NewClass/wilds/fmow/DNNOGD_rep/config.yaml', remark='')
    cfgs = exp_config.Config(config_path='./demos/NewClass/locomotion/HANOL/config.yaml', remark='')
    train_set, test_set, info = get_dataset('wilds', cfgs, cfgs.data_cfgs.kwargs, rng=np.random.default_rng(cfgs.seed))
