# /usr/bin/env python
# -*- coding: utf-8 -*-
from multiprocessing import Pool
from os.path import isdir, join

import pandas as pd
import torch
import torch.utils.data as data
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle
from utils_pkg import exp_config

# load wilds dataset
import pickle

import numpy as np
from torchvision.transforms import transforms
from tqdm import trange


# from data_pkg.data import LabeledDataset


def load_one_wilds_data(data_name, domain_idx, is_shuffle=False):
    
    PATH_SUFFIX = '/home/xxxx/Codes/data/wilds_export/FMoW_xxxx/wilds_packed'
    data_name = data_name.lower()
    
    with open(f'{PATH_SUFFIX}/{data_name}/x_{domain_idx}.pkl', 'rb') as handle:
        data_x = pickle.load(handle)
    with open(f'{PATH_SUFFIX}/{data_name}/y_{domain_idx}.pkl', 'rb') as handle:
        data_y = pickle.load(handle)
    
    if is_shuffle:
        data_x, data_y = shuffle(data_x, data_y)
    
    return data_x, data_y


class CustomDataset(data.Dataset):
    def __init__(self, data, labels, datetime, transform=None, ori_labels=None):
        self.data = data
        self.labels = labels
        self.datetime = datetime
        self.ori_labels = ori_labels
        self.transform = transform
        
        # if isinstance(self.data, np.ndarray):
        #     self.data = torch.from_numpy(self.data)
        # self.data = self.data.float()
    
    def __getitem__(self, index):
        raise NotImplementedError()
    
    def __len__(self):
        raise NotImplementedError()


class TrainDataset(CustomDataset):
    def __init__(self, cfgs: exp_config.Config, data, labels, datetime, transform, ori_labels=None):
        super(TrainDataset, self).__init__(data, labels, datetime, transform=transform, ori_labels=ori_labels)
        self.data_name = cfgs.data_cfgs.kwargs['wilds_name']
        self.label_mask = np.ones(len(self.data), dtype=np.bool_)
    
    def __getitem__(self, index, ):
        
        if self.data_name == 'Amazon':
            # tokenizer
            data = self.data[index]
        elif self.data_name == 'FMoW':
            # preprocess the image
            data = self.transform(self.data[index])
        else:
            data = self.data[index]
        
        return data, self.labels[index], self.label_mask[index]
    
    def __len__(self):
        return len(self.data)


class TestDataset(CustomDataset):
    def __init__(self, cfgs: exp_config.Config, data, labels, transform, datetime, **kwargs):
        super(TestDataset, self).__init__(data, labels, datetime, transform=transform)
        self.data_name = cfgs.data_cfgs.kwargs['wilds_name']
        
        self.rng = np.random.default_rng(cfgs.seed)
        self.interval = kwargs.get("interval")
        self.ptr = 0
        print('Online Batch Size: {}'.format(self.interval))
        if isinstance(self.labels, np.ndarray):
            self.labels = torch.from_numpy(self.labels)
        self.num_processes = 8
        
        #  For the NewClass task:
        self.label_mask = np.zeros(len(self.data), dtype=np.bool_)  # all unlabeled data
        self.pvu = False
    
    # def process_data(self, x):
    #     return self.transform(x)
    
    def __getitem__(self, t):
        
        self.ptr = t * self.interval
        X = self.data[self.ptr:self.ptr + self.interval]
        y = self.labels[self.ptr:self.ptr + self.interval]
        
        if self.transform:
            X = torch.stack([self.transform(x) for x in X])

            # with Pool(processes=self.num_processes) as pool:  # multi process to accelerate
            #     X = pool.map(self.process_data, X)
            # X = torch.stack(X)
        
        # if self.data_name == 'Amazon':
        #     # tokenizer
        #     pass
        # elif self.data_name == 'FMoW':
        #     # preprocess the image
        #     pass
        
        return X, y, None
    
    def getitem_NewClass(self, t):
        if not self.pvu:
            self.ptr = t * self.interval
            X = self.data[self.ptr:self.ptr + self.interval]
            
            if self.transform:
                X = torch.stack([self.transform(x) for x in X])
            
            y = self.labels[self.ptr:self.ptr + self.interval]
            label_mask = torch.tensor(self.label_mask[self.ptr:self.ptr + self.interval])
            
            return X, y, label_mask
        else:
            return self.data[t], self.labels[t], self.label_mask[t]
    
    def __len__(self):
        return len(self.data) // self.interval


def get_wilds_data(cfgs: exp_config.Config, data_cfgs_kwargs, bbox=False):
    data_name = data_cfgs_kwargs['wilds_name']
    # total_domain_num = data_cfgs_kwargs['source_data']['total_domain_num']
    
    if data_name == 'FMoW':
        transform = transforms.Compose(
            [transforms.Resize((224, 224)),
             transforms.ToTensor(),
             transforms.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225))
             ]
        )
    elif data == 'iwildcam':
        transform = transforms.Compose(
            [transforms.Resize((224, 224)),
             transforms.ToTensor(),
             transforms.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225))
             ]
        )
    else:
        transform = None
    
    if data_name == 'FMoW':
        dim = 224 * 224  # img size
    elif data_name == 'Amazon':
        dim = 256  # token length
    elif data_name == 'iwildcam':
        dim = 224 * 224  # img size
    else:
        raise NotImplementedError
    
    features_train = []
    labels_train = []
    dates_train = []
    train_idx_start = data_cfgs_kwargs['source_data']['domain_idx_start']
    train_idx_end = data_cfgs_kwargs['source_data']['domain_idx_end']
    for idx in trange(train_idx_start, train_idx_end + 1, desc='Loading {} Data - Trainset'.format(data_name)):
        data_x, data_y = load_one_wilds_data(data_name, idx, is_shuffle=True)
        features_train += data_x
        labels_train += data_y
        dates_train += [idx] * len(data_x)
    labels_train = torch.tensor(labels_train).long()
    dates_train = torch.tensor(dates_train).long()
    
    features_test = []
    labels_test = []
    dates_test = []
    test_idx_start = data_cfgs_kwargs['online_data']['domain_idx_start']
    test_idx_end = data_cfgs_kwargs['online_data']['domain_idx_end']
    for idx in trange(test_idx_start, test_idx_end + 1, desc='Loading {} Data - Testset'.format(data_name)):
        data_x, data_y = load_one_wilds_data(data_name, idx, is_shuffle=True)
        features_test += data_x
        labels_test += data_y
        dates_test += [idx] * len(data_x)
    labels_test = torch.tensor(labels_test).long()
    dates_test = torch.tensor(dates_test).long()
    
    le = preprocessing.LabelEncoder()
    _labels_train = le.fit_transform(labels_train)
    _labels_test = le.transform(labels_test)
    
    train_set = TrainDataset(
        cfgs=cfgs,
        data=features_train,
        ori_labels=labels_train,
        labels=_labels_train,
        datetime=dates_train,
        transform=transform,
    )
    
    test_set = TestDataset(
        cfgs=cfgs,
        data=features_test,
        labels=_labels_test,
        datetime=dates_test,
        seed=cfgs.seed,
        transform=transform,
        **data_cfgs_kwargs['online_data'],
    )
    
    cls_num = len(np.unique(_labels_train))
    count = torch.bincount(torch.from_numpy(_labels_train), minlength=cls_num)
    priors = count / count.sum()
    
    info = {
        'cls_num'    : cls_num,
        'dim'        : dim,
        'init_priors': priors,
    }
    print('train set length', train_set.labels.shape)
    return train_set, test_set, info
