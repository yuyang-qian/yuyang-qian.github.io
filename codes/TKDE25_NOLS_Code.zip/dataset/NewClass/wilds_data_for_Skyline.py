# /usr/bin/env python
# -*- coding: utf-8 -*-
from multiprocessing import Pool
from os.path import isdir, join

import pandas as pd
import torch
import torch.utils.data as data
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle
from utils_pkg import exp_config

# load wilds dataset
import pickle

import numpy as np
from torchvision.transforms import transforms
from tqdm import trange


# from data_pkg.data import LabeledDataset


def load_one_wilds_data(data_name, domain_idx, is_shuffle=False):
    with open('/home/xxxx/Codes/data/wilds_export/{}/x_{}.pkl'
                  .format(data_name, domain_idx), 'rb') as handle:
        data_x = pickle.load(handle)
    with open('/home/xxxx/Codes/data/wilds_export/{}/y_{}.pkl'
                  .format(data_name, domain_idx), 'rb') as handle:
        data_y = pickle.load(handle)
    
    if is_shuffle:
        data_x, data_y = shuffle(data_x, data_y)
    
    return data_x, data_y


class CustomDataset(data.Dataset):
    def __init__(self, data, labels, datetime, transform=None, ori_labels=None):
        self.data = data
        self.labels = labels
        self.datetime = datetime
        self.ori_labels = ori_labels
        self.transform = transform
        
        # if isinstance(self.data, np.ndarray):
        #     self.data = torch.from_numpy(self.data)
        # self.data = self.data.float()
    
    def __getitem__(self, index):
        pass
    
    def __len__(self):
        return len(self.data)


class TrainDataset(CustomDataset):
    def __init__(self, cfgs: exp_config.Config, tot_data_x, tot_data_y, tot_date, transform, ori_labels=None):
        super(TrainDataset, self).__init__(None, None, None, transform=transform, ori_labels=ori_labels)
        
        self.tot_data_x = tot_data_x
        self.tot_data_y = tot_data_y
        self.tot_date = tot_date
        
        # self.reinit()
        
        self.get_datetime = False
        self.data_name = cfgs.data_cfgs.kwargs['wilds_name']
    
    def reinit(self):
        self.data = []
        self.labels = []
        self.datetime = []
        for idx in trange(len(self.tot_data_x), desc='Init Dataset'):
            tmp_x = self.tot_data_x[idx]
            tmp_y = self.tot_data_y[idx]
            tmp_x, tmp_y = shuffle(tmp_x, tmp_y)
            self.data += tmp_x
            self.labels += tmp_y
            self.datetime += self.tot_date[idx]
        
        self.labels = torch.tensor(self.labels).long()
        self.datetime = torch.tensor(self.datetime).long()
        
        # labels_test = torch.tensor(labels_test).long()
        # dates_test = torch.tensor(dates_test).long()
        #
        # le = preprocessing.LabelEncoder()
        # _labels_train = le.fit_transform(labels_train)
        # _labels_test = le.transform(labels_test)
    
    def __getitem__(self, index, ):
        
        if self.data_name == 'Amazon':
            # tokenizer
            data = self.data[index]
        elif self.data_name == 'FMoW':
            # preprocess the image
            data = self.transform(self.data[index])
        else:
            data = self.data[index]
        
        if self.get_datetime:
            return data, self.labels[index], self.datetime[index]
        else:
            return data, self.labels[index]


class TestDataset(CustomDataset):
    def __init__(self, cfgs: exp_config.Config, data, labels, transform, datetime, **kwargs):
        super(TestDataset, self).__init__(data, labels, datetime, transform=transform)
        self.data_name = cfgs.data_cfgs.kwargs['wilds_name']
        
        self.rng = np.random.default_rng(cfgs.seed)
        self.interval = kwargs.get("interval")
        self.ptr = 0
        print('Online Batch Size: {}'.format(self.interval))
        if isinstance(self.labels, np.ndarray):
            self.labels = torch.from_numpy(self.labels)
        self.num_processes = 8
    
    def process_data(self, x):
        return self.transform(x)
    
    def __getitem__(self, t):
        
        self.ptr = t * self.interval
        X = self.data[self.ptr:self.ptr + self.interval]
        y = self.labels[self.ptr:self.ptr + self.interval]
        
        if self.transform is not None:
            X = torch.stack([self.transform(x) for x in X])
            # X = self.transform(X)
            # with Pool(processes=self.num_processes) as pool:  # multi process to accelerate
            #     X = pool.map(self.process_data, X)
            # X = torch.stack(X)
        
        # if self.data_name == 'Amazon':
        #     # tokenizer
        #     pass
        # elif self.data_name == 'FMoW':
        #     # preprocess the image
        #     pass
        
        return X, y, None


def get_wilds_data_for_Skyline(cfgs: exp_config.Config, data_cfgs_kwargs, is_offline_train=True, bbox=False):
    data_name = data_cfgs_kwargs['wilds_name']
    # total_domain_num = data_cfgs_kwargs['source_data']['total_domain_num']
    
    if data_name == 'FMoW':
        if is_offline_train:
            transform = transforms.Compose(
                [transforms.RandomHorizontalFlip(),
                 transforms.RandomCrop(size=[224, 224], padding=4),
                 # transforms.Resize((224, 224)),
                 transforms.ToTensor(),
                 transforms.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225))
                 ]
            )
        else:
            transform = transforms.Compose(
                [transforms.Resize((224, 224)),
                 transforms.ToTensor(),
                 transforms.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225))
                 ]
            )
    elif data == 'iwildcam':
        transform = transforms.Compose(
            [transforms.Resize((224, 224)),
             transforms.ToTensor(),
             transforms.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225))
             ]
        )
    else:
        transform = None
    
    if data_name == 'FMoW':
        dim = 224 * 224  # img size
    elif data_name == 'Amazon':
        dim = 256  # token length
    elif data_name == 'iwildcam':
        dim = 224 * 224  # img size
    else:
        raise NotImplementedError
    
    features_train = []
    labels_train = []
    dates_train = []
    features_test = []
    labels_test = []
    dates_test = []
    train_idx_start = data_cfgs_kwargs['source_data']['domain_idx_start']
    train_idx_end = data_cfgs_kwargs['source_data']['domain_idx_end']
    
    total_train_data_x = []
    total_train_data_y = []
    total_train_date = []
    total_test_data_x = []
    total_test_data_y = []
    total_test_date = []
    for idx in trange(train_idx_start, train_idx_end + 1, desc='Loading {} Data - Trainset'.format(data_name)):
        data_x, data_y = load_one_wilds_data(data_name, idx, is_shuffle=True)
        
        train_num = int(len(data_x) * 0.7)
        if train_num > 0:
            tmp_data_x = data_x[:train_num]
            tmp_data_y = data_y[:train_num]
            tmp_data_x, tmp_data_y = shuffle(tmp_data_x, tmp_data_y)
            
            total_train_data_x.append(tmp_data_x)
            total_train_data_y.append(tmp_data_y)
            total_train_date.append([idx] * train_num)
            
            # features_train += tmp_data_x
            # labels_train += tmp_data_y
            # dates_train += [idx] * train_num
        if len(data_x) - train_num > 0:
            tmp_data_x = data_x[train_num:]
            tmp_data_y = data_y[train_num:]
            tmp_data_x, tmp_data_y = shuffle(tmp_data_x, tmp_data_y)
            
            total_test_data_x.append(tmp_data_x)
            total_test_data_y.append(tmp_data_y)
            total_test_date.append([idx] * (len(data_x) - train_num))
            
            # features_test += tmp_data_x
            # labels_test += tmp_data_y
            # dates_test += [idx] * (len(data_x) - train_num)
    
    # labels_train = torch.tensor(labels_train).long()
    # dates_train = torch.tensor(dates_train).long()
    #
    # labels_test = torch.tensor(labels_test).long()
    # dates_test = torch.tensor(dates_test).long()
    #
    # le = preprocessing.LabelEncoder()
    # _labels_train = le.fit_transform(labels_train)
    # _labels_test = le.transform(labels_test)
    
    train_set = TrainDataset(
        cfgs=cfgs,
        tot_data_x=total_train_data_x,
        ori_labels=labels_train,
        tot_data_y=total_train_data_y,
        tot_date=total_train_date,
        transform=transform,
    )
    
    test_set = TrainDataset(
        cfgs=cfgs,
        tot_data_x=total_test_data_x,
        ori_labels=labels_test,
        tot_data_y=total_test_data_y,
        tot_date=total_test_date,
        transform=transform,
    )
    
    train_set.reinit()
    test_set.reinit()
    
    # le = preprocessing.LabelEncoder()
    # _labels_train = le.fit_transform(train_set.labels)
    # _labels_test = le.transform(_labels_train)
    # train_set.labels = _labels_train
    # _labels_train = _labels_test
    
    cls_num = len(np.unique(train_set.labels.numpy()))
    count = torch.bincount(train_set.labels, minlength=cls_num)
    priors = count / count.sum()
    
    info = {
        'cls_num'    : cls_num,
        'dim'        : dim,
        'init_priors': priors,
    }
    print('train set length', train_set.labels.shape)
    return train_set, test_set, info
