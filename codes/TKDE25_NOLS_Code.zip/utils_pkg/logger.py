import logging
import os
from datetime import datetime

cwd = os.getcwd().split('/')[-1]


class MyLogger:
    def __init__(self, log_path='./log.txt'):
        with open(log_path, 'w') as wf:
            pass
        logging.basicConfig(filename=log_path, level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger(cwd)
    
    def info(self, msg):
        msg = datetime.now().strftime('<%m-%d_%H:%M:%S> ') + str(msg)
        print(msg)
        self.logger.info(msg)
    
    def warning(self, msg):
        msg = datetime.now().strftime('<%m-%d_%H:%M:%S> ') + str(msg)
        print(msg)
        self.logger.warning(msg)
    
    def error(self, msg):
        msg = datetime.now().strftime('<%m-%d_%H:%M:%S> ') + str(msg)
        print(msg)
        self.logger.error(msg)


if __name__ == '__main__':
    logger = MyLogger()
    logger.info('haha')
