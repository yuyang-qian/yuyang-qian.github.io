import torch.utils.data as util_data
import numpy as np


class CSVList(object):
    def __init__(self, fea_path, label_path = None):
        samples = make_csv_dataset(fea_path, label_path)
        self.samples = samples

    def __getitem__(self, index):
        feature, label = self.samples[index]
        return feature, label, index

    def __len__(self):
        return len(self.samples)


def make_csv_dataset(fea_path, label_path):
    from numpy import genfromtxt
    if label_path is None:
        fea = genfromtxt(fea_path, delimiter=',')
        data = [(np.array(fea[i]), np.array(0)) for i in range(len(fea))]
    else:
        fea = genfromtxt(fea_path, delimiter=',')
        label = genfromtxt(label_path, delimiter=',')
        data = [(np.array(fea[i]), np.array(int(label[i]))) for i in range(len(fea))]
    return data


def load_csv(fea_csv_path, label_csv_path = None, batch_size=32, is_shuffle=True):
    data = CSVList(fea_csv_path, label_csv_path)
    data_loader = util_data.DataLoader(data, batch_size=batch_size, shuffle=is_shuffle, num_workers=4)
    return data_loader


def load_weights(path):
    weights = []
    with open(path, "r") as fp:
        for line in fp:
            weights.append(float(line))
    return weights