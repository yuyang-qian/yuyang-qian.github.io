def add_arg(parser, dataset_name):
    if dataset_name == 'Cross_Language':
        parser.add_argument('--dataset', default='Cross Language', type=str,
                            help='which dataset')
        parser.add_argument('--pre_fea_address', default="./demos/data/cross_language/FR_fea.csv", type=str,
                            help='address of previous data feature')
        parser.add_argument('--pre_label_address', default="./demos/data/cross_language/FR_gnd.csv", type=str,
                            help='address of previous data labels')
        parser.add_argument('--crt_fea_address', default="./demos/data/cross_language/EN_fea.csv", type=str,
                            help='address of current data feature')
        parser.add_argument('--crt_label_address', default="./demos/data/cross_language/EN_gnd.csv", type=str,
                            help='address of current data labels')
        parser.add_argument('--pre_align_fea_address', default="./demos/data/cross_language/FR_evo_data.csv", type=str,
                            help='address of aligned previous data')
        parser.add_argument('--crt_align_fea_address', default="./demos/data/cross_language/EN_evo_data.csv", type=str,
                            help='address of aligned current data')
        parser.add_argument('--pre_weights_address', default="./demos/data/cross_language/FR_pre_weights.csv", type=str,
                            help='address of weights of previous data')
        parser.add_argument('--evo_weights_address', default="./demos/data/cross_language/EN_evo_weights.csv", type=str,
                            help='address of weights of evolving data')
        parser.add_argument('--pre_dim', default=5000, type=int,
                            help='dimension of previous data')
        parser.add_argument('--crt_dim', default=5000, type=int,
                            help='dimension of current data')
        parser.add_argument('--class_num', default=2, type=int,
                            help='the number of total classes')
    
    return parser
