import numpy as np
from scipy.stats import mode
from tqdm import trange

from utils_pkg.SENC_Forest.SENCEstimation import SENCEstimation
from utils_pkg.SENC_Forest.updatemodel import updatemodel


def Testingpro(streamdata, streamdatalabel, model, Para, global_vars):
    newclasslabel = 999
    buffer = []
    result_new = []
    idbuffer = []
    batchdatalabel = []
    batchdatalabel_true = []
    
    for j in trange(len(streamdata)):
        Mass, mtimetest = SENCEstimation(streamdata[j:j + 1, :], model, Para['alpha'], model.anomaly, global_vars)
        #     Mass[:, 0]--pathline;
        #     Mass[:, 1]--distance
        #     Mass[:, 2]--label
        #     Mass[:, 3]--id to go
        #     Mass[:, 4]--new class or not
        answermass = Mass[:, 2]
        answermass[np.where(Mass[:, 4] == 1)] = newclasslabel
        Score = np.array(np.unique(answermass, return_counts=True)).T
        Score_1 = Score[Score[:, 1].argmax()]
        
        if Score_1[0] == newclasslabel:
            buffer.append(streamdata[j:j + 1, :])
            idbuffer.append(Mass[:, 3])
            # idbuffer = np.hstack((idbuffer, Mass[:, 3]))
            batchdatalabel.append(newclasslabel)
            batchdatalabel_true.append(streamdatalabel[j])
            result_new.append([newclasslabel, streamdatalabel[j]])
        else:
            result_new.append([Score_1[0], streamdatalabel[j]])
        
        if len(buffer) >= Para['buffersize']:
            model = updatemodel(np.vstack(buffer), model, np.array(batchdatalabel), np.vstack(idbuffer), global_vars)
            
            # batchdatalabel = []
            idbuffer = []
            buffer = []
        
        # print(f'{j}')
    
    result_new = np.array(result_new)
    return result_new
