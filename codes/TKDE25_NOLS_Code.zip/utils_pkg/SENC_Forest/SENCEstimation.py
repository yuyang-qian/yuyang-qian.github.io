import numpy as np
import time

from utils_pkg.SENC_Forest.SENCMass import SENCMass
from utils_pkg.SENC_Forest.SENCTree import GlobalVars


def SENCEstimation(TestData, Forest, cldi, anomalylambdan, global_vars: GlobalVars):
    # global id
    global_vars.id = 1
    
    NumInst = TestData.shape[0]
    
    # Initialize Mass array with zeros
    # Mass = np.zeros((Forest.NumTree, 5))
    Mass = np.zeros((NumInst, 5))
    start_time = time.time()
    
    for k in range(Forest.NumTree):
        trave = np.zeros((2, TestData.shape[1]))
        ano = anomalylambdan[k]
        
        # Assuming SENCMass is adapted to Python and accepts/returns a NumPy array for Mass
        Mass += SENCMass(TestData, np.arange(NumInst), Forest.Trees[k], np.zeros((NumInst, 5)), cldi, trave, ano, global_vars)
    
    # average and to integer
    Mass = np.round(Mass / Forest.NumTree)
    
    ElapseTime = time.time() - start_time
    return Mass, ElapseTime
