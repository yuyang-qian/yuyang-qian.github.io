import numpy as np
from scipy.spatial.distance import pdist, squareform

from utils_pkg.SENC_Forest.SENCTree import GlobalVars


class SENCTree2:
    def __init__(self, Data, CurtIndex, CurtHeight, Paras, alltraindatalabel, newlabel, global_vars: GlobalVars):
        self.Height = CurtHeight
        self.NodeStatus = None
        self.SplitAttribute = None
        self.SplitPoint = None
        self.LeftChild = None
        self.RightChild = None
        self.Size = len(CurtIndex)
        self.CurtIndex = CurtIndex
        self.global_vars = global_vars
        self.Data = Data
        self.Paras = Paras
        self.alltraindatalabel = alltraindatalabel
        self.newlabel = newlabel
        
        self.construct_tree()
    
    def construct_tree(self):
        if self.Size <= 10 or self.Height >= self.global_vars.rt:
            
            self.la = self.alltraindatalabel[self.CurtIndex]
            self.id = self.global_vars.id2
            self.global_vars.id2 += 1
            
            self.handle_leaf_node()
        else:
            self.handle_internal_node()
    
    def handle_leaf_node(self):
        self.NodeStatus = 0
        if self.Size > 1:
            C = np.mean(self.Data[self.CurtIndex, :], axis=0)
            self.dist = np.max(squareform(pdist(self.Data[self.CurtIndex, :])))
            self.center = C
            if self.Size != 1:
                c = 2 * (np.log(self.Size - 1) + 0.5772156649) - 2 * (self.Size - 1) / self.Size
            else:
                c = 0
            self.high = self.Height + c
            for index in self.CurtIndex:
                # print(index)
                self.global_vars.pathline3[index] = self.high
            self.global_vars.pathline5.append(self.high)
        else:
            if self.Size == 1:
                self.center = self.Data[self.CurtIndex, :]
            self.high = self.Height
            self.global_vars.flag1 = 1
    
    def handle_internal_node(self):
        self.NodeStatus = 1
        rindex = np.argmax(np.random.rand(self.Paras['NumDim']))
        self.SplitAttribute = self.Paras['IndexDim'][rindex]
        CurtData = self.Data[self.CurtIndex, self.SplitAttribute]
        self.SplitPoint = np.min(CurtData) + (np.max(CurtData) - np.min(CurtData)) * np.random.rand(1)
        
        LeftCurtIndex = np.array(self.CurtIndex)[CurtData < self.SplitPoint]
        LeftCurtIndex = LeftCurtIndex.tolist()
        self.LeftCurtIndexla = self.alltraindatalabel[LeftCurtIndex]
        
        RightCurtIndex = np.setdiff1d(self.CurtIndex, LeftCurtIndex)
        self.RightCurtIndexla = self.alltraindatalabel[RightCurtIndex]
        
        self.LeftChild = SENCTree2(self.Data, LeftCurtIndex, self.Height + 1, self.Paras, self.alltraindatalabel, self.newlabel, self.global_vars)
        if self.global_vars.flag1 == 1:
            self.adjust_node_height()
            self.global_vars.flag1 = 0
        
        self.RightChild = SENCTree2(self.Data, RightCurtIndex, self.Height + 1, self.Paras, self.alltraindatalabel, self.newlabel, self.global_vars)
        if self.global_vars.flag1 == 1:
            self.adjust_node_height()
            self.global_vars.flag1 = 0
    
    def adjust_node_height(self):
        C = np.mean(self.Data[self.CurtIndex, :], axis=0)
        self.dist = np.max(squareform(pdist(self.Data[self.CurtIndex, :])))
        self.center = C
        if self.Size != 1:
            c = 2 * (np.log(self.Size - 1) + 0.5772156649) - 2 * (self.Size - 1) / self.Size
        else:
            c = 0
        self.high = self.Height + c
