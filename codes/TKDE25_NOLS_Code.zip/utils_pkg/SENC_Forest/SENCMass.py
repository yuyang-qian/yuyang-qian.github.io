import numpy as np
import warnings

warnings.filterwarnings('ignore')
from scipy.spatial.distance import cdist
from scipy.stats import mode

from utils_pkg.SENC_Forest.SENCTree import GlobalVars


def SENCMass(Data, CurtIndex, Tree, mass, cldi, trave, ano, global_vars: GlobalVars):
    #     Mass[:, 0]--pathline;
    #     Mass[:, 1]--distance
    #     Mass[:, 2]--label
    #     Mass[:, 3]--id to go
    #     Mass[:, 4]--new class or not
    if Tree.NodeStatus == 0:
        mass[CurtIndex, 0] = float(Tree.high < ano)
        if Tree.Size == 1:
            mass[CurtIndex, 2] = Tree.la
            mass[CurtIndex, 3] = Tree.id
            global_vars.flag = 1
        elif Tree.Size < 1:
            global_vars.flag = 1
            mass[CurtIndex, 3] = Tree.id
        else:
            tempdist = cdist(Data[CurtIndex, :], [Tree.center])
            mass[CurtIndex, 1] = (tempdist.squeeze() > Tree.dist * cldi)
            mass[CurtIndex, 3] = Tree.id
            
            ter = Tree.la
            Scoretrainl, _ = mode(ter)
            if len(Scoretrainl) > 1:
                mass[CurtIndex, 2] = Scoretrainl[0]
            else:
                mass[CurtIndex, 2] = Scoretrainl
            
            for idx in CurtIndex.tolist():
                if mass[idx, 1] == 1 and mass[idx, 0] == 1:
                    mass[idx, 4] = 1
                else:
                    mass[idx, 4] = 0
    
    else:
        LeftCurtIndex = np.array([CurtIndex[i] for i in range(len(CurtIndex)) if Data[CurtIndex[i], Tree.SplitAttribute] < Tree.SplitPoint])
        # LeftCurtIndex = CurtIndex[Data[CurtIndex, Tree.SplitAttribute] < Tree.SplitPoint]
        RightCurtIndex = np.setdiff1d(CurtIndex, LeftCurtIndex)
        trave[0, Tree.SplitAttribute] = 1
        trave[1, Tree.SplitAttribute] = Tree.SplitPoint
        
        if len(LeftCurtIndex) > 0:
            mass = SENCMass(Data, LeftCurtIndex, Tree.LeftChild, mass, cldi, trave, ano, global_vars)
            if global_vars.flag == 1:
                tempdist = cdist(Data[CurtIndex, :], [Tree.center])
                mass[CurtIndex, 1] = (tempdist.squeeze() > Tree.dist * cldi)
                
                if mass[CurtIndex, 0] < ano and mass[CurtIndex, 1] == 1:
                    mass[CurtIndex, 4] = 1
                else:
                    mass[CurtIndex, 4] = 0
                
                ter = Tree.RightCurtIndexla
                Scoretrainl, _ = mode(ter)
                if len(Scoretrainl) > 1:
                    mass[CurtIndex, 2] = Scoretrainl[0]
                else:
                    mass[CurtIndex, 2] = Scoretrainl
                
                global_vars.flag = 0
        
        if len(RightCurtIndex) > 0:
            mass = SENCMass(Data, RightCurtIndex, Tree.RightChild, mass, cldi, trave, ano, global_vars)
            if global_vars.flag == 1:
                tempdist = cdist(Data[CurtIndex, :], [Tree.center])
                mass[CurtIndex, 1] = (tempdist.squeeze() > Tree.dist * cldi)
                
                if mass[CurtIndex, 0] < ano and mass[CurtIndex, 1] == 1:
                    mass[CurtIndex, 4] = 1
                else:
                    mass[CurtIndex, 4] = 0
                
                ter = Tree.LeftCurtIndexla
                Scoretrainl, _ = mode(ter)
                if len(Scoretrainl) > 1:
                    mass[CurtIndex, 2] = Scoretrainl[0]
                else:
                    mass[CurtIndex, 2] = Scoretrainl
                
                global_vars.flag = 0
    
    return mass
