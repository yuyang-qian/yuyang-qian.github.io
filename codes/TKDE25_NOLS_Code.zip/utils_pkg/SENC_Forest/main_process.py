# read the data.mat
import scipy.io as sio

from utils_pkg.SENC_Forest.SENCForest import SENCForest
from utils_pkg.SENC_Forest.SENCTree import GlobalVars
from utils_pkg.SENC_Forest.Testingpro import Testingpro

import numpy as np
import scipy.sparse as sp
import time
from sklearn.utils import shuffle

if __name__ == '__main__':
    # Load data
    art4 = sio.loadmat('data.mat')['art4']
    Input_dataset = art4
    
    # Parameters setup
    train_num = 3  # Known Classes
    newclass_num = 1
    num_per_class = 2000
    alltraindata = np.array([])
    alltraindatalabel = np.array([])
    streamdata = np.array([])
    streamdatalabel = np.array([])
    ALLindex = [0, 1, 2, 3]  # all dataset intdexees
    
    global_vars = GlobalVars()
    # Random Instances
    for i in range(len(Input_dataset)):
        dataindex = np.random.permutation(len(Input_dataset[i][0]))
        datatemp = Input_dataset[i][0][dataindex]
        if sp.issparse(datatemp):  # If the data is sparse
            datatemp = datatemp.toarray()
        Input_dataset[i][0] = datatemp
    
    # Train Instances
    traindata = []
    for i in range(train_num):
        datatemp = Input_dataset[ALLindex[i]][0]
        traindata.append((datatemp[:num_per_class], Input_dataset[ALLindex[i]][1]))
        alltraindata = np.vstack([alltraindata, datatemp[:num_per_class]]) if alltraindata.size else datatemp[:num_per_class]
        if len(alltraindatalabel) == 0:
            alltraindatalabel = np.ones(num_per_class) * (Input_dataset[ALLindex[i]][1]).reshape(1)
        else:
            alltraindatalabel = np.hstack([alltraindatalabel, np.ones(num_per_class) * (Input_dataset[ALLindex[i]][1]).reshape(1)])
        
        alltraindatalabel = alltraindatalabel.astype(int).reshape(-1)
    
    # Test Instances
    testdata = []
    for i in range(train_num + newclass_num):
        datatemp = Input_dataset[ALLindex[i]][0]
        testdata.append((datatemp[num_per_class:num_per_class + 500], 999 if i >= train_num else (Input_dataset[ALLindex[i]][1]).reshape(1)))
        streamdata = np.vstack([streamdata, datatemp[num_per_class:num_per_class + 500]]) if streamdata.size else datatemp[num_per_class:num_per_class + 500]
        
        if len(streamdatalabel) == 0:
            streamdatalabel = np.ones(500) * (999 if i >= train_num else (Input_dataset[ALLindex[i]][1]).reshape(1))
        else:
            streamdatalabel = np.hstack([streamdatalabel, np.ones(500) * (999 if i >= train_num else (Input_dataset[ALLindex[i]][1]).reshape(1))])
        streamdatalabel = streamdatalabel.astype(int).reshape(-1)
    
    streamdata, streamdatalabel = shuffle(streamdata, streamdatalabel)
    
    # Training process
    NumTree = 100
    NumSub = 200
    CurtNumDim = alltraindata.shape[1]
    rseed = int(time.time())
    # Recursion limit might need to be adjusted in Python if necessary
    Model = SENCForest(alltraindata, NumTree, NumSub, CurtNumDim, rseed, alltraindatalabel, global_vars)
    
    # Testing process
    Para = {'beta': 1, 'alpha': 1, 'buffersize': 400}
    Result = Testingpro(streamdata, streamdatalabel, Model, Para, global_vars)
    
    # Evaluation
    newevaluation = np.array([np.sum(Result[:i + 1, 0] == Result[:i + 1, 1]) / (i + 1) for i in range(Result.shape[0])])
    
    print(newevaluation)
    
    # plot newevaluation
    import matplotlib.pyplot as plt
    
    plt.plot(newevaluation)
    plt.show()
    
    print('Final Accuracy:', newevaluation[-1])
