import numpy as np

from utils_pkg.SENC_Forest.SENCTree import GlobalVars
from utils_pkg.SENC_Forest.SENCTree2 import SENCTree2


def updatetree(temptree, idtree, alltraindata, alltraindatalabel, newlabel, global_vars: GlobalVars):
    # defines a function updatetree that recursively updates a tree structure
    # based on new data or labels. The function checks if a node is a leaf
    # or an internal node and processes it accordingly.
    # For leaf nodes, it potentially rebuilds the node with updated data;
    # for internal nodes, it recursively updates the left and right children.
    
    # global pathline3, pathlinenew, pathline5, rt
    
    if temptree.NodeStatus == 0:
        tempid = [i for i, x in enumerate(idtree) if x == temptree.id]
        
        if len(tempid) > 0:
            global_vars.pathline3 = np.zeros(global_vars.HeightLimit)
            updata = alltraindata[tempid, :]
            updatalabel = alltraindatalabel[tempid]
            
            if temptree.Size != 0:
                updata = np.vstack((updata, np.tile(temptree.center, (temptree.Size, 1))))
                
                # print(tempid)
                # print(f"updatalabel.shape: {updatalabel.shape}")
                # print(f"temptree.la.shape: {temptree.la.shape}")
                updatalabel = np.hstack((updatalabel, temptree.la))
            
            IndexDim = list(range(updata.shape[1]))
            Paras = {'NumDim': updata.shape[1], 'HeightLimit': 50, 'IndexDim': IndexDim}
            
            IndexSub = list(range(updata.shape[0]))
            global_vars.rt = temptree.Height + 3
            newtree = SENCTree2(updata, IndexSub, temptree.Height, Paras, updatalabel, newlabel, global_vars)
        else:
            newtree = temptree
            if temptree.la.size != 0:
                global_vars.pathline5.append(temptree.high)
        
        return newtree
    
    else:
        LeftChild = temptree.LeftChild
        RightChild = temptree.RightChild
        
        temptree.LeftChild = updatetree(LeftChild, idtree, alltraindata, alltraindatalabel, newlabel, global_vars)
        temptree.RightChild = updatetree(RightChild, idtree, alltraindata, alltraindatalabel, newlabel, global_vars)
    
    return temptree
