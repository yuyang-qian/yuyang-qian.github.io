# It selects a subset of the training data, updates each tree in the forest with this subset,
# and then recalculates certain properties of the tree, such as anomaly values
# based on the pathline5 variable, which seems to track
# some kind of depth or distance metric within each tree.
import copy

import numpy as np

from utils_pkg.SENC_Forest.SENCTree import GlobalVars
from utils_pkg.SENC_Forest.updatetree import updatetree


def updatemodel(alltraindata, ReForest, alltraindatalabel, idbuffer, global_vars: GlobalVars):
    newi = 1
    selectnumber = 20  # Assuming ReForest.NumSub is equivalent to 20 as hardcoded
    for i in range(len(idbuffer)):
        tree_id = i % ReForest.NumTree
        global_vars.pathline4 = []
        idtree = idbuffer[i]
        temptree = copy.deepcopy(ReForest.Trees[tree_id])
        global_vars.id2 = temptree.totalid + 1
        global_vars.pathlinenew = []
        newlabel = np.unique(alltraindatalabel)
        global_vars.pathline5 = []
        
        # Randomly select a subset of the training data and labels
        inde = np.random.permutation(alltraindata.shape[0])
        idtree1 = idtree[inde[:selectnumber] % len(idtree)]
        alltraindata1 = alltraindata[inde[:selectnumber], :]
        alltraindatalabel1 = alltraindatalabel[inde[:selectnumber]]
        
        # Update the tree
        newtree = updatetree(temptree, idtree1, alltraindata1, alltraindatalabel1, newlabel, global_vars)
        newtree.totalid = global_vars.id2 - 1
        newtree.pathline1 = global_vars.pathline5
        
        # Analyze the updated pathline5 for anomaly detection or adjustment
        tempan = sorted(global_vars.pathline5)
        varsf = [np.std(tempan[:j]) for j in range(len(tempan))]
        varsb = [np.std(tempan[j:]) for j in range(len(tempan))]
        vars_rate2 = np.abs(np.array(varsf) - np.array(varsb))
        
        bb = np.argmin(vars_rate2)
        print(f"old para of Tree {tree_id} is {ReForest.anomaly[tree_id]}; new para is {tempan[bb]}")
        ReForest.anomaly[tree_id] = tempan[bb]
        
        varsf = []
        varsb = []
        
        # ReForest.Trees[newi - 1] = newtree  # Update the tree in the forest
        ReForest.Trees[tree_id] = newtree  # Update the tree in the forest
    
    newReForest = ReForest
    return newReForest
