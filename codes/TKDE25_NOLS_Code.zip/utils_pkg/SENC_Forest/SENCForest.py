import numpy as np
import random
import time

import torch

from utils_pkg.SENC_Forest.SENCTree import SENCTree, GlobalVars


class SENCForest:
    # The SENCForest class is designed to construct a forest of SENCTrees,
    # each based on a subset of the data and aimed at anomaly detection or other tasks
    # requiring a forest-based approach.
    def __init__(self, Data, NumTree, NumSub, NumDim, rseed, label, global_vars: GlobalVars):
        if torch.is_tensor(Data):
            Data = Data.cpu().numpy()
        if torch.is_tensor(label):
            label = label.cpu().numpy()
        # Initialize the SENCForest with data, parameters, and labels
        self.NumTree = NumTree  # Number of trees in the forest
        self.NumSub = NumSub  # Number of data points in each tree's subset
        self.NumDim = NumDim  # Number of dimensions to consider for splitting
        self.c = 2 * (np.log(NumSub - 1) + 0.5772156649) - 2 * (NumSub - 1) / NumSub  # Constant used for adjustments
        self.rseed = rseed  # Random seed for reproducibility
        random.seed(rseed)  # Set Python's internal random seed
        np.random.seed(rseed)  # Set NumPy's random seed
        (NumInst, DimInst) = Data.shape  # Total number of instances and dimensions
        self.Trees = []  # Container for trees in the forest
        self.fruit = np.unique(label)  # Unique labels (classes)
        self.HeightLimit = 200  # Maximum height of trees
        # Parameters passed to each SENCTree
        Paras = {'HeightLimit': self.HeightLimit, 'IndexDim': list(range(DimInst)), 'NumDim': NumDim}
        self.classindex = []  # Indices of instances for each class
        self.ElapseTime = 0  # Time taken to build the forest
        
        self.anomaly = np.zeros(NumTree)  # Anomaly values for each tree
        
        start_time = time.time()  # Start timing the forest construction
        for fruit_value in self.fruit:
            # Find indices of all instances for each unique label
            self.classindex.append(np.where(label == fruit_value)[0])
        
        for i in range(NumTree):
            IndexSub = []  # Indices for the subset of data for the current tree
            for class_idx, class_indices in enumerate(self.classindex):
                # Ensure each class is represented in the subset
                if len(class_indices) < NumSub:
                    print('Number of instances is too small for class {}, need Num {} but only have Num {}'.format(
                        class_idx, NumSub, len(class_indices)))
                    # print(class_indices)
                    # break
                    continue
                else:
                    # Randomly select NumSub instances from each class
                    tempso = np.random.permutation(len(class_indices))
                    IndexSub.extend(class_indices[tempso[:NumSub]])
                    # print('Number of instances is enough.')
                    # print(class_indices[tempso[:NumSub]])
            
            if len(IndexSub) == 0:  # If the subset is empty, skip this tree
                continue
            
            # Reset global variables in SENCTree before building a new tree
            global_vars.id = 1
            global_vars.pathline = []
            global_vars.pathline3 = np.zeros(global_vars.HeightLimit)
            
            # Construct a tree with the selected subset and parameters
            tree = SENCTree(Data, np.array(IndexSub).astype(int).reshape(-1), 0, Paras, label, global_vars)
            # Store additional information in the tree
            tree.totalid = global_vars.id - 1
            tree.pathline = global_vars.pathline3
            tree.pathline1 = global_vars.pathline
            
            # Analyze tree's path lengths for anomaly detection
            tempan = np.sort(np.array(tree.pathline1)[:, 0])
            varsf = np.array([np.std(tempan[:j + 1]) for j in range(len(tempan))])
            varsb = np.array([np.std(tempan[j:]) for j in range(len(tempan))])
            vars_rate2 = np.abs(varsf - varsb)
            
            # Find the split point in path lengths that minimizes the variance difference
            bb = np.where(vars_rate2 == np.min(vars_rate2))[0]
            self.anomaly[i] = tempan[bb[0]]
            
            self.Trees.append(tree)  # Add the constructed tree to the forest
            # print('Successfully built tree %d' % (i + 1))
        self.ElapseTime = time.time() - start_time  # Calculate elapsed time for forest construction


# Example usage demonstrates how to instantiate and use the SENCForest class.
if __name__ == '__main__':
    Data = np.random.rand(100, 10)  # Generate example data
    label = np.random.randint(0, 2, 100)  # Generate example binary labels
    global_vars = GlobalVars()  # Create an instance of GlobalVars
    forest = SENCForest(Data, 10, 45, 10, 42, label, global_vars)  # Create a SENCForest instance
