import random

import numpy as np
from scipy.spatial.distance import cdist


# Global variables (should be avoided if possible, consider refactoring)

# flag1 = 0  # Assuming flag1 is managed similarly in the global scope


# Global variables equivalent in a class structure
class GlobalVars:
    def __init__(self):
        self.HeightLimit = 100000
        self.flag = 0
        self.flag1 = 0
        self.id = 0
        self.id2 = 0
        
        # self.pathlinenew = np.zeros(HeightLimit)
        # self.pathline = np.zeros(HeightLimit)
        # self.pathline3 = np.zeros(HeightLimit)
        # self.pathline4 = np.zeros(HeightLimit)
        # self.pathline5 = np.zeros(HeightLimit)
        
        self.pathlinenew = []
        self.pathline = []
        
        self.pathline3 = np.zeros(self.HeightLimit)
        self.pathline4 = []
        self.pathline5 = []
        self.rt = 0


class SENCTree:
    # global id, pathline, pathline3, flag1
    
    # Class attributes for global state tracking
    def __init__(self, Data, CurtIndex, CurtHeight, Paras, alltraindatalabel, global_vars: GlobalVars):
        # Initialize a node of the SENCTree
        self.Height = CurtHeight  # Current height of the node in the tree
        NumInst = len(CurtIndex)  # Number of instances in the current subset
        
        if CurtHeight >= Paras['HeightLimit'] or NumInst <= 10:
            self.NodeStatus = 0
            self.SplitAttribute = None
            self.SplitPoint = None
            self.LeftChild = None
            self.RightChild = None
            self.Size = NumInst
            self.CurtIndex = CurtIndex
            self.la = alltraindatalabel[CurtIndex]
            self.id = global_vars.id
            global_vars.id += 1
            self.center = np.mean(Data[CurtIndex, :], axis=0)
            self.dist = np.max(cdist(Data[CurtIndex, :], [self.center]))
            
            if NumInst != 1:
                c = 2 * (np.log(self.Size - 1) + 0.5772156649) - 2 * (self.Size - 1) / self.Size
            else:
                c = 0
            self.high = CurtHeight + c
            global_vars.pathline.append([self.high, NumInst])
            global_vars.pathline3[CurtIndex] = np.repeat(self.high, NumInst)
            
            if NumInst == 1:
                self.center = Data[CurtIndex, :]
                global_vars.flag1 = 1
                self.high = CurtHeight
        
        else:
            self.NodeStatus = 1
            rindex = np.argmax(np.random.rand(Paras['NumDim']))
            self.SplitAttribute = Paras['IndexDim'][rindex]
            CurtData = Data[CurtIndex, self.SplitAttribute]
            CurtDatalabel = alltraindatalabel[CurtIndex]
            
            # self.SplitPoint = np.min(CurtData) + (np.max(CurtData) - np.min(CurtData)) * np.random.rand()
            
            CurtData = CurtData + 0.0001 * np.random.rand(NumInst)
            last2_min = np.sort(CurtData)[2]
            last2_max = np.sort(CurtData)[-2]
            self.SplitPoint = last2_min + (last2_max - last2_min) * np.random.rand() * 0.95
            
            LeftCurtIndex = CurtIndex[CurtData < self.SplitPoint]
            RightCurtIndex = np.setdiff1d(CurtIndex, LeftCurtIndex)
            self.LeftCurtIndex = LeftCurtIndex
            self.LeftCurtIndexla = alltraindatalabel[LeftCurtIndex]
            self.RightCurtIndex = RightCurtIndex
            self.RightCurtIndexla = alltraindatalabel[RightCurtIndex]
            self.Size = NumInst
            
            self.LeftChild = SENCTree(Data, LeftCurtIndex, CurtHeight + 1, Paras, alltraindatalabel, global_vars)
            if global_vars.flag1 == 1:
                self.center = np.mean(Data[RightCurtIndex, :], axis=0)
                self.dist = np.max(cdist(Data[RightCurtIndex, :], [self.center]))
                self.la = alltraindatalabel[RightCurtIndex]
                global_vars.flag1 = 0
            
            self.RightChild = SENCTree(Data, RightCurtIndex, CurtHeight + 1, Paras, alltraindatalabel, global_vars)
            if global_vars.flag1 == 1:
                self.center = np.mean(Data[LeftCurtIndex, :], axis=0)
                self.dist = np.max(cdist(Data[LeftCurtIndex, :], [self.center]))
                self.la = alltraindatalabel[LeftCurtIndex]
                global_vars.flag1 = 0
