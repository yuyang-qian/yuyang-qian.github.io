import typing, os, sys, random

import numpy as np
import cvxpy as cp


def solve_gem_qp(
    new_grad: np.ndarray,
    old_grad_pool: typing.Iterable[np.ndarray],
    num_sample: int = 0,
) -> np.ndarray:
    """
    solve_gem_qp
        return GEM gradient, given new_grad and old_grad_pool.
        GEM gradient is np.ndarray vector (tensor order is one)
    new_grad
        gradient of online batch,
        must be np.ndarray, must be vector (tensor order is one)
    old_grad_pool
        gradient of offline batches and previous online batches,
        list, each item is an old_grad, must be np.ndarray, must
        be vector (tensor order is one)
    num_sample
        number of old_grad to be sampled from old_grad_pool,
        must be int, ignored if num_sample <= 0 (do not sample,
        use all old_grad)
    """

    # ======== sanity check ========

    assert isinstance(num_sample, int), "num_sample is not int"

    assert isinstance(new_grad, np.ndarray), "new_grad not np.ndarray"
    assert all(map(lambda old_grad: isinstance(old_grad, np.ndarray), old_grad_pool)), "old_grad_pool not np.ndarray"

    assert len(new_grad.shape) == 1, "new_grad not vector shape"
    assert all(map(lambda old_grad: len(old_grad.shape) == 1, old_grad_pool)), "old_grad_pool not vector shape"

    # sample without replacement
    if num_sample > 0 and num_sample < len(old_grad_pool):
        old_grad_pool = [old_grad for old_grad in old_grad_pool]
        random.shuffle(old_grad_pool)
        old_grad_pool = old_grad_pool[0:num_sample]
    else:
        num_sample = len(old_grad_pool)

    # ======== compose QP parameters ========

    # notations similar to https://arxiv.org/abs/1706.08840 eq. (8) ~ (11)

    (p,) = new_grad.shape
    print(f"[solve_gem_qp] prime_dim={p}, dual_dim={num_sample}")

    g = np.transpose(np.expand_dims(new_grad, axis=0))
    G = np.transpose(np.stack(old_grad_pool, axis=0))
    GTG = G.T @ G
    gTG = g.T @ G

    v = cp.Variable((num_sample, 1))
    qp = cp.Problem(
        cp.Minimize((1 / 2) * cp.quad_form(v, GTG, assume_PSD=True) + gTG @ v),
        [v >= 0],
    )
    qp.solve()

    g_tilde = G @ v.value + g

    gem_grad = np.squeeze(g_tilde, axis=1)
    return gem_grad
