import numpy as np
import math

def H(x):
    """Entropy-like function."""
    return -x * np.log(x) - (1 - x) * np.log(1 - x)

def logistic(y, p):
    """Logistic loss function."""
    return np.log(1 + np.exp(-y * p))

def square(y, p):
    """Square loss function."""
    return (y - p) ** 2

def FESL(predR, predN, lossR, lossN, Y_2ndstage, lossType):
    nSmp = len(Y_2ndstage)
    predFESL_c = np.zeros(nSmp)
    predFESL_s = np.zeros(nSmp)
    lossFESL_c = np.zeros(nSmp)
    lossFESL_s = np.zeros(nSmp)
    record1 = np.zeros(nSmp)
    record2 = np.zeros(nSmp)
    w11, w12, w21, w22 = 0.5, 0.5, 0.5, 0.5
    M = 1

    for t in range(nSmp):
        # FESL-c prediction by combination
        predFESL_c[t] = w11 * predR[t] + w12 * predN[t]
        if lossType == 'log':
            lossFESL_c[t] = 1 / M * logistic(Y_2ndstage[t], predFESL_c[t])
        elif lossType == 'square':
            lossFESL_c[t] = 1 / M * square(Y_2ndstage[t], predFESL_c[t])
        
        eta1 = np.sqrt(8 * np.log(2) / nSmp)
        w11 *= np.exp(-eta1 * lossR[t])
        w12 *= np.exp(-eta1 * lossN[t])
        w11 /= (w11 + w12)
        w12 = 1 - w11
        if w11 < w12:
            record1[t] = 1
        
        # FESL-s prediction by dynamic selection
        if np.random.rand() < w21:
            predFESL_s[t] = predR[t]
        else:
            predFESL_s[t] = predN[t]
            record2[t] = 1

        if lossType == 'log':
            lossFESL_s[t] = 1 / M * logistic(Y_2ndstage[t], predFESL_s[t])
        elif lossType == 'square':
            lossFESL_s[t] = 1 / M * square(Y_2ndstage[t], predFESL_s[t])
        
        eta2 = np.sqrt((8 / nSmp) * (2 * np.log(2) + (nSmp - 1) * H(1 / (nSmp - 1))))
        alpha = 1 / (nSmp - 1)
        v1 = w21 * np.exp(-eta2 * lossR[t])
        v2 = w22 * np.exp(-eta2 * lossN[t])
        W = v1 + v2
        w21 = alpha * W / 2 + (1 - alpha) * v1
        w22 = alpha * W / 2 + (1 - alpha) * v2
        w21 /= (w21 + w22)
        w22 = 1 - w21
    
    if lossType == 'square':
        accFESL_c = np.mean(lossFESL_c)
        accFESL_s = np.mean(lossFESL_s)
    else:
        accFESL_c = np.sum(Y_2ndstage == np.sign(predFESL_c)) / nSmp
        accFESL_s = np.sum(Y_2ndstage == np.sign(predFESL_s)) / nSmp
    
    return predFESL_c, predFESL_s, lossFESL_c, lossFESL_s, accFESL_c, accFESL_s, record1, record2
