import copy

import numpy as np


def Baseline(X, Y, W_init, lossType, tau_scale=1000.0):
    # X = copy.deepcopy(X)
    # Y = copy.deepcopy(Y)
    # W_init = copy.deepcopy(W_init)
    
    nSmp, _ = X.shape
    W = W_init
    pred = np.zeros(nSmp)
    loss = np.zeros(nSmp)

    if lossType == 'log':
        M = 1
        for t in range(nSmp):
            pred[t] = np.dot(X[t, :], W)
            temp = np.exp(-Y[t] * pred[t])
            loss[t] = (1 / M) * np.log(1 + temp)
            tau = 1 / (np.sqrt(t + 1) * tau_scale)  # t+1 because Python is 0-based and MATLAB is 1-based
            W = W + tau * (temp / (1 + temp)) * (np.dot(X[t, :].T, Y[t]))
        acc = np.sum(Y == np.sign(pred)) / nSmp
    
    elif lossType == 'square':
        M = 1000
        for t in range(nSmp):
            pred[t] = np.dot(X[t, :], W)
            loss[t] = (1 / M) * (Y[t] - pred[t]) ** 2
            tau = 1 / (np.sqrt(t + 1) * 1000)  # Adjusted for Python indexing
            W = W - 0.5 * tau * (2 * (pred[t] - Y[t]) * X[t, :].T)
        acc = np.mean(loss)  # Here acc is actually mean square error

    return W, pred, loss, acc
