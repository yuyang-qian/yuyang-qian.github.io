from tensorboard.backend.event_processing import event_accumulator
import pandas as pd
from tqdm import tqdm


def main():
    # load log data
    # parser = argparse.ArgumentParser(description='Export tensorboard data')
    # parser.add_argument('--in-path', type=str, required=True, help='Tensorboard event files or a single tensorboard '
    # 															   'file location')
    # parser.add_argument('--ex-path', type=str, required=True, help='location to save the exported data')
    
    # methods = ['AdaptiveReuse', 'AdaptiveReuse_avg', 'OGD', 'self-training']
    
    methods = ['OGD', 'OMDNoOp', 'OMDLastOp', "OMDEnsemble_LACH"]
    # seeds = [1234, 2345, 1111, 2222, 3000]  # 25 tasks
    # class_num_lists = ['1,1,1,2,2', '3,3,3,3,3', '1,1,2,2,3']
    vars = ['0.01', '0.03', '0.05']
    task_id = 0
    valnum = 1000
    
    logs = []
    seed_list = []
    for k in range(len(methods)):
        for i in range(len(vars)):
            method = methods[k]
            var = vars[i]
            task_name = 'Var{}_{}'.format(var, method)
            
            # print('./log/{}/'.format(task_name))
            logs.append('./log/{}/'.format(task_name))
            seed_list.append(i)
            task_id += 1
            log = './log/{}/'.format(task_name)
            
            event_data = event_accumulator.EventAccumulator(log)  # a python interface for loading Event data
            event_data.Reload()  # synchronously loads all of the data written so far b
            # print(event_data.Tags())  # print all tags
            keys = event_data.scalars.Keys()  # get all tags, save in a list
            print(keys)
            df = pd.DataFrame()
            key = 'data.syn_model.linear_SSD-none/loss/Accumulate Regret'
            df['Regret'] = pd.DataFrame(event_data.Scalars(key)).value
            df.to_csv('./csv_file/Var{}/{}.csv'.format(var, method), index=False)
    
    print("Tensorboard data exported successfully")


if __name__ == '__main__':
    main()
