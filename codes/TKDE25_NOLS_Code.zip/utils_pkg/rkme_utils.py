import copy
import pickle

import mkl

mkl.get_max_threads()

import random
import time

import numpy as np
from sklearn.metrics.pairwise import rbf_kernel
from sklearn.cluster import KMeans
from collections import Counter, namedtuple
import torch

import faiss
import json, codecs
import warnings


def choose_device(cuda=False):
    if cuda:
        device = torch.device("cuda:0")
    else:
        device = torch.device("cpu")
    return device


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


def torch_rbf_kernel(x1, x2, gamma):
    X12norm = torch.sum(x1 ** 2, 1, keepdim=True) - 2 * \
              x1 @ x2.T + torch.sum(x2 ** 2, 1, keepdim=True).T
    return torch.exp(-X12norm * gamma)


class StaSpec():
    
    def __init__(self, gamma=None, cuda=False):
        self.z = []
        self.beta = []
        # self.BETA_EPS = 0.01
        self.gamma = gamma
        self.device = choose_device(cuda=cuda)
        # self.num_points = 0
        self.cuda = cuda
    
    def preprocess(self, X, weight):
        weight = weight.reshape(1, -1)
        return (X * weight).astype(np.float32)
    
    def auto_get_gamma(self, X):
        # Auto Get Gamma
        # raise NotImplementedError
        
        if not torch.is_tensor(X):
            X = torch.from_numpy(X)
        X = X.to(self.device).double()
        gamma = 0.9 * torch.sqrt(torch.var(X)) / (X.shape[0]) ** (1.0 / 5.0)
        gamma = gamma.detach().cpu().item()
        return gamma
    
    def fit(self, X, K, step_size, steps):
        alpha = None
        self.num_points = X.shape[0]
        
        if self.gamma is None:
            self.gamma = self.auto_get_gamma(X)
        
        # Initialize Z by Clustering
        self._init_z_by_faiss(X, K)
        self._update_beta(alpha, X)
        # Alternating optimize Z and beta
        for i in range(steps):
            self._update_z(alpha, X, step_size)
            self._update_beta(alpha, X)
    
    def _init_z_by_faiss(self, X, K):
        numDim = X.shape[1]
        
        # kmeans = faiss.Kmeans(numDim, k, niter=100, verbose=False, gpu=self.cuda)
        kmeans = faiss.Kmeans(numDim, K, niter=100, verbose=False)
        kmeans.train(X)
        center = torch.from_numpy(kmeans.centroids).double()
        self.z = center
    
    def _update_beta(self, alpha, X):
        # Z = np.array(self.z)
        Z = self.z
        
        if not torch.is_tensor(Z):
            Z = torch.from_numpy(Z)
        Z = Z.to(self.device).double()
        
        if not torch.is_tensor(X):
            X = torch.from_numpy(X)
        X = X.to(self.device).double()
        K_z = torch_rbf_kernel(Z, Z, gamma=self.gamma).to(self.device)
        K_zx = torch_rbf_kernel(Z, X, gamma=self.gamma).to(self.device)
        
        beta = torch.sum(torch.linalg.inv(K_z + torch.eye(K_z.shape[0]).to(self.device) * 1e-5) @ K_zx,
                         dim=1) / X.shape[0]
        
        # self.beta = list(beta)
        self.beta = beta
    
    def _update_z(self, alpha, X, step_size):
        gamma = self.gamma
        
        Z = self.z
        beta = self.beta
        # Z = np.array(self.z.detach().cpu())
        # beta = np.array(self.beta.detach().cpu())
        
        if not torch.is_tensor(Z):
            Z = torch.from_numpy(Z)
        Z = Z.to(self.device).double()
        
        if not torch.is_tensor(beta):
            beta = torch.from_numpy(beta)
        beta = beta.to(self.device).double()
        
        if not torch.is_tensor(X):
            X = torch.from_numpy(X)
        X = X.to(self.device).double()
        
        grad_Z = torch.zeros_like(Z)
        
        for i in range(Z.shape[0]):
            z_i = Z[i, :].reshape(1, -1)
            term_1 = (beta * torch_rbf_kernel(z_i, Z, gamma)) @ (z_i - Z)
            if alpha is not None:
                term_2 = -2 * (alpha * torch_rbf_kernel(z_i, X, gamma)) @ (z_i - X)
            else:
                term_2 = -2 * (torch_rbf_kernel(z_i, X, gamma) / self.num_points) @ (z_i - X)
            grad_Z[i, :] = -2 * gamma * beta[i] * (term_1 + term_2)
        Z = Z - step_size * grad_Z
        # self.z = list(Z)
        self.z = Z
    
    def save(self, savepath='saved_spec.json', verbose=False):
        # Save in JSON file:
        rkme_to_save = copy.deepcopy(self.__dict__)
        if torch.is_tensor(rkme_to_save['z']):
            rkme_to_save['z'] = rkme_to_save['z'].detach().cpu().numpy()
        rkme_to_save['z'] = rkme_to_save['z'].tolist()
        if torch.is_tensor(rkme_to_save['beta']):
            rkme_to_save['beta'] = rkme_to_save['beta'].detach().cpu().numpy()
        rkme_to_save['beta'] = rkme_to_save['beta'].tolist()
        rkme_to_save['device'] = 'gpu' if rkme_to_save['cuda'] else 'cpu'
        # print(rkme_to_save)
        # json_str = json.dumps(rkme_to_save)
        # json_file.write(json_str)
        json.dump(rkme_to_save, codecs.open(savepath, 'w', encoding='utf-8'),
                  separators=(',', ':'),
                  # sort_keys=True,
                  # indent=4
                  )
        
        if verbose:
            print('RKME save attr: {} in {}'.format(rkme_to_save.keys(), savepath))
    
    def load(self, filepath='saved_spec.json', verbose=False):
        # Load JSON file:
        obj_text = codecs.open(filepath, 'r', encoding='utf-8').read()
        rkme_load = json.loads(obj_text)
        rkme_load['device'] = choose_device(rkme_load['cuda'])
        rkme_load['z'] = torch.from_numpy(np.array(rkme_load['z']))
        rkme_load['beta'] = torch.from_numpy(np.array(rkme_load['beta']))
        for d in self.__dir__():
            if d in rkme_load.keys():
                if verbose:
                    print('Loading attr: {} from {}'.format(d, filepath))
                setattr(self, d, rkme_load[d])
    
    def save_pkl(self, savepath='saved_spec.pkl', verbose=False):
        
        warnings.warn('The pkl saving format is not easy to read, we recommend to use JSON saving format (".save" function).', category=DeprecationWarning)
        with open(savepath, 'wb') as fw:
            rkme_to_save = copy.deepcopy(self.__dict__)
            pickle.dump(rkme_to_save, fw)
            if verbose:
                print('RKME save attr: {} in {}'.format(rkme_to_save.keys(), savepath))
    
    def load_pkl(self, filepath='saved_spec.pkl', verbose=False):
        warnings.warn('The pkl saving format is not easy to read, we recommend to use JSON saving format (".load" function).', category=DeprecationWarning)
        fr = open(filepath, 'rb')
        rkme_load = pickle.load(fr)
        fr.close()
        # self = rkme
        for d in self.__dir__():
            if d in rkme_load.keys():
                if verbose:
                    print('Loading attr: {} from {}'.format(d, filepath))
                setattr(self, d, rkme_load[d])


# fr = open(filepath, 'rb')
# rkme_load = pickle.load(fr)
# fr.close()
# # self = rkme
# for d in self.__dir__():
# 	if d in rkme_load.keys():
# 		if verbose:
# 			print('Loading attr: {} from {}'.format(d, filepath))
# 		setattr(self, d, rkme_load[d])


class RKME_Searcher():
    
    def __init__(self, list_of_Phi):
        self.Phi = list_of_Phi
        self.c = len(list_of_Phi)
        self.gamma = list_of_Phi[0].gamma
    
    def cal_dist(self, Phi_t, cuda=False):
        dist_list = []
        for i in range(self.c):
            Phi_s = self.Phi[i]
            # dist2 = self.Phi[i].dist_between_reduced_sets(Phi_t)
            try:
                dist = MMD(Phi_t.z, Phi_s.z, Phi_t.beta,
                           Phi_s.beta, gamma=self.gamma,
                           cuda=cuda)
                dist_list.append(dist.cpu().item())
            except:
                dist_list.append(float("inf"))
        return dist_list


def MMD(x1, x2, beta1=None, beta2=None, omit_term1=False, gamma=1.0, cuda=False):
    device = choose_device(cuda=cuda)
    
    # || sum_i alpha1_i k(x1_i, \cdot) - sum_i alpha2_i k(x2_i, \cdot) ||_H^2
    if beta1 is None:
        beta1 = torch.ones(x1.shape[0]) / x1.shape[0]
    if beta2 is None:
        beta2 = torch.ones(x2.shape[0]) / x2.shape[0]
    
    if not torch.is_tensor(x1):
        x1 = torch.from_numpy(x1)
    if not torch.is_tensor(x2):
        x2 = torch.from_numpy(x2)
    if not torch.is_tensor(beta1):
        beta1 = torch.from_numpy(beta1)
    if not torch.is_tensor(beta2):
        beta2 = torch.from_numpy(beta2)
    
    beta1 = beta1.reshape(1, -1)
    beta2 = beta2.reshape(1, -1)
    
    assert beta1.size(1) == x1.size(0) and beta2.size(1) == x2.size(0)
    assert x1.size(1) == x2.size(1)
    
    # x1 = torch.tensor(x1, dtype=torch.float32)
    # x2 = torch.tensor(x2, dtype=torch.float32)
    # alpha1 = torch.tensor(alpha1, dtype=torch.float32)
    # alpha2 = torch.tensor(alpha2, dtype=torch.float32)
    
    x1 = x1.double()
    x2 = x2.double()
    beta1 = beta1.double()
    beta2 = beta2.double()
    
    x1 = x1.to(device)
    x2 = x2.to(device)
    beta1 = beta1.to(device)
    beta2 = beta2.to(device)
    
    if omit_term1:
        term1 = 0
    else:
        term1 = torch.sum(torch_rbf_kernel(
            x1, x1, gamma) * (beta1.T @ beta1))
    term2 = torch.sum(torch_rbf_kernel(x1, x2, gamma) * (beta1.T @ beta2))
    term3 = torch.sum(torch_rbf_kernel(x2, x2, gamma) * (beta2.T @ beta2))
    return (term1 - 2 * term2 + term3).detach().cpu()


if __name__ == '__main__':
    Num = 60000
    dim = 80
    spec_num = 100
    
    setup_seed(1234)
    
    # IMPORTANT: Input should be float 32
    X = np.random.randn(Num, dim).astype(np.float32)
    
    setup_seed(1234)
    t0 = time.time()
    rkme2 = StaSpec(gamma=0.01, cuda=True)
    # rkme2 = StaSpec(gamma=None, cuda=True)
    rkme2.fit(X, spec_num, 0.01, 3)
    specification2 = np.array(rkme2.z.detach().cpu())
    print('RKME_fast finished in {}s'.format(time.time() - t0))
    print('MMD Disc: {}'.format(
        MMD(X, specification2, beta2=rkme2.beta.detach().cpu(), cuda=False, omit_term1=True)))
    print('RKME+MMD finished in {}s'.format(time.time() - t0))
    rkme2.save('test.json')
    rkme2.save_pkl('test.pkl')
    
    rkme_new = StaSpec()
    rkme_new.load('test.json')
    rkme_new2 = StaSpec()
    rkme_new2.load_pkl('test.pkl')
