import math
import time

import numpy as np
import torch
from sklearn.metrics.pairwise import rbf_kernel
from tqdm import trange


def random_sample_idx(num, len_dataset):
	num = min(num, len_dataset)
	data_sample_id = np.random.choice(range(len_dataset), num, replace=False)
	data_sample_id = torch.from_numpy(data_sample_id)
	return data_sample_id


def choose_device(cuda=False):
	if cuda:
		device = torch.device("cuda:0")
	else:
		device = torch.device("cpu")
	return device


def softmax(x):
	"""Compute softmax values for each sets of scores in x."""
	e_x = np.exp(x - np.max(x))
	return e_x / e_x.sum()


def torch_rbf_kernel(x1, x2, gamma):
	X12norm = torch.sum(x1 ** 2, 1, keepdim=True) - 2 * x1 @ x2.T + torch.sum(x2 ** 2, 1, keepdim=True).T
	return torch.exp(-X12norm * gamma)


def MMD_disc(x1, x2, alpha1=None, alpha2=None, gamma=1.0):
	if alpha1 is None:
		alpha1 = torch.ones(x1.shape[0]) / x1.shape[0]
		alpha1 = alpha1.cuda() if x1.is_cuda else alpha1
	if alpha2 is None:
		alpha2 = torch.ones(x2.shape[0]) / x2.shape[0]
		alpha2 = alpha2.cuda() if x1.is_cuda else alpha2
	
	alpha1 = alpha1.reshape(1, -1)
	alpha2 = alpha2.reshape(1, -1)
	
	assert alpha1.size(1) == x1.size(0) and alpha2.size(1) == x2.size(0)
	
	x1 = x1.float()
	x2 = x2.float()
	alpha1 = alpha1.float()
	alpha2 = alpha2.float()
	
	term1 = torch.sum(torch_rbf_kernel(x1, x1, gamma) * (alpha1.T @ alpha1))
	term2 = torch.sum(torch_rbf_kernel(x1, x2, gamma) * (alpha1.T @ alpha2))
	term3 = torch.sum(torch_rbf_kernel(x2, x2, gamma) * (alpha2.T @ alpha2))
	return term1 - 2 * term2 + term3


class SKETCH():
	
	def __init__(self, M, gamma=0.1, get_weight=False):
		self.H = []
		self.beta = []
		self.gamma = gamma  # rbf_kernel parameter
		self.M = M  # Number of SKETCH points
		# self.numDim = numDim
		self.idxs = []
		self.get_weight = get_weight
	
	def _step2_get_beta(self, X_s):
		# H = np.array(self.H)
		# K_z = rbf_kernel(H, gamma=self.gamma)
		
		K_z = torch_rbf_kernel(self.H, self.H, gamma=self.gamma)
		K_zx = torch_rbf_kernel(self.H, X_s, gamma=self.gamma)
		
		# print(self.beta)
		self.beta = torch.sum(torch.pinverse(K_z) @ K_zx, dim=1) / X_s.shape[0]
	
	# print(self.beta.shape)
	def _step1_get_samples_perstep_beta(self, step_idx, X_s, k_h_Xs, h_source):
		'''
        Since the RKHS Kernel \phi{x} is hard to compute, and the original
        w, h Iteration is hard to implement, we get the H from equation (9)
        instead.
        The sample space \mathcal{x} is the whole dataset X_s.
        input: h_{i}
        :return: h_{i+1}
        '''
		
		# total_obj = k_hi_Xs + k(X_s, H{0 ~ i-1})
		
		k_h_hpre = torch.zeros_like(k_h_Xs)
		
		if len(self.H) != 0:
			self._step2_get_beta(X_s)
			beta_now = self.beta
			beta_now = beta_now.reshape(-1, 1)
			beta_now = beta_now.repeat(1, h_source.shape[0])
			# print(beta_now.shape)
			k_h_hpre = torch.sum(torch_rbf_kernel(self.H, h_source, gamma=self.gamma) * beta_now,
								 dim=0)  # \sum k(h, h{0 ~ i-1}) * beta_now
		_, hi_idx = torch.max(k_h_Xs - k_h_hpre, dim=0)  # Choose H_i greedily.
		return h_source[hi_idx]  # H = H \and h_i
	
	def _step1_get_samples(self, step_idx, X_s, k_h_Xs, h_source):
		'''
        Since the RKHS Kernel \phi{x} is hard to compute, and the original
        w, h Iteration is hard to implement, we get the H from equation (9)
        instead.
        The sample space \mathcal{x} is the whole dataset X_s.
        input: h_{i}
        :return: h_{i+1}
        '''
		
		# total_obj = k_hi_Xs + k(X_s, H{0 ~ i-1})
		
		k_h_hpre = torch.zeros_like(k_h_Xs)
		
		if len(self.H) != 0:
			k_h_hpre = torch.sum(torch_rbf_kernel(self.H, h_source, gamma=self.gamma),
								 dim=0) / step_idx  # \sum k(h, h{0 ~ i-1}) / i
		
		re = k_h_Xs - k_h_hpre
		re[self.idxs] = -math.inf
		# _, hi_idx = torch.max(re, dim=0)  # Choose H_i greedily.
		
		# take the M largest index:
		_, hi_idx = torch.topk(re, self.M, largest=True)
		# print(hi_idx)
		return h_source[hi_idx], hi_idx  # H = H \and h_i
	
	def get_sketch(self, X_s):
		self.idxs = []
		self.H = []
		self.beta = []
		if not torch.is_tensor(X_s):
			X_s = torch.from_numpy(X_s)
		
		h_source = X_s
		
		# k_Xs_Xs = torch.sum(torch_rbf_kernel(X_s, X_s, gamma=self.gamma), dim=0) / X_s.shape[0]
		k_h_Xs = torch.sum(torch_rbf_kernel(X_s, h_source, gamma=self.gamma), dim=0) / X_s.shape[0]
		
		# for i in trange(1, self.M + 1, desc='Sketching using herding'):
		# 	hi, hi_idx = self._step1_get_samples(i, X_s, k_h_Xs, h_source=h_source)
		
		hi, hi_idx = self._step1_get_samples(1.0, X_s, k_h_Xs, h_source=h_source)
		# self.idxs[i - 1] = hi_idx
		# hi = self._step1_get_samples(i, X_s, k_Xs_Xs, h_source=X_s)
		hi = hi.reshape(1, -1)
		hi_idx = torch.tensor(hi_idx).long()
		if len(self.H) > 0:
			self.H = torch.cat((self.H, hi), 0)
			self.idxs = torch.cat((self.idxs, hi_idx), 0)
		else:
			self.H = hi
			self.idxs = hi_idx
		self.idxs = self.idxs.long()
		
		# print(self.H.shape)
		# alpha = torch.ones(X_s.shape[0]) * 1.0 / X_s.shape[0]
		if self.get_weight:
			self._step2_get_beta(X_s)  # get weight for each sketched sample
	
	def get_sketch_perstep_beta(self, X_s):
		if not torch.is_tensor(X_s):
			X_s = torch.from_numpy(X_s)
		
		h_source = X_s
		
		# k_Xs_Xs = torch.sum(torch_rbf_kernel(X_s, X_s, gamma=self.gamma), dim=0) / X_s.shape[0]
		k_h_Xs = torch.sum(torch_rbf_kernel(X_s, h_source, gamma=self.gamma), dim=0) / X_s.shape[0]
		
		for i in range(1, self.M + 1):
			hi = self._step1_get_samples_perstep_beta(i, X_s, k_h_Xs, h_source=h_source)
			# hi = self._step1_get_samples_perstep_beta(i, X_s, k_Xs_Xs, h_source=X_s)
			hi = hi.reshape(1, -1)
			if len(self.H) > 0:
				self.H = torch.cat((self.H, hi), 0)
			else:
				self.H = hi
		# print(self.H.shape)
		# alpha = torch.ones(X_s.shape[0]) * 1.0 / X_s.shape[0]
		self._step2_get_beta(X_s)
	
	def eval(self, X):
		# Compute Phi(X)
		Z = np.array(self.z)
		beta = np.array(self.beta)
		v = np.zeros((Z.shape[0], X.shape[0]))
		for i in range(Z.shape[0]):
			z_i = self.z[i].reshape(1, -1)  # z: 10 * 512, X: 1 * 10000
			v[i, :] = beta[i] * rbf_kernel(z_i, X, gamma=self.gamma)
		v = np.sum(v, axis=0)
		return v
	
	def eval_mine(self, X):  # calculate MMD
		# Compute Discrepancy
		n_tr = self.K  # 10
		n_te = X.shape[0]  # 10000
		
		K = rbf_kernel(self.z, self.z, gamma=self.gamma)  # 10 * 10
		
		K2 = rbf_kernel(self.z, X, gamma=self.gamma)  # 10 * 10000
		k = np.sum(K2, axis=1).reshape(-1, 1)  # 10
		beta = np.array(self.beta).reshape(-1, 1)  # 10 * 1
		# print('beat:', beta)
		disc = (beta.T @ K @ beta) / (n_tr ** 2) - 2.0 * (k.T @ beta) / n_tr / n_te
		return disc
	
	def approx_error(self, X_s):
		alpha = np.ones(X_s.shape[0]) / X_s.shape[0]
		beta = np.array(self.beta)
		# Z = np.array(self.z)
		H = self.H.numpy()
		beta = self.beta.numpy()
		gamma = self.gamma
		term_0 = 0
		term_1 = 0
		term_2 = 0
		for i in range(X_s.shape[0]):
			x_i = X_s[i, :].reshape(1, -1)
			term_0 += alpha[i] * np.dot(alpha, np.ravel(rbf_kernel(x_i, X_s, gamma)))
		for i in range(H.shape[0]):
			H_i = H[i, :].reshape(1, -1)
			term_1 += beta[i] * np.dot(beta, np.ravel(rbf_kernel(H_i, H, gamma)))
			term_2 += beta[i] * np.dot(alpha, np.ravel(rbf_kernel(H_i, X_s, gamma)))
		return term_0 + term_1 - 2 * term_2
	
	def approx_error_nobeta(self, X_s):
		alpha = np.ones(X_s.shape[0]) / X_s.shape[0]
		beta = np.array(self.beta)
		# Z = np.array(self.z)
		H = self.H.numpy()
		beta = np.ones(self.M) / self.M
		gamma = self.gamma
		term_0 = 0
		term_1 = 0
		term_2 = 0
		for i in range(X_s.shape[0]):
			x_i = X_s[i, :].reshape(1, -1)
			term_0 += alpha[i] * np.dot(alpha, np.ravel(rbf_kernel(x_i, X_s, gamma)))
		for i in range(H.shape[0]):
			H_i = H[i, :].reshape(1, -1)
			term_1 += beta[i] * np.dot(beta, np.ravel(rbf_kernel(H_i, H, gamma)))
			term_2 += beta[i] * np.dot(alpha, np.ravel(rbf_kernel(H_i, X_s, gamma)))
		return term_0 + term_1 - 2 * term_2


if __name__ == '__main__':
	# Test the SKETCH class
	X = np.random.randn(100, 512)
	sketch = SKETCH(10)
	sketch.get_sketch(X)
	sketched_idx = sketch.idxs
