# Python implementation for "Handling New Class in Online Label Shift"

This is the python implementation for the experiments in the paper "**Handling New Class in Online Label Shift**". We will first introduce the structure and requirements of the code, followed by a brief instruction for a quick start.

## Code Structure

`main.py` is the entrance of the program. The code mainly contains the following three parts.

- **online**: Implementations of the proposed algorithm HAndling New class in Online Label shift (HANOL).

- **dataset**: Code for datasets pre-processing.

- **utils_pkg**: Useful tools for running the code.

## Requirements

- matplotlib==3.3.3
- numpy==1.19.2
- pandas==1.4.1
- prettytable==0.9.2
- PyYAML==6.0
- scikit_learn==0.23.2
- torch==2.0.1
- tqdm==4.62.3

## Quick Start

We provide several demos in the folder _./demos_. To get a quick start, the readers can run any demo by the parameter specified in `config.yaml` in that folder.

For example, one can use `python main_nc.py --config_path ./demos/NewClass/locomotion/HANOL_with_Detector/config.yaml` to run HANOL algorithm over the SHL (locomotion) dataset, whose parameters are set as `./demos/locomotion/HANOL/config.yaml`

| Method     | Running Commands for Locomotion EN-OLS Problem                                                     | Result (err%) | Efficiency (it/s) |
|------------|----------------------------------------------------------------------------------------------------|---------------|-------------------|
| FIX        | `python main_nc.py --config_path ./demos/NewClass/locomotion/FIX/config.yaml`                      | 44.82         |                   |
| SENCForest | `python main_nc.py --config_path ./demos/NewClass/locomotion/SENCForest/config.yaml`               | 32.28         | 194.96            |
| HANOL_full | `python main_nc.py --config_path ./demos/NewClass/locomotion/HANOL_with_Detector/config.yaml`      | 28.64         | 124.32            |
| HANOL      | `python main_nc.py --config_path ./demos/NewClass/locomotion/HANOL_Detector_Efficient/config.yaml` | 29.37         | 156.24            |