set -ex
expr_root=`pwd`


while [[ $# -gt 0 ]]
do
    key="$1"
    case $key in
        -o|--output)
            expr_root=$2
            shift 2
            ;;
        *)
            echo invalid arg [$1]
            exit 1
            ;;
    esac
done

output=${expr_root}/output
mkdir -p $output
date > $output/log.txt

while [ ! -f "main_nc.py" ]
do
    cd ..
done


python -u main_nc.py \
    --config_path ${expr_root}/config.yaml | tee -a $output/log.txt

