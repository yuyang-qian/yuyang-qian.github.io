# /usr/bin/env python
# -*- coding: utf-8 -*-
import logging
import argparse
import json as js
import copy
import os
import time
from os.path import join

import warnings

import torch
from torch.utils.data import Subset

warnings.filterwarnings("ignore", category=UserWarning)

os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
os.environ['CUDA_VISIBLE_DEVICES'] = '7'
import numpy as np
import torch.utils.data as data
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm

from dataset.NewClass.wrapper import get_dataset
from offline_train.NewClass.DNN_bbse import DNN_BBSE
from models_pkg.wrapper import get_cls_model, get_rep_model

from online.algorithms.NewClass.wrapper import get_online_alg
# from models_pkg.bbse import BBSE
from online.utils.risk import *
from utils_pkg import exp_config
# from utils_pkg import argparser

from utils_pkg.timer import Timer
from utils_pkg.utils import setup_seed

from utils_pkg.distances import KL_divegence_diff, mutual_info_diff
from sklearn.metrics import f1_score

logging.getLogger("pytorch_lightning").setLevel(logging.WARNING)


def write(writer, info, t):
    for k, v in info.items():
        writer.add_scalar(k, v, t)


def set_gpu_id(gpu_ids='0'):
    os.environ['CUDA_VISIBLE_DEVICES'] = gpu_ids


def set_cpu_num(cpu_num=8):
    os.environ['OMP_NUM_THREADS'] = str(cpu_num)
    os.environ['OPENBLAS_NUM_THREADS'] = str(cpu_num)
    os.environ['MKL_NUM_THREADS'] = str(cpu_num)
    os.environ['VECLIB_MAXIMUM_THREADS'] = str(cpu_num)
    os.environ['NUMEXPR_NUM_THREADS'] = str(cpu_num)
    torch.set_num_threads(cpu_num)
    torch.set_num_interop_threads(cpu_num)


def sample_dataset(data, labels, prior_estimate, N):
    if torch.is_tensor(data):
        num_samples = data.shape[0]
    else:
        num_samples = len(data)
    num_classes = len(prior_estimate)
    prior_estimate = torch.maximum(prior_estimate, torch.ones_like(prior_estimate) * 1e-1)
    prior_estimate = torch.softmax(prior_estimate, dim=0)
    class_probabilities = prior_estimate.unsqueeze(0).expand(num_samples, -1)
    
    sampled_indices = torch.multinomial(class_probabilities, 1).squeeze().detach().cpu()
    # sampled_indices = [i for i in range(len(sampled_indices)) if labels[i] == sampled_indices[i]]
    sampled_indices = torch.tensor(sampled_indices == torch.from_numpy(labels)).detach().nonzero(as_tuple=True)[0]
    sampled_indices = torch.tensor(sampled_indices).detach()
    perm = torch.randperm(sampled_indices.size(0))
    selected_samples = sampled_indices[perm[:N]]
    
    return selected_samples


def compute_f1_multi(y_true, y_pred):
    # y_pred = torch.argmax(y_pred, dim=1)  # get the class with the highest probability
    y_pred = y_pred.detach().cpu().numpy()
    y_true = y_true.cpu().numpy()
    
    return f1_score(y_true, y_pred, average='macro')  # 'macro' will take the mean of F1 Score from each class


def accuracy_top3(output, target, topk=(1, 2, 3)):
    """Computes the accuracy over the k top predictions for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)
        
        _, pred = output.topk(maxk, 1, True, True)
        # pred = pred.t()
        correct = pred.eq(target.view(-1, 1).expand_as(pred))
        
        res = []
        for k in topk:
            correct_k = correct[:k].view(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
        return res


class DistCal:
    def __init__(self, data_info, buffer_size=1000, new_class=None, dis='KL'):
        # buffer_size = math.inf
        self.buffer_size = buffer_size
        self.dis = dis
        self.data_info = data_info
        self.buffer = None
        self.total_dist = 0.0
        self.new_class = new_class
    def get_distance(self, train_set, target_data, target_label, underlying_priors, t):
        if self.dis == 'KL':
            num_classes = self.data_info['cls_num']
            try:
                source_label = train_set.labels
            except:
                source_label = train_set.y
            
            new_class_num = 0
            for i in self.new_class:
                # delete in source_label
                source_label[source_label == i] = -1
                new_class_num += (target_label == i).sum().item()
            
            if torch.is_tensor(target_label):
                target_label = target_label.cpu().numpy()
            
            # add target_label to buffer
            if self.buffer is None:
                self.buffer = target_label
            else:
                self.buffer = np.concatenate([self.buffer, target_label], axis=0)
                if self.buffer.shape[0] > self.buffer_size:
                    self.buffer = self.buffer[-self.buffer_size:]
            self.total_dist += (KL_divegence_diff(self.buffer, source_label, num_classes) + new_class_num / target_label.shape[0]) / 2.0
            return KL_divegence_diff(self.buffer, source_label, num_classes)
        
        if self.dis == 'mutual_info':
            num_classes = self.data_info['cls_num']
            source_label = train_set.labels
            
            # add target_label to buffer
            if self.buffer is None:
                self.buffer = target_label
            else:
                self.buffer = np.concatenate([self.buffer, target_label], axis=0)
                if self.buffer.shape[0] > self.buffer_size:
                    self.buffer = self.buffer[-self.buffer_size:]
            self.total_dist += mutual_info_diff(self.buffer, source_label, num_classes)
            return mutual_info_diff(self.buffer, source_label, num_classes)


def run(T, train_set, test_set, estimator, online_alg, cfgs: exp_config.Config, data_info, device='cuda', writer=None):
    # procedure:
    # 1. estimate prior;
    # 2. get prior by BBSE;
    # 3. get prediction;
    # 4. get loss to update model
    if T > len(test_set):
        T = len(test_set)
        print(f'Warning: cfgs.T={cfgs.T}, too great, set T to len(test_set)={len(test_set)}')
    nc_cfg = cfgs.data_cfgs.kwargs['online_data']['newclass_cfg']
    new_class = nc_cfg.get('new_class')
    distcal = DistCal(data_info, buffer_size=cfgs.online_cfgs.dist_buffer_size, new_class=new_class)
    record = []
    cumulative_estimate_loss, cumulative_underlying_loss, error_cnt, nc_error_cnt, nc_total_num = 0, 0, 0, 0, 1e-9
    
    loss_cfgs = cfgs.online_cfgs.kwargs.get('loss', {})
    loss_name = loss_cfgs.get('name', 'RewritingRisk')
    nn_loss = loss_cfgs.get('nn_loss', False) or \
              cfgs.online_cfgs.kwargs.get('nn_loss', False)
    
    loss_func = eval(loss_name)(device=device, nn_loss=nn_loss, cfgs=cfgs)
    print('Loss {}, Use nn: {}'.format(loss_name, nn_loss))
    
    time_helper = Timer()
    time_helper.tik()
    f1_list = []
    top_3_list = []
    tot_new_class_num = 0
    tot_sample_num = 0
    tot_estimate_class_prior = 0.0
    
    tiny_set = copy.deepcopy(train_set)
    tiny_set.data = tiny_set.data[:10]
    tiny_set.labels = tiny_set.labels[:10]
    tiny_set.label_mask = tiny_set.label_mask[:10]
    
    for t in tqdm(range(T)):
        
        target_data, target_label, target_label_masks = test_set.getitem_NewClass(t)
        
        # PvU_dataset = Subset(test_set, list(range(t, t + test_set.interval)))
        # PvU_dataset.dataset.pvu = True
        # PvU_dataset = ConcatDataset([train_set, PvU_dataset])
        
        # the distance calculation for N-OLS problem
        diff_distance = distcal.get_distance(train_set, target_data, target_label, target_label_masks, t)
        
        avg_diff_distance = distcal.total_dist / (t + 1)
        
        target_data = target_data.to(device)
        sample_num = target_data.shape[0]
        if sample_num == 0: continue
        prior_estimate = estimator.estimate(target_data).to(device)  # \tilde{mu} estimated by BBSE
        
        # use resampled train_set instead of full of train_set (resample according to prior_estimate)
        sampled_idx = sample_dataset(train_set.data, train_set.labels, prior_estimate, len(target_data))
        PvU_dataset = copy.deepcopy(tiny_set)
        
        # if 'wilds' in cfgs.data_cfgs.name:
        # rand_sample_idx = torch.randperm(len(test_set.data))[:max(len(target_data), 1024)]
        interval = test_set.interval
        PvU_dataset.data = [train_set.data[i] for i in sampled_idx.tolist()] + [test_set.data[i] for i in range(t * interval, (t + 1) * interval)]
        # [rand_sample_idx]
        # PvU_dataset.data = torch.cat([PvU_dataset.data[sampled_idx], target_data.cpu()], dim=0)
        PvU_dataset.labels = torch.cat([torch.tensor(train_set.labels)[sampled_idx], torch.tensor(target_label)], dim=0)
        PvU_dataset.label_mask = torch.cat([torch.tensor(train_set.label_mask)[sampled_idx], torch.tensor(target_label_masks)], dim=0)
        # else:
        #     PvU_dataset.data = torch.cat([train_set.data[sampled_idx], target_data.cpu()], dim=0)
        #     PvU_dataset.labels = torch.cat([torch.tensor(train_set.labels)[sampled_idx], torch.tensor(target_label)], dim=0)
        #     PvU_dataset.label_mask = torch.cat([torch.tensor(train_set.label_mask)[sampled_idx], torch.tensor(target_label_masks)], dim=0)

        loss_func.set_priors(prior_estimate, target_label_masks)
        online_alg.set_criterion(loss_func)
        
        result = online_alg.alg_forward(target_data, prior_estimate, PvU_dataset, t)
        # output = None
        if len(result) == 3:
            pred, estimate_loss, underlying_loss = result
            # uniform prior
            new_class_prior = 1 / data_info['cls_num']
        else:
            pred, estimate_loss, underlying_loss, new_class_prior = result
        
        ori_pred = None
        if isinstance(pred, dict):
            ori_pred = pred['Ori']
            pred = pred['Opt']
        
        new_class = cfgs.data_cfgs.kwargs['online_data']['newclass_cfg'].get('new_class')
        target_label = target_label.to(pred.device)
        # if cfgs.online_cfgs.algorithm in ['ATLAS', 'FIX', 'DNN_FIX', 'FTH', 'FTFWH', 'DNN_OGD', 'GEM', 'AGEM', 'DNN_AGEM', 'DNN_GEM']:
        #     for c in new_class:
        #         pred[target_label == c] = -1
        if cfgs.online_cfgs.algorithm in ['ATLAS', 'FIX', 'DNN_FIX', 'FTH', 'FTFWH', 'OGD', 'DNN_OGD', 'AGEM', 'DNN_AGEM', 'DNN_GEM']:
            for c in new_class:
                pred[target_label == c] = -1
        _error_cnt = (pred.view_as(target_label) != target_label).sum().item()
        error_cnt += _error_cnt
        
        nc_list = cfgs.data_cfgs.kwargs['online_data']['newclass_cfg']['new_class']
        # error of labels in nc_list:
        nc_idx = [i for i in range(len(target_label)) if (target_label[i]).item() in nc_list]
        if len(nc_idx) == 0:
            _nc_error_cnt = 0
        else:
            _nc_error_cnt = (pred[nc_idx].view_as(target_label[nc_idx]) != target_label[nc_idx]).sum().item()
            nc_error_cnt += _nc_error_cnt
            nc_total_num += len(nc_idx)
        
        tot_sample_num += sample_num
        # tot_new_class_num += torch.isin(target_label.detach().cpu(), torch.tensor(new_class)).sum().item()
        
        tot_new_class_num += np.isin(target_label.detach().cpu().numpy(), new_class).sum()
        
        mpe_true = tot_new_class_num / tot_sample_num
        tot_estimate_class_prior = new_class_prior * sample_num / tot_sample_num + tot_estimate_class_prior * (
            1 - sample_num / tot_sample_num)
        
        avg_error = error_cnt / ((t + 1) * sample_num)
        avg_nc_error = nc_error_cnt / nc_total_num
        
        f1 = compute_f1_multi(target_label, pred)
        f1_list.append(f1)
        
        # top_3_list.append(accuracy_top3(output.detach(), target_label.detach().reshape(-1, 1)))
        
        cumulative_estimate_loss += estimate_loss
        
        if underlying_loss is not None:
            cumulative_underlying_loss += underlying_loss
        if writer is not None:
            res_info = {
                'Estimate/Estimate Loss'        : estimate_loss,
                'Estimate/Cumulative Loss'      : cumulative_estimate_loss,
                'Estimate/Prior[0]'             : prior_estimate[0],
                'Underlying/Avg Error'          : avg_error,
                'Underlying/Avg NC Error'       : avg_nc_error,
                'Underlying/Cumulative Error'   : error_cnt,
                'Underlying/Cumulative NC Error': nc_error_cnt,
                'MPE/True'                      : mpe_true,
                'MPE/Estimated'                 : tot_estimate_class_prior,
                'diff_distance'                 : diff_distance,
                'avg_diff_distance'             : avg_diff_distance,
            }
            # if underlying_loss is not None and target_label_masks is not None:
            #     res_info.update({
            #         'Underlying/1-Underlying Loss': underlying_loss,
            #         'Underlying/2-Cumulative Loss': cumulative_underlying_loss,
            #         'Underlying/5-Prior[0]'       : target_label_masks[0],
            #     })
            
            write(writer, res_info, t)
            for k, v in res_info.items():
                res_info[k] = v.item() if isinstance(v, torch.Tensor) else v
            record.append(res_info)
        
        if t % cfgs.log_interval == 0:
            print('estimated_new_class_prior:', tot_estimate_class_prior, 'real_new_class_prior:', mpe_true)
            time_helper.tok('{} rounds'.format(t))
            print(
                '\n[Time {}] Estimate Loss: {}, F1 Score: {}, Avg Error: {}, Avg NC Error: {}/{}'.format(
                    t, estimate_loss,
                    np.average(np.array(f1_list)),
                    avg_error,
                    round(avg_nc_error * nc_total_num),
                    round(nc_total_num)
                ))
        
        if t == T - 1:
            time_helper.tok('{} rounds'.format(t))
            print('\n\n---------------------------------------------------------------------------------')
            print('| Methods: {}, Dataset: {}                                           |'
                  .format(cfgs.online_cfgs.algorithm, cfgs.data_cfgs.name))
            print(
                '| Final Result:                                                                    |\n'
                '| Estimate Loss: {}\t\t\tUnderlying Loss: {} |\t\t\n'
                '| Avg Error: {}\t\t\tAvg DistributionShift: {} |'.format(estimate_loss,
                                                                          underlying_loss,
                                                                          avg_error,
                                                                          avg_diff_distance))
            
            print('---------------------------------------------------------------------------------\n\n')
    
    return record


def stepsize(cfgs: exp_config.Config, sigma_min, K):
    alg = cfgs.online_cfgs.algorithm
    kwargs = cfgs.online_cfgs.kwargs
    D = float(kwargs['D'])
    G = float(kwargs['G'])
    T = cfgs.T
    
    print('D: {}, G: {}, T:{}'.format(D, G, T))
    print('K: {}, Sigma: {}'.format(K, sigma_min))
    
    step_rate = cfgs.online_cfgs.kwargs.get('step_lr_rate', 1.0)
    min_step, max_step = D * step_rate / (G * (T ** 0.5)), D / G * step_rate
    
    max_step_clip = kwargs.get('max_step_clip', max_step)
    max_step = min(max_step, max_step_clip)
    
    return min_step, max_step


parser = argparse.ArgumentParser(
    'PyTorch implementation for Streaming Data Project'
)

# parser.add_argument('--config_path', type=str, default='./demos/NewClass/locomotion/HANOL/config.yaml')
# parser.add_argument('--config_path', type=str, default='./demos/NewClass/locomotion/HANOL_with_Detector/config.yaml')
# parser.add_argument('--config_path', type=str, default='./demos/NewClass/locomotion/HANOL_rep/config.yaml')
parser.add_argument('--config_path', type=str, default='./demos/NewClass/locomotion/HANOL_with_Detector/config.yaml')
# parser.add_argument('--config_path', type=str, default='./demos/NewClass/locomotion/HANOL_Detector_Efficient/config.yaml')
# parser.add_argument('--config_path', type=str, default='./demos/NewClass/locomotion/FIX/config.yaml')
# parser.add_argument('--config_path', type=str, default='./demos/NewClass/locomotion/UOGD/config.yaml')
# parser.add_argument('--config_path', type=str, default='./demos/NewClass/locomotion/SENCForest/config.yaml')

parser.add_argument('--remark', type=str, default='')
# parser.add_argument('--task_name', type=str, default='')

'''
Methods:
OGD: DOGD
OMDLastOp: Optimism set as last gradient
OMDEnsemble_LACH: our proposed LACH
'''

if __name__ == "__main__":
    # cfgs = argparser()
    
    args = parser.parse_args()
    
    cfgs = exp_config.Config(config_path=args.config_path, remark=args.remark)
    
    setup_seed(cfgs.seed)
    set_gpu_id(gpu_ids=cfgs.hardware_cfgs.gpu_ids)
    experiment = cfgs.task_name
    
    device = cfgs.hardware_cfgs.device
    cpu_num = cfgs.hardware_cfgs.cpu_num
    set_cpu_num(cpu_num)
    rng = np.random.default_rng(cfgs.seed)
    
    train_set, test_set, data_info = get_dataset(
        # name=cfgs['Data']['name'],
        name=cfgs.data_cfgs.name,
        cfgs=cfgs,
        data_cfgs_kwargs=cfgs.data_cfgs.kwargs,
        rng=rng
    )
    
    cfgs.data_cfgs.kwargs['cls_num'] = data_info['cls_num']
    cfgs.data_cfgs.kwargs['dim'] = data_info['dim']
    cfgs.data_cfgs.kwargs['data_info'] = data_info
    
    # BBSE estimation
    # bbox, _ = get_cls_model(cfgs, cfgs.offline_cfgs.type, data_info, device)
    # bbox, _ = get_cls_model(cfgs, cfgs.offline_cfgs.type, data_info, device, cfgs.online_cfgs.cls_model_name, cfgs.offline_cfgs.BBSE_path)
    offline_rep_model, _ = get_rep_model(cfgs, cfgs.offline_cfgs, cfgs.offline_cfgs.type, data_info, device, cfgs.offline_cfgs.rep_model_name, cfgs.offline_cfgs.rep_model_path)
    offline_cls_model, _ = get_cls_model(cfgs, cfgs.offline_cfgs, cfgs.offline_cfgs.type, data_info, device, cfgs.offline_cfgs.cls_model_name, cfgs.offline_cfgs.cls_model_path)
    
    source_loader = data.DataLoader(train_set,
                                    batch_size=cfgs.offline_cfgs.source_batch_size,
                                    shuffle=True,
                                    pin_memory=False)
    # print('source loader:', source_loader.dataset.data.shape)
    # estimator = BBSE(bbox=bbox,
    #                  source_loader=source_loader,
    #                  cls_num=data_info['cls_num'],
    #                  device=device,
    #                  kwargs=cfgs.offline_cfgs.kwargs,
    #                  )
    estimator = DNN_BBSE(cfgs=cfgs,
                         rep_model=offline_rep_model,
                         cls_model=offline_cls_model,
                         train_set=train_set,
                         cls_num=data_info['cls_num'],
                         device=device,
                         kwargs=cfgs.offline_cfgs.kwargs,
                         )
    sigma_min = estimator.get_sigma_min()
    cfgs.online_cfgs.kwargs['sigma_min'] = sigma_min
    # cfgs['Online']['kwargs']['sigma_min'] = sigma_min
    min_step, max_step = stepsize(cfgs,
                                  sigma_min,
                                  data_info['cls_num'])
    models_dict = {}
    # offline_cls_model, _ = get_cls_model(cfgs, cfgs.offline_cfgs.type, data_info, device, cfgs.online_cfgs.cls_model_name, cfgs.offline_cfgs.BBSE_path)
    online_cls_model, cls_init = get_cls_model(cfgs, cfgs.online_cfgs, cfgs.online_cfgs.type, data_info, device, cfgs.online_cfgs.cls_model_name, cfgs.online_cfgs.cls_model_path)
    online_rep_model, rep_init = get_rep_model(cfgs, cfgs.online_cfgs, cfgs.online_cfgs.type, data_info, device, cfgs.online_cfgs.rep_model_name, cfgs.online_cfgs.rep_model_path)
    
    models_dict['offline_cls_model'] = offline_cls_model
    models_dict['online_cls_model'] = online_cls_model
    models_dict['cls_init'] = cls_init
    models_dict['rep_init'] = rep_init
    models_dict['offline_rep_model'] = offline_rep_model
    models_dict['online_rep_model'] = online_rep_model
    
    online_alg = get_online_alg(cfgs, cfgs.online_cfgs, min_step, max_step, models_dict, train_set, device, rng, data_info)
    
    writer = None
    if cfgs.online_cfgs.write:
        writer = SummaryWriter(join(cfgs.output_dir,
                                    'runs_{}'.format(time.strftime("%a_%b_%d_%H:%M:%S",
                                                                   time.localtime()))))
    print('\n****************************************************\nExp Config:\n', cfgs)
    record = run(cfgs.T, train_set, test_set, estimator, online_alg, cfgs, data_info, device=device, writer=writer)
    
    with open(join(cfgs.output_dir, 'result.json'), 'w') as fw:
        js.dump(record, fw, indent=4)
