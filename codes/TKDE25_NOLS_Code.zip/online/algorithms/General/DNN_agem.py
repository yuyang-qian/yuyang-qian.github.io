import torch
import torch.nn as nn
from torch.optim import *
from torch.utils.data import DataLoader
from tqdm import tqdm, trange

from online.algorithms.General.DNN_base import DNN_base
from utils_pkg import exp_config
from utils_pkg.tools import Timer
from utils_pkg.tools import tensor2scalar

import abc
import random

from utils_pkg.utils import collate_first2_args


class DNN_AGEM(DNN_base, metaclass=abc.ABCMeta):
    
    @abc.abstractmethod
    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **algo_kwargs):
        super(DNN_AGEM, self).__init__(cfgs=cfgs, **algo_kwargs)
        self.lr = stepsize
        
        self.optimizer = None
        print('DNN_OGD Stepsize: {}'.format(self.lr))
        
        self.estimate_result = {
            'D': [],
            'G': [],
        }
        
        self.grad_clip = self.cfgs.online_cfgs.grad_clip
        self.projection = self.cfgs.online_cfgs.kwargs.get('projection', False)
        
        if self.cfgs.online_cfgs.update_DNN_represent:
            self.rep_data_buffer = []
            # self.dataloader = DataLoader(self.alg_kwargs['dataset'],
            #                              num_workers=0,
            #                              batch_size=self.cfgs.online_cfgs.kwargs['rep_batch_size'],
            #                              shuffle=True,
            #                              pin_memory=False,
            #                              collate_fn=collate_first2_args)
            # for batch_idx, (data, target) in enumerate(self.dataloader):
            #     # initialize the rep_data_buffer to be the (source data and source label)
            #     # data, target = data.to(self.device), target.to(self.device)
            #     self.rep_data_buffer.append((data, target))
        
        if not cfgs.online_cfgs.kwargs.get('is_base_expert', False):
            # whether this DNN_OGD is a base experts? (of ATLAS or WavRestart)
            self.source_rep, self.source_label = self.get_rep_of_data(self.alg_kwargs['dataset'])
        
        # # collect G & D for ATLAS
        # self._max_grad_norm = 0.0
        # self._max_input_radius = 0.0
        
        self._agem_pool = list(self.alg_kwargs['dataset'])
        # _x, _y = self._agem_pool[i]
        # _x: tensor of shape [3, 224, 224]
        # _y: tensor of shape [] (integer, not a tensor)

    def opt_rep(self):
        '''
        Optimize the representation layer (except the last layer classifier) with OGD.
        '''
        #     use data and label in rep_data_buffer to optimize the rep_model
        self.online_rep_model.train()
        self.online_cls_model = self.online_cls_model.to(self.device)
        
        if self.cfgs.online_cfgs.kwargs.get('only_opt_rep', False):
            # optimizer only the rep_model
            text = 'only opt rep model'
            self.online_cls_model.eval()
            # optimizer = SGD(self.online_rep_model.parameters(), lr=float(self.cfgs.online_cfgs.kwargs['rep_lr']))
            _agem_lr = float(self.cfgs.online_cfgs.kwargs['rep_lr'])
            
        else:
            # optimizer both the rep_model and cls_model
            text = 'opt rep and cls models'
            self.online_cls_model.train()
            # optimizer = SGD(list(self.online_rep_model.parameters()) + list(self.online_cls_model.parameters()),
            #                 lr=float(self.cfgs.online_cfgs.kwargs['rep_lr']))
            _agem_lr = float(self.cfgs.online_cfgs.kwargs['rep_lr'])
        
        # optimizer.zero_grad()
        
        loss = 0.0
        for epoch in range(self.cfgs.online_cfgs.kwargs['rep_optimize_epoch']):
            # for data, label in tqdm(self.rep_data_buffer, desc='Optimize {}, loss={}'.format(text, loss), leave=True):
            #     label = label.to(self.device)
            #     data = data.to(self.device)
            #     data = self.online_rep_model(data)
            #     output = self.online_cls_model(data)
            #     # use logistic loss to optimize the online_rep_model
            #     loss = nn.CrossEntropyLoss()(output, label)
            #     loss.backward()
            #     optimizer.step()

            _batch_size = self.cfgs.online_cfgs.kwargs['rep_batch_size']

            for _batch_idx in trange(len(self.rep_data_buffer) // _batch_size, desc='Optimize {}, loss={}'.format(text, loss), leave=True):

                # ======== grad on new stream data ========

                if self.cfgs.online_cfgs.kwargs.get('only_opt_rep', False):
                    _agem_para = self.online_rep_model.parameters()
                else:
                    _agem_para = list(self.online_rep_model.parameters()) + list(self.online_cls_model.parameters())

                label = torch.tensor(
                    [label for data, label in self.rep_data_buffer[_batch_idx * _batch_size : (_batch_idx + 1) * _batch_size]]
                ).to(self.device)
                data = torch.stack(
                    [data for data, label in self.rep_data_buffer[_batch_idx * _batch_size : (_batch_idx + 1) * _batch_size]]
                ).to(self.device)
                data = self.online_rep_model(data)
                output = self.online_cls_model(data)
                
                _erm_obj = nn.CrossEntropyLoss()(output, label)
                _erm_grad = torch.autograd.grad(_erm_obj, _agem_para)
                # tuple of 171 tensors (MobileNet)

                # ======== grad on random old data ========

                if self.cfgs.online_cfgs.kwargs.get('only_opt_rep', False):
                    _agem_para = self.online_rep_model.parameters()
                else:
                    _agem_para = list(self.online_rep_model.parameters()) + list(self.online_cls_model.parameters())

                _pool_size = len(self._agem_pool) // _batch_size
                _rand_idx = random.randrange(0, _pool_size)
                
                label = torch.tensor(
                    [label for data, label in self._agem_pool[_rand_idx * _batch_size : (_rand_idx + 1) * _batch_size]]
                ).to(self.device)
                data = torch.stack(
                    [data for data, label in self._agem_pool[_rand_idx * _batch_size : (_rand_idx + 1) * _batch_size]]
                ).to(self.device)
                data = self.online_rep_model(data)
                output = self.online_cls_model(data)
                
                _memory_obj = nn.CrossEntropyLoss()(output, label)
                _memory_grad = torch.autograd.grad(_memory_obj, _agem_para)
                # tuple of 171 tensors (MobileNet)

                # ======== project _erm_grad on _memory_grad ========

                if self.cfgs.online_cfgs.kwargs.get('only_opt_rep', False):
                    _agem_para = self.online_rep_model.parameters()
                else:
                    _agem_para = list(self.online_rep_model.parameters()) + list(self.online_cls_model.parameters())

                _final_grad = [None for _ in range(len(_erm_grad))]

                for _idx in range(len(_erm_grad)):
                    _erm_grad_idx = _erm_grad[_idx]
                    _grad_idx_shape = _erm_grad_idx.shape
                    _memory_grad_idx = _memory_grad[_idx]

                    _erm_grad_idx = _erm_grad_idx.flatten()
                    _memory_grad_idx = _memory_grad_idx.flatten()
                    _final_grad_idx = _erm_grad_idx - \
                        (torch.dot(_erm_grad_idx, _memory_grad_idx) / torch.dot(_memory_grad_idx, _memory_grad_idx)) \
                        * _memory_grad_idx
                    _final_grad_idx = _final_grad_idx.view(_grad_idx_shape)
                    del _erm_grad_idx, _memory_grad_idx, _grad_idx_shape

                    _final_grad[_idx] = _final_grad_idx

                for _param_idx, _grad_idx in zip(_agem_para, _final_grad):
                    _param_idx.data -= _grad_idx * _agem_lr

        # get self.source_rep using the rep_model
        self.source_rep, self.source_label = self.get_rep_of_data(self.alg_kwargs['dataset'])

        print(f'len(self.rep_data_buffer)={len(self.rep_data_buffer)}, len(self._agem_pool)={len(self._agem_pool)}')

        for _x, _y in self.rep_data_buffer:
            self._agem_pool.append((_x, _y))

        self.rep_data_buffer = []
    
    @torch.no_grad()
    def get_rep_of_data(self, dataset):
        dataloader = DataLoader(dataset,
                                num_workers=0,
                                batch_size=self.cfgs.online_cfgs.kwargs.get('rep_batch_size', 256),
                                shuffle=False,
                                pin_memory=False,
                                collate_fn=collate_first2_args)
        tot_rep = None
        tot_label = None
        for batch_idx, (data, label) in enumerate(tqdm(dataloader, desc='Updating rep_data')):
            if self.online_rep_model is not None:
                data = data.to(self.device)
                rep = self.online_rep_model(data).cpu()
            else:
                rep = data.cpu()
            label = label.cpu()
            if tot_rep is None:
                tot_rep = rep
                tot_label = label
            else:
                tot_rep = torch.cat((tot_rep, rep), dim=0)
                tot_label = torch.cat((tot_label, label), dim=0)
        return tot_rep, tot_label
    
    def opt_cls_one_batch(self, source_rep, source_label, target_data):
        self.online_cls_model = self.online_cls_model.cpu()
        self.online_cls_model.train()
        timer = Timer()
        optimizer = SGD(self.online_cls_model.parameters(), lr=self.lr)
        optimizer.zero_grad()
        
        # if self.online_rep_model is not None:
        #     self.online_rep_model.eval()
        #     source_data = self.online_rep_model(source_data).cpu().detach()
        
        output = self.online_cls_model(source_rep)
        
        # # collect G & D for ATLAS
        # if len(source_rep.shape) > 1 and source_rep.size(0) > 1:
        #     _batch_size = source_rep.size(0)
        #     _radius_i, _radius_j = random.sample(list(range(_batch_size)), k=2)
        #     _input_radius = torch.norm(source_rep[_radius_i] - source_rep[_radius_j], p=2)
        #     _input_radius = _input_radius.item()
        #     self._max_input_radius = max(self._max_input_radius, _input_radius)
        
        info = self.criterion(output.float(), source_label)
        
        loss = info['estimate']
        loss.backward()
        
        # # collect G & D for ATLAS
        # _grad_flatten = torch.cat([param.grad.data.view(-1) for param in self.online_cls_model.parameters()])
        # _grad_norm = torch.norm(_grad_flatten, p=2)
        # _grad_norm = _grad_norm.item()
        # self._max_grad_norm = max(self._max_grad_norm, _grad_norm)
        
        if self.grad_clip:
            nn.utils.clip_grad_norm_(self.online_cls_model.parameters(), 1.0, norm_type=1.0)
        
        optimizer.step()
        
        return tensor2scalar(info['estimate']), tensor2scalar(info['underlying'])
    
    def opt_cls(self, target_data):
        '''
        Only optimize the last layer classifier with OGD.
        '''
        estimate_loss, underlying_loss = 0, 0
        
        # optimize cls_model with CPU
        _estimate_loss, _underlying_loss = self.opt_cls_one_batch(self.source_rep, self.source_label, target_data)
        
        if _estimate_loss is None:
            estimate_loss = None
        else:
            estimate_loss += _estimate_loss
        
        if _underlying_loss is None:
            underlying_loss = None
        else:
            underlying_loss += _underlying_loss
        
        if estimate_loss is not None:
            estimate_loss /= len(self.dataloader)
        if underlying_loss is not None:
            underlying_loss /= len(self.dataloader)
        
        # for batch_idx, (source_data, source_label) in enumerate(self.cache):
        #     source_data, source_label = source_data.to(self.device), source_label.to(self.device)
        #     _estimate_loss, _underlying_loss = self.opt_cls_one_batch(source_data, source_label, target_data)
        #
        #     if _estimate_loss is None:
        #         estimate_loss = None
        #     else:
        #         estimate_loss += _estimate_loss
        #
        #     if _underlying_loss is None:
        #         underlying_loss = None
        #     else:
        #         underlying_loss += _underlying_loss
        #
        # if estimate_loss is not None:
        #     estimate_loss /= len(self.dataloader)
        # if underlying_loss is not None:
        #     underlying_loss /= len(self.dataloader)
        
        if self.projection:
            self.online_cls_model.project()
        
        # For OLS setting: add the pseudo-label to rep_data_buffer
        pseudo_target_label = self.predict(target_data)
        
        if self.cfgs.online_cfgs.update_DNN_represent:

            _target_data_len = pseudo_target_label.size(0)
            for _target_data_idx in range(_target_data_len):
                _x = target_data[_target_data_idx].cpu().squeeze()
                _y = pseudo_target_label[_target_data_idx].cpu().item()
                self.rep_data_buffer.append((_x, _y))
                # _x: tensor of shape [3, 224, 224]
                # _y: tensor of shape [] (integer, not a tensor)

            # if len(self.rep_data_buffer[-1]) + len(target_data) > self.cfgs.online_cfgs.kwargs['rep_batch_size']:
            #     self.rep_data_buffer.append((target_data.cpu(), pseudo_target_label.cpu()))
            # else:
            #     self.rep_data_buffer[-1] = (torch.cat((self.rep_data_buffer[-1][0], target_data.cpu()), dim=0),
            #                                 torch.cat((self.rep_data_buffer[-1][1], pseudo_target_label.cpu()), dim=0))
        
        return estimate_loss, underlying_loss
    
    @torch.no_grad()
    def predict(self, data):
        self.online_cls_model.eval()
        self.online_cls_model = self.online_cls_model.cpu()
        if self.online_rep_model is not None:
            self.online_rep_model.eval()
            data = data.to(self.device)
            data = data.to(torch.float32)
            data = self.online_rep_model(data).detach()
        data = data.cpu().detach()
        output = self.online_cls_model(data)
        pred = output.argmax(-1)
        return pred
    
    def eval(self):
        
        estimate_loss, underlying_loss = 0, 0
        
        for batch_idx, (data, target) in enumerate(self.cache):
            data, target = data.to(self.device), target.to(self.device)
            if self.online_rep_model is not None:
                data = self.online_rep_model(data).detach()
            output = self.online_cls_model(data)
            info = self.criterion(output.float(), target)
            estimate_loss += info['estimate'].item()
            if info['underlying'] is None:
                underlying_loss = None
            else:
                underlying_loss += info['underlying'].item()
        
        estimate_loss /= len(self.dataloader)
        if underlying_loss is not None:
            underlying_loss /= len(self.dataloader)
        
        return estimate_loss, underlying_loss
    
    def alg_forward(self, target_data, prior_estimate, t):
        pred = self.predict(target_data)
        estimate_loss, underlying_loss = self.opt_cls(target_data)
        if self.cfgs.online_cfgs.update_DNN_represent and t % self.cfgs.online_cfgs.kwargs['rep_update_interval'] == 0:
            print('Update the representation layer.')
            self.opt_rep()
            
            if self.cfgs.online_cfgs.kwargs.get('rep_update_only_once', False):  # only update once
                self.cfgs.online_cfgs.update_DNN_represent = False
        
        return pred, estimate_loss, underlying_loss
