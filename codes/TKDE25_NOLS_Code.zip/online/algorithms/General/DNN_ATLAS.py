# /usr/bin/env python
# -*- coding: utf-8 -*-
import copy
from collections import OrderedDict

import torch
import torch.nn as nn
from torch.optim import *
import numpy as np
from prettytable import PrettyTable
from torch.utils.data import DataLoader
from tqdm import tqdm

from online.algorithms.General.DNN_base import DNN_base
from online.algorithms.General.meta import Hedge
from online.utils.lr import SelfTuningLr
from online.utils.schedule import DiscretizedSSP
from utils_pkg import exp_config
from utils_pkg.multi_thread import MultiThreadHelper
import abc

from utils_pkg.utils import collate_first2_args


class DNN_ATLAS(DNN_base, metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def __init__(self, cfgs: exp_config.Config, seed=None, ExpertClass=None, **alg_kwargs):
        super(DNN_ATLAS, self).__init__(cfgs=cfgs, seed=seed, **alg_kwargs)
        
        self.offline_cls_model = None
        self.ExpertClass = ExpertClass
        # No need to create cls_model in ATLAS, we only need to create multiple `expert`s: DNN_OGD, and a rep_model
        
        ssp = DiscretizedSSP(min_step=alg_kwargs['min_step'],
                             max_step=alg_kwargs['max_step'],
                             grid=2)
        print(ssp)
        self.ssp = ssp
        self.expert_setup(ssp, **alg_kwargs)  # pool of base learners
        
        self._meta = self.meta_setup(ssp, cfgs.online_cfgs.kwargs)
        
        self.combine = cfgs.online_cfgs.kwargs.get('combine', 'weight')
        self.loss_vector = torch.zeros(len(ssp))
        
        self._t = 0
        self.print = False
        self.source_rep, self.source_label = self.get_rep_of_data(self.alg_kwargs['dataset'])
        
        # added for atlas + ogd_rep
        # copy from online/algorithms/General/DNN_ogd.py
        if self.cfgs.online_cfgs.update_DNN_represent:
            self.rep_data_buffer = []
            self.dataloader = DataLoader(self.alg_kwargs['dataset'],
                                         num_workers=0,
                                         batch_size=self.cfgs.online_cfgs.kwargs['rep_batch_size'],
                                         shuffle=True,
                                         pin_memory=False,
                                         collate_fn=collate_first2_args)
            for batch_idx, (data, target) in enumerate(self.dataloader):
                # initialize the rep_data_buffer to be the (source data and source label)
                # data, target = data.to(self.device), target.to(self.device)
                self.rep_data_buffer.append((data, target))
    
    @torch.no_grad()
    def get_rep_of_data(self, dataset):
        dataloader = DataLoader(dataset,
                                num_workers=0,
                                batch_size=self.cfgs.online_cfgs.kwargs.get('rep_batch_size', 256),
                                shuffle=False,
                                pin_memory=False,
                                collate_fn=collate_first2_args)
        tot_rep = None
        tot_label = None
        for batch_idx, (data, label) in enumerate(tqdm(dataloader, desc='Updating rep_data of ATLAS')):
            if self.online_rep_model is not None:
                data = data.to(self.device)
                rep = self.online_rep_model(data).cpu()
            else:
                rep = data.cpu()
            label = label.cpu()
            if tot_rep is None:
                tot_rep = rep
                tot_label = label
            else:
                tot_rep = torch.cat((tot_rep, rep), dim=0)
                tot_label = torch.cat((tot_label, label), dim=0)
        return tot_rep, tot_label
    
    def expert_setup(self, ssp, **alg_kwargs):
        self.experts = []
        new_cfgs = copy.deepcopy(self.cfgs)
        new_cfgs.online_cfgs.kwargs['rep_batch_size'] = 200000
        new_cfgs.online_cfgs.kwargs['is_base_expert'] = True
        for i in range(len(ssp)):  # create multiple `expert`s: DNN_OGD
            new_alg_kwargs = copy.deepcopy(alg_kwargs)
            new_alg_kwargs['online_cls_model'] = copy.deepcopy(alg_kwargs['online_cls_model'])
            new_alg_kwargs['online_rep_model'] = None  # no representation model for base experts
            new_alg_kwargs['rep_init'] = None  # no representation model for base experts
            self.experts.append(self.ExpertClass(cfgs=new_cfgs, stepsize=ssp[i], **new_alg_kwargs))
        
        self.length = len(ssp)
        self.weight_shape = self.experts[0].online_cls_model.linear.weight.shape
        self.threads = self.cfgs.online_cfgs.kwargs.get('thread', 0)
    
    def meta_setup(self, ssp, cfgs):
        G = cfgs['G']
        D = cfgs['D']
        lr_scale = cfgs.get('lr_scale', 1.0)
        # lr = SelfTuningLr(scale=lr_scale / (G * D))
        lr = lr_scale * np.sqrt(np.log(len(ssp)) / self.cfgs.T)
        meta = Hedge(N=len(ssp), lr=lr, prior=cfgs.get("meta_init", 'uniform'))
        print('Meta init: ' + cfgs.get("meta_init", 'uniform'))
        # print('Meta LR: {}'.format(lr_scale / (G * D)))
        print('Meta LR: {}'.format(lr))
        
        return meta
    
    # added for atlas + ogd_rep
    # copy from online/algorithms/General/DNN_ogd.py
    def opt_rep(self, *args):
        '''
        Optimize the representation layer (except the last layer classifier) with OGD.
        '''
        # one online_rep_model for all experts, or one online_rep_model for each expert?
        
        self.online_rep_model.train()
        self.online_cls_model = self.online_cls_model.to(self.device)
        
        if self.cfgs.online_cfgs.kwargs.get('only_opt_rep', False):
            # optimizer only the rep_model
            text = 'only opt rep model'
            self.online_cls_model.eval()
            optimizer = SGD(self.online_rep_model.parameters(), lr=float(self.cfgs.online_cfgs.kwargs['rep_lr']))
        else:
            # optimizer both the rep_model and cls_model
            text = 'opt rep and cls models'
            self.online_cls_model.train()
            optimizer = SGD(list(self.online_rep_model.parameters()) + list(self.online_cls_model.parameters()),
                            lr=float(self.cfgs.online_cfgs.kwargs['rep_lr']))
        
        optimizer.zero_grad()
        
        loss = 0.0
        for epoch in range(self.cfgs.online_cfgs.kwargs['rep_optimize_epoch']):
            for data, label in tqdm(self.rep_data_buffer, desc='Optimize {}, loss={}'.format(text, loss), leave=True):
                label = label.to(self.device)
                data = data.to(self.device)
                data = self.online_rep_model(data)
                output = self.online_cls_model(data)
                # use logistic loss to optimize the online_rep_model
                loss = nn.CrossEntropyLoss()(output, label)
                loss.backward()
                optimizer.step()
        
        # get self.source_rep using the rep_model
        self.source_rep, self.source_label = self.get_rep_of_data(self.alg_kwargs['dataset'])
    
    @torch.no_grad()
    def predict(self, data):
        self.online_cls_model = self.online_cls_model.cpu()
        prob = self._meta.get_prob()
        if self.combine == 'weight':
            if self.online_rep_model is not None:
                data = self.online_rep_model(data).detach()
            data = data.cpu()
            output = self.online_cls_model(data)
            pred = output.argmax(-1)
        elif self.combine == "output":
            soft_out = []
            data = data.to(self.device).to(torch.float32)
            
            for model in self.experts:
                if self.online_rep_model is not None:
                    data = self.online_rep_model(data).detach()
                output = model.online_cls_model(data)
                soft_out.append(output.softmax(-1))
            soft_out = torch.stack(soft_out, dim=0)
            num_bases = len(self.ssp)
            combine_out = torch.mm(prob.view(1, num_bases), soft_out.view(num_bases, -1))
            combine_out = combine_out.reshape(soft_out.shape[1:])
            pred = combine_out.argmax(-1)
        
        else:
            return NotImplementedError
        self.pretty_print(prob, 'Weight')
        return pred
    
    def set_criterion(self, func):
        super().set_criterion(func)
        for expert in self.experts:
            expert.set_criterion(func)
    
    def get_meta_lr(self):
        return self._meta.lr
    
    def get_meta_prob(self):
        return self._meta.get_prob()
    
    def opt_cls(self, target_data):
        self._t += 1
        
        # optimization
        self._meta.update_lr()
        self._meta.opt(self.loss_vector)  # Meta
        
        loss_vector = torch.zeros(len(self.ssp))  # Base
        # for batch_idx, (data, target) in enumerate(self.cache):
        loss_vector += self.opt_experts_one_batch(self.source_rep, self.source_label, target_data)
        
        self.loss_vector = loss_vector / len(self.dataloader)
    
    def opt_experts_one_batch(self, source_rep, target, target_data):
        loss_vector = torch.zeros(self.length)
        
        def expert_opt(idx, expert, data, target):
            # if self.online_rep_model is not None:
            #     data = self.online_rep_model(data).detach()
            estimate_loss, underlying_loss = expert.opt_cls_one_batch(data, target, target_data)
            if expert.projection:
                expert.online_cls_model.project()
            
            return idx, estimate_loss
        
        commands = [(expert_opt, idx, expert, source_rep, target) for idx, expert in enumerate(self.experts)]
        loss_result = MultiThreadHelper(commands, self.threads, multi_process=False)()
        
        for idx, loss in loss_result:
            if loss is not None:
                loss_vector[idx] = loss
        
        # project and load to aux
        for expert in self.experts:
            if expert.projection:
                expert.online_cls_model.project()
        
        return loss_vector
    
    @torch.no_grad()
    def eval(self):
        estimate_loss, underlying_loss = 0, 0
        
        # for batch_idx, (data, target) in enumerate(self.cache):
        
        output = self.online_cls_model(self.source_rep)
        info = self.criterion(output.float(), self.source_label)
        estimate_loss += info['estimate'].item()
        if info['underlying'] is None:
            underlying_loss = None
        else:
            underlying_loss += info['underlying'].item()
        
        estimate_loss /= len(self.dataloader)
        if underlying_loss is not None:
            underlying_loss /= len(self.dataloader)
        
        return estimate_loss, underlying_loss
    
    def load_model(self):
        def weight_combine(x_bases, prob):
            prob = prob.to(x_bases.device)
            
            x_shape = x_bases.shape
            num_bases = x_shape[0]
            
            x_combined = torch.mm(prob.view(1, num_bases), x_bases.view(num_bases, -1))
            x_combined = x_combined.reshape(x_shape[1:])
            
            return x_combined
        
        prob = self._meta.get_prob()
        
        weights = []
        for i in range(len(self.ssp)):
            weights.append(self.experts[i].online_cls_model.state_dict())
        
        combine_weights = OrderedDict()
        names = weights[0].keys()
        for name in names:
            bases = [base[name] for base in weights]
            combine_weights[name] = weight_combine(torch.stack(bases), prob)
        
        self.online_cls_model.load_state_dict(combine_weights)
    
    def alg_forward(self, target_data, prior_estimate, t):
        
        # evaluate
        self.load_model()
        pred = self.predict(target_data)
        estimate_loss, underlying_loss = self.eval()
        
        # update
        self.opt_cls(target_data)
        
        # added for atlas + ogd_rep
        # copy from online/algorithms/General/DNN_ogd.py
        if self.cfgs.online_cfgs.update_DNN_represent and t % self.cfgs.online_cfgs.kwargs['rep_update_interval'] == 0:
            print('Update the representation layer.')
            self.opt_rep()
        
        return pred, estimate_loss, underlying_loss
    
    def pretty_print(self, values, name):
        if self.print:
            table = PrettyTable()
            steps = ['{:.8f}'.format(step) for step in self.ssp._step_pool[:len(values)]]
            table.field_names = ['Lr'] + steps
            values = values.cpu().detach().numpy()
            values = ['{:.2f}'.format(v) for v in values]
            
            table.add_row(['Val'] + values)
            print('>>>{}'.format(name))
            print(table)
