# /usr/bin/env python
# -*- coding: utf-8 -*-
import copy

import numpy as np
import torch

from utils_pkg.StreamingWaveletPkg.StreamingWavelet import StreamingWaveletCDJV
from online.algorithms.General.DNN_base import DNN_base
from utils_pkg.exp_config import Config
import abc


def soft_threshold(x, threshold):
    return max(0, x - threshold)


class WaveletRestartModule():
    def __init__(self, dim, max_length, order, get_coeff=False, cfgs=None):
        # self.wavelet = StreamingWavelet(dim=dim, max_length=max_length, order=order, get_coeff=get_coeff)
        self.wavelet = StreamingWaveletCDJV(dim=dim, max_length=max_length, order=order, get_coeff=get_coeff)
        self.cfgs = cfgs
    
    def update(self, signal):
        self.wavelet.add_signal(signal)
    
    def is_restart_now(self, threshold):
        if soft_threshold(self.wavelet.get_norm(), threshold / self.cfgs.online_cfgs.kwargs['wav_thresh_rate']) >= threshold:
            # if self.wavelet.get_norm() >= threshold:
            self.wavelet.reinit()
            return True
        else:
            return False


class DNN_WaveletRestart(DNN_base, metaclass=abc.ABCMeta):
    
    @abc.abstractmethod
    def __init__(self, cfgs: Config, online_cfgs_kwargs=None, seed=None, ExpertClass=None, **alg_kwargs):
        super(DNN_WaveletRestart, self).__init__(cfgs=cfgs, seed=seed, **alg_kwargs)
        if online_cfgs_kwargs is None:
            online_cfgs_kwargs = {}
        self.cfgs = cfgs
        
        self.T = cfgs.T
        self.order = online_cfgs_kwargs['order']
        
        self.dim = alg_kwargs['cls_num']
        self.projection = online_cfgs_kwargs['projection']
        
        N = int(np.ceil(np.log2(self.T))) + 1
        self.sigma_min = online_cfgs_kwargs['sigma_min']
        online_cfgs_kwargs['N'] = N
        alg_kwargs['dim'] = self.dim
        self.alg_kwargs = alg_kwargs
        
        self.combine = online_cfgs_kwargs.get('combine', 'weight')
        
        print('ALL KWARGS:', self.alg_kwargs, self.cfgs)
        
        self.online_cls_model = None
        self.online_rep_model = None
        self.offline_cls_model = None
        self.offline_rep_model = None
        # No need to create model in WavRestart Alg, we only need to create an `expert`: DNN_OGD
        
        self.expert = ExpertClass(cfgs=cfgs, seed=seed, **alg_kwargs)
        self.init_expert_model = copy.deepcopy(self.expert.online_cls_model)
        
        self.restart_schedule = self.restart_schedule_setup()
        
        self.loss_vector = torch.zeros(1)
        
        self._t = 0
        self._interval_len = 0
        self.data_buffer = []
    
    def set_criterion(self, func):
        self.expert.set_criterion(func)
    
    def restart(self):
        
        self._interval_len = 0
        # self.learner_for_mu = self.learner_for_mu_setup()
        self.expert.online_cls_model = copy.deepcopy(self.init_expert_model)
        
        self.data_buffer = []
    
    def restart_schedule_setup(self):
        RestartModule = WaveletRestartModule(dim=self.dim, max_length=self.T, order=self.order, get_coeff=False, cfgs=self.cfgs)
        return RestartModule
    
    def opt_rep(self):
        '''
        Optimize the representation layer (except the last layer classifier) with OGD.
        '''
        self.expert.opt_rep()
    
    def opt_cls(self, prior_estimate, target_data):
        '''
        Only optimize the last layer classifier with OGD.
        '''
        
        # self.expert.lr = self.alg_kwargs['lr_init'] / (np.sqrt(self._interval_len)) / 2.0 + self.alg_kwargs['lr_init'] / 2.0
        # self.expert.lr = self.alg_kwargs['lr_init'] * 2.0
        
        estimate_loss, underlying_loss = self.expert.opt_cls(target_data)
        
        return estimate_loss, underlying_loss
    
    @torch.no_grad()
    def predict(self, data):
        pred = self.expert.predict(data)
        return pred
    
    def alg_forward(self, target_data, prior_estimate, t):
        pred = self.expert.predict(target_data)
        # estimate_loss, underlying_loss = self.expert.eval()
        
        # update the internal expert (DNN_OGD):
        estimate_loss, underlying_loss = self.opt_cls(prior_estimate, target_data)
        
        self.restart_schedule.update(prior_estimate.cpu().detach().numpy().reshape(-1))
        # Restart Condition: F-norm of wavelet efficients exceeds threshold
        if self.restart_schedule.is_restart_now(threshold=1 / self.sigma_min * self.order):
            self.restart()
            print('Restart at t = {}'.format(t))
            
            # TODO: use data in the buffer to update the model
            if self.cfgs.online_cfgs.update_DNN_represent:
                print('Update the model_rep_model')
                self.opt_rep()
        
        return pred, estimate_loss, underlying_loss
