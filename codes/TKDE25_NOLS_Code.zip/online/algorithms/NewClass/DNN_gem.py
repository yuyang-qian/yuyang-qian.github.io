from online.algorithms.General.DNN_gem import DNN_GEM as DNN_GEM_abc
from utils_pkg import exp_config


class DNN_GEM(DNN_GEM_abc):
    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **algo_kwargs):
        super(DNN_GEM, self).__init__(cfgs=cfgs, stepsize=stepsize, **algo_kwargs)
    
    def alg_forward(self, target_images, prior_estimate, PvU_datasetm, t):
        pred = self.predict(target_images)  # see DNN_base.predict at online/algorithms/General/DNN_base.py
        
        # copy from online/algorithms/General/DNN_ogd.py
        estimate_loss, underlying_loss, pseudo_labels = self.opt_cls(target_images)
        
        # copy from online/algorithms/General/DNN_ogd.py
        if self.cfgs.online_cfgs.update_DNN_represent and t % self.cfgs.online_cfgs.kwargs["rep_update_interval"] == 0:
            print("\033[93m[DNN_GEM]\033[0m", f"opt_rep at t={t}")
            self.opt_rep(target_images, pseudo_labels)
            if self.cfgs.online_cfgs.kwargs.get("rep_update_only_once", False):
                self.cfgs.online_cfgs.update_DNN_represent = False
        
        # copy from online/algorithms/General/DNN_ogd.py
        return pred, estimate_loss, underlying_loss
