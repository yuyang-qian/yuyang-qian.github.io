# /usr/bin/env python
# -*- coding: utf-8 -*-

import torch
import torch.nn as nn
from torch.optim import *
from torch.utils.data import DataLoader
from tqdm import tqdm

from online.algorithms.General.DNN_ogd import DNN_OGD as DNN_OGD_abc
from utils_pkg import exp_config
from utils_pkg.tools import Timer
from utils_pkg.tools import tensor2scalar

__all__ = ["DNN_OGD"]


class DNN_OGD(DNN_OGD_abc):
    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **algo_kwargs):
        super(DNN_OGD, self).__init__(cfgs=cfgs, stepsize=stepsize, **algo_kwargs)
    
    def opt_cls_one_batch(self, source_rep, source_label, target_data, new_class_prior=None, known_class=None, new_class=None):
        self.online_cls_model = self.online_cls_model.cpu()
        self.online_cls_model.train()
        timer = Timer()
        optimizer = SGD(self.online_cls_model.parameters(), lr=self.lr)
        optimizer.zero_grad()
        
        # if self.online_rep_model is not None:
        #     self.online_rep_model.eval()
        #     source_data = self.online_rep_model(source_data).cpu().detach()
        
        output = self.online_cls_model(source_rep)
        
        if self.criterion.name == 'RewritingRisk_HANOL':
            if self.online_rep_model is not None:
                target_data = self.online_rep_model(target_data).detach()
            target_output = self.online_cls_model(target_data.cpu())
            info = self.criterion(output.float(), source_label, target_output, target_data, new_class_prior, known_class, new_class)
        else:
            info = self.criterion(output.float(), source_label)
        
        # info = self.criterion(output.float(), source_label)
        
        loss = info['estimate']
        loss.backward()
        
        if self.grad_clip:
            nn.utils.clip_grad_norm_(self.online_cls_model.parameters(), 1.0, norm_type=1.0)
        
        optimizer.step()
        
        return tensor2scalar(info['estimate']), tensor2scalar(info['underlying'])
    
    @torch.no_grad()
    def predict(self, data):
        self.online_cls_model.eval()
        self.online_cls_model = self.online_cls_model.cpu()
        if self.online_rep_model is not None:
            self.online_rep_model.eval()
            data = data.to(self.device)
            data = data.to(torch.float32)
            data = self.online_rep_model(data).detach()
        data = data.cpu().detach()
        output = self.online_cls_model(data)
        pred = output.argmax(-1)
        return pred
    
    def alg_forward(self, target_data, prior_estimate, PvU_dataset, t):
        pred = self.predict(target_data)
        estimate_loss, underlying_loss = self.opt_cls(target_data)
        if self.cfgs.online_cfgs.update_DNN_represent and t % self.cfgs.online_cfgs.kwargs['rep_update_interval'] == 0:
            print('Update the representation layer.')
            self.opt_rep()
        
        return pred, estimate_loss, underlying_loss
