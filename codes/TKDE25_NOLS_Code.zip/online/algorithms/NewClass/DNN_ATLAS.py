# /usr/bin/env python
# -*- coding: utf-8 -*-

from online.algorithms.General.DNN_ATLAS import DNN_ATLAS as DNN_ATLAS_abc
from online.algorithms.NewClass.DNN_ogd import DNN_OGD
from utils_pkg import exp_config


class DNN_ATLAS(DNN_ATLAS_abc):
    def __init__(self, cfgs: exp_config.Config, seed=None, ExpertClass=DNN_OGD, **alg_kwargs):
        super(DNN_ATLAS, self).__init__(cfgs=cfgs, seed=seed, ExpertClass=ExpertClass, **alg_kwargs)
    
    def alg_forward(self, target_data, prior_estimate, PvU_dataset, t):
        # evaluate
        self.load_model()
        pred = self.predict(target_data)
        estimate_loss, underlying_loss = self.eval()
        
        # update
        self.opt_cls(target_data)
        
        return pred, estimate_loss, underlying_loss
