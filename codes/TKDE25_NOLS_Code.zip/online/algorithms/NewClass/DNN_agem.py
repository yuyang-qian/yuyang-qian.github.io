from online.algorithms.General.DNN_agem import DNN_AGEM as DNN_AGEM_abc
from utils_pkg import exp_config


class DNN_AGEM(DNN_AGEM_abc):
    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **algo_kwargs):
        super(DNN_AGEM, self).__init__(cfgs=cfgs, stepsize=stepsize, **algo_kwargs)
    
    def alg_forward(self, target_data, prior_estimate, pvu_dataset, t):
        pred = self.predict(target_data)
        estimate_loss, underlying_loss = self.opt_cls(target_data)
        if self.cfgs.online_cfgs.update_DNN_represent and t % self.cfgs.online_cfgs.kwargs['rep_update_interval'] == 0:
            print('Update the representation layer.')
            self.opt_rep()
            
            if self.cfgs.online_cfgs.kwargs.get('rep_update_only_once', False):  # only update once
                self.cfgs.online_cfgs.update_DNN_represent = False
        
        return pred, estimate_loss, underlying_loss
