# /usr/bin/env python
# -*- coding: utf-8 -*-

import torch

from online.utils.lr import SelfTuningLr, OptSelfTuningLr


class Hedge(object):
    def __init__(self, N, lr, prior, use_optimism=False):
        self._N = N
        self._lr = lr
        self.prob = self.set_prior(prior)
        self.use_optimism = use_optimism
        self.t = 0
        if use_optimism:
            self.aux_prob = self.set_prior(prior)

    def set_prior(self, prior):
        if prior == 'uniform':
            prob = [1 / self._N for i in range(self._N)]
        elif prior == 'nonuniform':
            prob = [(self._N + 1) / (self._N * i * (i + 1)) for i in range(1, self._N + 1)]
        else:
            prob = prior

        return torch.tensor(prob)

    @torch.no_grad()
    def opt(self, loss):

        exp_loss = torch.exp(-self.lr * loss)
        ori_prob = self.prob.detach().clone()
        self.prob *= exp_loss
        self.prob /= self.prob.sum()
        if torch.any(torch.isnan(self.prob)):
            self.prob = ori_prob

    @torch.no_grad()
    def optimism_opt(self, opt):

        exp_loss = torch.exp(-self.lr * opt)
        self.aux_prob = self.prob * exp_loss
        self.aux_prob /= self.aux_prob.sum()

        if torch.any(torch.isnan(self.aux_prob)):
            self.aux_prob = self.prob

    def get_prob(self):
        if self.use_optimism:
            return self.aux_prob
        else:
            return self.prob

    def update_lr(self, **kwargs):
        lr = self._lr
        if isinstance(lr, SelfTuningLr) or \
                isinstance(lr, OptSelfTuningLr):
            lr = lr.compute_lr(**kwargs)

        self.lr = lr
    
    def check_cut_off(self):
        excld_idx = []
        for i in range(len(self.prob)):
            if self.prob[i] < 0.005:
                # 0.005
                excld_idx.append(i)
        # self._N -= len(tmp)
        excld_idx.sort(reverse=True)
        prob = self.prob.tolist()
        for idx in excld_idx:
            prob.pop(idx)
        self.prob = torch.tensor(prob)
        self.prob /= self.prob.sum()
        return excld_idx
    
    def check_add_new(self):
        prob = self.prob.tolist()
        add_min, add_max = False, False
        # new_min, new_max = None, None
        if prob[0] > 0.3:
            # tmp_min = self.ssp[0]
            # new_min = tmp_min / 2
            add_min = True
            # add new expert
            prob.insert(0, 0.125)
            self.prob = torch.tensor(prob)
            self.prob /= self.prob.sum()
        
        if prob[-1] > 0.3:
            # tmp_max = self.ssp[-1]
            # new_max = tmp_max * 2
            add_max = True
            # add new expert
            prob.append(0.125)
            self.prob = torch.tensor(prob)
            self.prob /= self.prob.sum()
        return add_min, add_max
    
    def set_mask(self, target_mask):
        self.mask = target_mask
    
    def get_mask(self):
        return self.mask
    
    def receive_excld(self, excld_idx):
        prob = self.prob.tolist()
        for idx in excld_idx:
            prob.pop(idx)
        self.prob = torch.tensor(prob)
        self.prob /= self.prob.sum()
    
    def receive_idx_prob(self, idx, idx_prob):
        prob = self.prob.tolist()
        prob.insert(idx, idx_prob)
        self.prob = torch.tensor(prob)
        self.prob /= self.prob.sum()
