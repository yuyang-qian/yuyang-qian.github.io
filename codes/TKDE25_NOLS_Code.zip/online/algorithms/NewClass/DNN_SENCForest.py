# /usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
import torch
from torch import nn
from torch.optim import *
from torch.utils.data import DataLoader
from tqdm import tqdm

from models_pkg.SENCForest_model import SENCForest_model
from online.algorithms.NewClass.DNN_base import DNN_base
from online.algorithms.NewClass.DNN_ogd import DNN_OGD
from utils_pkg import exp_config
from utils_pkg.tools import tensor2scalar


class DNN_SENCForest(DNN_base):
    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **alg_kwargs):
        super(DNN_SENCForest, self).__init__(cfgs=cfgs, **alg_kwargs)
        self.lr = stepsize
        self.grad_clip = self.cfgs.online_cfgs.grad_clip
        self.projection = self.cfgs.online_cfgs.kwargs.get('projection', False)
        
        self.offline_cls_model = None
        self.online_kwargs = self.cfgs.online_cfgs.kwargs
        
        if self.cfgs.online_cfgs.update_DNN_represent:
            self.rep_data_buffer = []
            self.dataloader = DataLoader(self.alg_kwargs['dataset'],
                                         num_workers=0,
                                         batch_size=self.cfgs.online_cfgs.kwargs['rep_batch_size'],
                                         shuffle=True,
                                         pin_memory=False)
            for batch_idx, (data, target, _) in enumerate(self.dataloader):
                # initialize the rep_data_buffer to be the (source data and source label)
                # data, target = data.to(self.device), target.to(self.device)
                self.rep_data_buffer.append((data, target))
        
        self._t = 0
        self.print = False
        
        self.source_rep, self.source_label = self.get_rep_of_data(self.alg_kwargs['dataset'])
        
        # check type of online_cls_model
        if not isinstance(self.online_cls_model, SENCForest_model):
            raise ValueError('online_cls_model should be SENCForest_model')
        
        # new class detector (nc_detector) using SENCForest_model
        # self.nc_detector = SENCForest_model(self.cfgs)
        self.expert_setup(**alg_kwargs)
        
        self.new_class_list = self.cfgs.data_cfgs.kwargs['online_data']['newclass_cfg']['new_class']
        self.new_class_pointer = 0
        # self.online_mpe_estimator = online_mpe_estimate()
    
    @torch.no_grad()
    def get_rep_of_data(self, dataset):
        dataloader = DataLoader(
            dataset,
            num_workers=0,
            batch_size=self.cfgs.online_cfgs.kwargs.get('rep_batch_size', 256),
            shuffle=False,
            pin_memory=False
        )
        tot_rep = None
        tot_label = None
        for batch_idx, (data, label, _) in enumerate(tqdm(dataloader, desc='Updating rep_data of SENCForest')):
            if self.online_rep_model is not None:
                data = data.to(self.device)
                rep = self.online_rep_model(data).cpu()
            else:
                rep = data.cpu()
            label = label.cpu()
            if tot_rep is None:
                tot_rep = rep
                tot_label = label
            else:
                tot_rep = torch.cat((tot_rep, rep), dim=0)
                tot_label = torch.cat((tot_label, label), dim=0)
        return tot_rep, tot_label
    
    def expert_setup(self, **alg_kwargs):
        # self.nc_detector = SENCForest_model(self.cfgs)
        self.online_cls_model.init_forest(self.source_rep, self.source_label)
    
    def opt_rep(self, *args):
        '''
        Optimize the representation layer (except the last layer classifier) with OGD.
        '''
        #     use data and label in rep_data_buffer to optimize the rep_model
        self.online_rep_model.train()
        self.online_cls_model = self.online_cls_model.to(self.device)
        
        if self.cfgs.online_cfgs.kwargs.get('only_opt_rep', False):
            # optimizer only the rep_model
            text = 'only opt rep model'
            self.online_cls_model.eval()
            optimizer = SGD(self.online_rep_model.parameters(), lr=float(self.cfgs.online_cfgs.kwargs['rep_lr']))
        else:
            # optimizer both the rep_model and cls_model
            text = 'opt rep and cls models'
            self.online_cls_model.train()
            optimizer = SGD(list(self.online_rep_model.parameters()) + list(self.online_cls_model.parameters()),
                            lr=float(self.cfgs.online_cfgs.kwargs['rep_lr']))
        
        optimizer.zero_grad()
        
        loss = 0.0
        for epoch in range(self.cfgs.online_cfgs.kwargs['rep_optimize_epoch']):
            for data, label in tqdm(self.rep_data_buffer, desc='Optimize {}, loss={}'.format(text, loss), leave=True):
                label = label.to(self.device)
                data = data.to(self.device)
                data = self.online_rep_model(data)
                output = self.online_cls_model(data)
                # use logistic loss to optimize the online_rep_model
                loss = nn.CrossEntropyLoss()(output, label)
                loss.backward()
                optimizer.step()
        
        # get self.source_rep using the rep_model
        self.source_rep, self.source_label = self.get_rep_of_data(self.alg_kwargs['dataset'])
    
    @torch.no_grad()
    def predict(self, data):
        # self.online_cls_model.eval()
        self.online_cls_model = self.online_cls_model.cpu()
        if self.online_rep_model is not None:
            self.online_rep_model.eval()
            data = data.to(self.device)
            data = data.to(torch.float32)
            data = self.online_rep_model(data).detach()
        data = data.cpu().detach()
        pred, is_new_class = self.online_cls_model(data, newclasslabel=self.new_class_list[self.new_class_pointer])
        pred = torch.tensor(pred)
        # pred = output.argmax(-1)
        return pred
    
    def set_criterion(self, func):
        super().set_criterion(func)
    
    def opt_cls(self, target_data, PvU_dataset):
        '''
        Only optimize the last layer classifier with OGD.
        '''
        estimate_loss, underlying_loss = 0, 0
        
        # optimize cls_model with CPU
        # _estimate_loss, _underlying_loss = self.opt_cls_one_batch(self.source_rep, self.source_label, target_data)
        #
        # if _estimate_loss is None:
        #     estimate_loss = None
        # else:
        #     estimate_loss += _estimate_loss
        #
        # if _underlying_loss is None:
        #     underlying_loss = None
        # else:
        #     underlying_loss += _underlying_loss
        #
        # if estimate_loss is not None:
        #     estimate_loss /= len(self.dataloader)
        # if underlying_loss is not None:
        #     underlying_loss /= len(self.dataloader)
        #
        # # For OLS setting: add the pseudo-label to rep_data_buffer
        # pseudo_target_label = self.predict(target_data)
        #
        # if self.cfgs.online_cfgs.update_DNN_represent:
        #     if len(self.rep_data_buffer[-1]) + len(target_data) > self.cfgs.online_cfgs.kwargs['rep_batch_size']:
        #         self.rep_data_buffer.append((target_data.cpu(), pseudo_target_label.cpu()))
        #     else:
        #         self.rep_data_buffer[-1] = (torch.cat((self.rep_data_buffer[-1][0], target_data.cpu()), dim=0),
        #                                     torch.cat((self.rep_data_buffer[-1][1], pseudo_target_label.cpu()), dim=0))
        
        return estimate_loss, underlying_loss
    
    @torch.no_grad()
    def eval(self):
        estimate_loss, underlying_loss = 0, 0
        
        # # for batch_idx, (data, target) in enumerate(self.cache):
        #
        # output = self.online_cls_model(self.source_rep)
        # info = self.criterion(output.float(), self.source_label)
        # estimate_loss += info['estimate'].item()
        # if info['underlying'] is None:
        #     underlying_loss = None
        # else:
        #     underlying_loss += info['underlying'].item()
        #
        # estimate_loss /= len(self.dataloader)
        # if underlying_loss is not None:
        #     underlying_loss /= len(self.dataloader)
        
        return estimate_loss, underlying_loss
    
    def alg_forward(self, target_data, prior_estimate, PvU_dataset, t):
        
        pred = self.predict(target_data)
        estimate_loss, underlying_loss = self.opt_cls(target_data, PvU_dataset)
        if self.cfgs.online_cfgs.update_DNN_represent and t % self.cfgs.online_cfgs.kwargs['rep_update_interval'] == 0:
            print('Update the representation layer.')
            self.opt_rep()
        
        return pred, estimate_loss, underlying_loss
