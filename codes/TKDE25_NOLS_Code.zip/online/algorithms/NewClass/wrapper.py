# /usr/bin/env python
# -*- coding: utf-8 -*-
from online.algorithms.NewClass.DNN_ATLAS import DNN_ATLAS
from online.algorithms.NewClass.DNN_FIX import DNN_FIX
from online.algorithms.NewClass.DNN_HANOL import DNN_HANOL
from online.algorithms.NewClass.DNN_HANOL_with_Detector import DNN_HANOL_with_Detector
from online.algorithms.NewClass.DNN_SENCForest import DNN_SENCForest
from online.algorithms.NewClass.DNN_agem import DNN_AGEM
from online.algorithms.NewClass.DNN_gem import DNN_GEM
from online.algorithms.NewClass.DNN_ogd import DNN_OGD
from online.utils.risk import RewritingRisk, RewritingRisk_HANOL
from utils_pkg import exp_config


def get_online_alg(cfgs: exp_config.Config, online_cfgs, min_step, max_step, models_dict, train_set, device, rng, info):
    # this method is for getting the model
    optimism = None
    if 'optimism' in online_cfgs.kwargs:
        loss_func = RewritingRisk(device=device,
                                  nn_loss=online_cfgs.kwargs.get('nn_loss', False))
        kwargs = online_cfgs.kwargs['optimism'].get('kwargs', {})
        kwargs['rng'] = rng
        optimism = eval(online_cfgs.kwargs['optimism']['type'])(loss_func=loss_func,
                                                                dim=info['dim'],
                                                                cls_num=info['cls_num'],
                                                                **kwargs)
    # get models from models_dict
    offline_cls_model = models_dict['offline_cls_model']
    online_cls_model = models_dict['online_cls_model']
    online_rep_model = models_dict['online_rep_model']
    offline_rep_model = models_dict['offline_rep_model']
    cls_init = models_dict['cls_init']
    rep_init = models_dict['rep_init']
    
    alg_kwargs = {
        'offline_rep_model': offline_rep_model,
        'offline_cls_model': offline_cls_model,  # offline-trained model
        'online_rep_model' : online_rep_model,  # representation model to extract the feature before the `online_cls_model`
        'online_cls_model' : online_cls_model,  # `online_cls_model` is for final classification
        'dataset'          : train_set,
        'device'           : device,
        'batch_size'       : cfgs.offline_cfgs.source_batch_size,
        'cls_init'         : cls_init,  # init model for `online_cls_model`
        'rep_init'         : rep_init,  # init model for `online_rep_model`
    }
    if online_cfgs.algorithm == 'DNN_OGD':
        alg_kwargs.update({
            'stepsize'  : online_cfgs.kwargs.get("lr", min_step),
            'projection': online_cfgs.kwargs.get('projection', False),
        })
        online_alg = DNN_OGD(cfgs=cfgs, **alg_kwargs)
    elif online_cfgs.algorithm == 'DNN_GEM':
        alg_kwargs.update({
            'stepsize'  : online_cfgs.kwargs.get("lr", min_step),
            'projection': online_cfgs.kwargs.get('projection', False),
        })
        online_alg = DNN_GEM(cfgs=cfgs, **alg_kwargs)
    elif online_cfgs.algorithm == 'DNN_AGEM':
        alg_kwargs.update({
            'stepsize'  : online_cfgs.kwargs.get("lr", min_step),
            'projection': online_cfgs.kwargs.get('projection', False),
        })
        online_alg = DNN_AGEM(cfgs=cfgs, **alg_kwargs)
    elif online_cfgs.algorithm == 'DNN_FIX':
        alg_kwargs.update({
            'stepsize'  : online_cfgs.kwargs.get("lr", min_step),
            'projection': online_cfgs.kwargs.get('projection', False),
        })
        online_alg = DNN_FIX(cfgs=cfgs, **alg_kwargs)
    elif online_cfgs.algorithm == 'DNN_HANOL':
        alg_kwargs.update({
            'min_step'     : min_step,
            'max_step'     : max_step,
            'projection'   : online_cfgs.kwargs.get('projection', False),
            'optimism'     : optimism,
            'opt_lr'       : online_cfgs.kwargs.get("opt_lr", 1),
            'opt_epoch'    : online_cfgs.kwargs.get("opt_epoch", 7),
            'opt_optimizer': online_cfgs.kwargs.get("opt_optimizer", 'LBFGS'),
        })
        
        online_alg = DNN_HANOL(cfgs=cfgs, seed=cfgs.seed, **alg_kwargs)
    elif online_cfgs.algorithm == 'DNN_HANOL_with_Detector':
        alg_kwargs.update({
            'min_step'     : min_step,
            'max_step'     : max_step,
            'projection'   : online_cfgs.kwargs.get('projection', False),
            'optimism'     : optimism,
            'opt_lr'       : online_cfgs.kwargs.get("opt_lr", 1),
            'opt_epoch'    : online_cfgs.kwargs.get("opt_epoch", 7),
            'opt_optimizer': online_cfgs.kwargs.get("opt_optimizer", 'LBFGS'),
        })
        
        online_alg = DNN_HANOL_with_Detector(cfgs=cfgs, seed=cfgs.seed, **alg_kwargs)
    elif online_cfgs.algorithm == 'DNN_ATLAS':
        alg_kwargs.update({
            'min_step'  : min_step,
            'max_step'  : max_step,
            'projection': online_cfgs.kwargs.get('projection', False),
        })
        online_alg = DNN_ATLAS(cfgs=cfgs, seed=cfgs.seed, **alg_kwargs)
    elif online_cfgs.algorithm == 'DNN_SENCForest':
        alg_kwargs.update({
            'stepsize'  : online_cfgs.kwargs.get("lr", min_step),
            'projection': online_cfgs.kwargs.get('projection', False),
        })
        online_alg = DNN_SENCForest(cfgs=cfgs, **alg_kwargs)
    else:
        raise NotImplementedError
    
    return online_alg
