# /usr/bin/env python
# -*- coding: utf-8 -*-

from online.algorithms.General.DNN_base import DNN_base as DNN_base_abc
from utils_pkg import exp_config


class DNN_base(DNN_base_abc):
    # DNN-based OGD updated online algorithm (model),
    # where representation and classifier are optimized separately
    def __init__(self, cfgs: exp_config.Config, **alg_kwargs):
        super(DNN_base, self).__init__(cfgs, **alg_kwargs)
    
    def alg_forward(self, target_feature, prior_estimate, test_dataset, t):
        pred = self.predict(target_feature)
        # estimate_loss, underlying_loss = self.opt(target_feature)
        
        return pred
