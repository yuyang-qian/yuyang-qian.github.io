# /usr/bin/env python
# -*- coding: utf-8 -*-

import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from online.algorithms.General.DNN_FIX import DNN_FIX as DNN_FIX_abc
from online.algorithms.NewClass.DNN_base import DNN_base
from utils_pkg import exp_config

__all__ = ["DNN_FIX"]


class DNN_FIX(DNN_FIX_abc):
    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **algo_kwargs):
        super(DNN_FIX, self).__init__(cfgs=cfgs, **algo_kwargs)
    
    def alg_forward(self, target_data, prior_estimate, PvU_dataset, t):
        pred = self.predict(target_data)
        estimate_loss, underlying_loss = self.eval()
        
        return pred, estimate_loss, underlying_loss
