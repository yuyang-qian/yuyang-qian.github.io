import logging
import os

os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
os.environ['CUDA_VISIBLE_DEVICES'] = '7'
from os.path import join
import json as js

import torch
import torch.nn as nn

from data.wrapper import get_data_loader

from utils_pkg.mpe_argparser import argparser
from utils_pkg.utils import Timer, OnCheckpointHparams, MetricsTracker, get_optimizer
from utils_pkg.MPE.mpe import mpe_estimate, online_mpe_estimate
from model import ResModel, BertModel
from loss.eulac_loss import URELoss

try:
    import lightning as L

except:
    import pytorch_lightning as L

import torchmetrics


# --------------------------------
# Step 1: Define a LightningModule
# --------------------------------
# A LightningModule (nn.Module subclass) defines a full *system*


class LightningModel(L.LightningModule):
    def __init__(self, model, loss_func, cfg):
        super().__init__()
        self.model = model
        self.loss_func = loss_func
        self.cfg = cfg
        self.train_acc = torchmetrics.Accuracy(task="multiclass",
                                               num_classes=self.cfg['model']['kwargs']['num_classes'])
        self.val_acc = torchmetrics.Accuracy(task="multiclass",
                                             num_classes=self.cfg['model']['kwargs']['num_classes'])
    
    def forward(self, x):
        output, _ = self.model(x)
        return output
    
    def training_step(self, batch, batch_idx):
        data, target, label_mask = batch
        output, features = self.model(data)
        
        try:
            results = self.loss_func(output, target, label_mask,
                                     self.current_epoch)
            loss = results['loss']
        except TypeError:
            loss = self.loss_func(output, target)
            results = {'loss': loss}
        
        self.log('training_loss', loss,
                 sync_dist=True, prog_bar=False,
                 logger=False)
        for k, v in results.items():
            if k != 'loss':
                self.log(k, v,
                         sync_dist=True, prog_bar=False,
                         logger=False)
        
        with torch.no_grad():
            predicted_labels = output.argmax(-1)
            self.train_acc(predicted_labels, target)
            self.log("train_acc", self.train_acc,
                     on_epoch=True, on_step=False,
                     prog_bar=False, logger=False
                     )
        
        return results
    
    def validation_step(self, batch, batch_idx):
        data, target, _ = batch
        output, features = self.model(data)
        
        predicted_labels = output.argmax(-1)
        
        self.val_acc(predicted_labels, target)
        
        self.log(
            'val_acc', self.val_acc,
            prog_bar=False,
            logger=False,
        )
    
    def configure_optimizers(self):
        optimizer = get_optimizer(self.model, self.cfg['train'])
        
        if not self.cfg['train'].get('scheduler', False):
            return optimizer
        
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer,
            T_max=200,
        )
        
        return [optimizer], [scheduler]


# -------------------
# Step 2: Define data
# -------------------

cfg = argparser()
L.seed_everything(cfg['seed'])
train_loader, val_loader, _ = get_data_loader(cfg['data'])

online_mpe_estimator = online_mpe_estimate()
if 'mpe' in cfg and cfg['mpe'].get("use_mpe", False):
    print('>>> Using MPE to estimate prior <<<')
    esti_prior = mpe_estimate(train_loader, cfg)
    # esti_prior = online_mpe_estimator.online_mpe(train_loader, cfg)
    print('Estimated prior: {}'.format(esti_prior))
    cfg['loss']['kwargs']['prior'] = esti_prior

# -------------------
# Step 3: Train
# -------------------
model = eval(cfg['model']['name'])(**cfg['model']['kwargs'])

if cfg['train'].get('compile', False):
    model = torch.compile(model)

loss_func = URELoss(**cfg['loss']['kwargs'])
# loss_func = nn.CrossEntropyLoss()
warped_model = LightningModel(model,
                              loss_func,
                              cfg)

devices = cfg['train'].get('devices', 1)
strategy = 'ddp' if devices > 1 else 'auto'
metrics_tracker = MetricsTracker()
trainer = L.Trainer(
    accelerator="gpu" if torch.cuda.is_available() else "cpu",
    max_epochs=cfg['train']['epoch'],
    precision=cfg['train'].get('precision', 16),
    logger=L.loggers.TensorBoardLogger(
        save_dir=cfg['output'],
        name=cfg.get('expr_name', ''),
        version=cfg.get('version', None),
    ),
    devices=devices,
    strategy=strategy,
    callbacks=[
        OnCheckpointHparams(),
        L.callbacks.LearningRateMonitor(logging_interval='epoch'),
        metrics_tracker,
    ],
)

timer = Timer()
trainer.fit(warped_model, train_loader, val_loader)
timer.tok('Finished training!')

with open(join(trainer.logger.log_dir, 'result.json'), 'w') as f:
    js.dump(metrics_tracker.collection, f, indent=4)
