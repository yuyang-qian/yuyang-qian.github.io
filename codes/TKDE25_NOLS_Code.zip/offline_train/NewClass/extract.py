import yaml
from os.path import join
from os import makedirs
from glob import glob
import argparse
import torch
import numpy as np
from collections import OrderedDict

from model import ResModel, BertModel
from data.wrapper import get_data_loader

try:
    import lightning as L
except:
    import pytorch_lightning as L
import torchmetrics

parser = argparse.ArgumentParser()
parser.add_argument("--result-path", type=str,
                    help='the path of the experiment output')
parser.add_argument("--ckpt-name", type=str, default='',
                    help='the name of the checkpoint, e.g. best.ckpt')

args = parser.parse_args()


class LightningModel(L.LightningModule):
    def __init__(self, model, cfg):
        super().__init__()
        self.model = model
        self.cfg = cfg
        self.val_acc = torchmetrics.Accuracy(task="multiclass",
                                             num_classes=self.cfg['model']['kwargs']['num_classes'])
    
    def predict_step(self, batch, batch_idx, dataloader_idx=0):
        data, target, label_mask = batch
        output, features = self.model(data)
        
        predicted_labels = output.argmax(-1)
        acc = self.val_acc(predicted_labels, target)
        
        return acc, features, target, label_mask


def predict(trainer, model, data_loader, name, output):
    model.eval()
    result = trainer.predict(model, data_loader)
    acc = np.mean([res[0] for res in result])
    features = torch.cat([res[1] for res in result], dim=0)
    targets = torch.cat([res[2] for res in result], dim=0)
    label_masks = torch.cat([res[3] for res in result], dim=0)
    
    print('Accuracy of {} set: {:.4f}'.format(name, acc))
    
    makedirs(output, exist_ok=True)
    torch.save(
        {
            'features'   : features,
            'labels'     : targets,
            'label_masks': label_masks,
        }, join(output, '{}_features.bin'.format(name))
    )


if __name__ == '__main__':
    # path
    cfg_path = join(args.result_path, 'hparams.yaml')
    if not args.ckpt_name:
        ckpt_path = glob(join(args.result_path,
                              'checkpoints', '*.ckpt'))[0]
    else:
        ckpt_path = join(args.result_path, args.ckpt_name)
    output_path = join(args.result_path, 'extracted')
    
    # load config
    with open(cfg_path) as f:
        cfg = yaml.load(f, Loader=yaml.Loader)
    model = eval(cfg['model']['name'])(**cfg['model']['kwargs'])
    warped_model = LightningModel(model, cfg)
    warped_model.load_state_dict(torch.load(ckpt_path)['state_dict'])
    warped_model.eval()
    warped_model.model.eval()
    
    trainer = L.Trainer(accelerator='gpu', devices=1, logger=False)
    
    train_loader, offline_test_loader, online_test_loader = get_data_loader(cfg['data'])
    
    predict(trainer, warped_model, train_loader, 'train', output_path)
    predict(trainer, warped_model, offline_test_loader, 'offline_test', output_path)
    predict(trainer, warped_model, online_test_loader, 'online_test', output_path)
    
    weights = warped_model.model.classifier.weight.data.cpu().detach()
    torch.save(OrderedDict({
        'linear.weight': weights
    }), join(output_path, "black_box.bin"))
