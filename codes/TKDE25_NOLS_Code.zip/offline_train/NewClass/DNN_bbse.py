# /usr/bin/env python
# -*- coding: utf-8 -*-
from os.path import join

import cvxpy as cp
import numpy as np
import torch
import torch.nn.functional as F
from tqdm import tqdm

from utils_pkg.utils import collate_first2_args


class DNN_BBSE(object):
    def __init__(self, cfgs, rep_model, cls_model, train_set, cls_num, device, kwargs, train_BBSE=False):
        cls_model.eval()
        self.cfgs = cfgs
        self.cls_num = cls_num
        self.device = device
        
        self.rep_model = rep_model
        if self.rep_model is not None: self.rep_model = self.rep_model.to(self.device)
        self.cls_model = cls_model.to(self.device)
        
        if not train_BBSE:
            self.cm, self.cm_inv, self.sigma_min = self.confusion_matrix(train_set)
            
            self.cm = self.cm.to(self.device)
            self.cm_inv = self.cm_inv.to(self.device)
        
        self.nn_clip = kwargs.get("nn_clip", False)
        self.softmax = kwargs.get("softmax", False)
        
        self.use_history = kwargs.get('use_history', False)
        self.smooth_ratio = kwargs.get("smooth_ratio", 0)
        self.history = None
        
        self.use_reg = kwargs.get('use_reg', False)
        self.lamda = kwargs.get('lambda', 0)
    
    def train(self, source_loader, criterion, num_epoch, writer):  # train the rep_model and based on source data
        record = {}
        if self.rep_model is not None: self.rep_model.train()
        self.cls_model.train()
        if self.rep_model is not None:
            optimizer = torch.optim.Adam(
                list(self.rep_model.parameters()) + list(self.cls_model.parameters()),
                lr=self.cfgs.offline_cfgs.kwargs['lr']
            )
        else:
            optimizer = torch.optim.Adam(
                list(self.cls_model.parameters()),
                lr=self.cfgs.offline_cfgs.kwargs['lr']
            )
        
        for epoch in range(num_epoch):
            for batch_idx, (data, target) in enumerate(source_loader):
                data, target = data.to(self.device), target.to(self.device)
                if self.rep_model is not None:
                    data = self.rep_model(data)
                output = self.cls_model(data)
                loss = criterion(output, target)
                
                acc = (output.argmax(-1) == target).float().mean()
                
                self.cls_model.zero_grad()
                if self.rep_model is not None: self.rep_model.zero_grad()
                loss.backward()
                
                optimizer.step()
                
                if batch_idx % 10 == 0:
                    print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}\tAcc: {:.6f}'.format(
                        epoch,
                        batch_idx * len(data),
                        len(source_loader.dataset),
                        100. * batch_idx / len(source_loader),
                        loss.item(),
                        acc.item()
                    ))
                    writer.add_scalar('Train/Loss', loss.item(), epoch * len(source_loader) + batch_idx)
                    writer.add_scalar('Train/Acc', acc.item(), epoch * len(source_loader) + batch_idx)
                    
                    record['loss'] = loss.item()
            # torch.save(model.state_dict(), join(expr_path, 'initial_model.bin'))
            if self.rep_model is not None:
                torch.save(self.rep_model.state_dict(), join(self.cfgs.offline_cfgs.kwargs['save_path'], 'rep_model_epoch_{}.bin'.format(epoch)))
            torch.save(self.cls_model.state_dict(), join(self.cfgs.offline_cfgs.kwargs['save_path'], 'cls_model_epoch_{}.bin'.format(epoch)))
        return record
    
    def get_sigma_min(self):
        return self.sigma_min
    
    @torch.no_grad()
    def confusion_matrix(self, train_set):
        cmatrix = torch.zeros((self.cls_num, self.cls_num)).cpu()
        tot_data = None
        tot_target = None
        
        if self.rep_model is not None: self.rep_model.eval()
        
        source_loader = torch.utils.data.DataLoader(train_set,
                                                    batch_size=self.cfgs.online_cfgs.kwargs.get('rep_batch_size', 256),
                                                    shuffle=False,
                                                    pin_memory=True,
                                                    drop_last=False,
                                                    collate_fn=collate_first2_args)
        for batch_idx, (data, target) in enumerate(tqdm(source_loader, desc='Confusion Matrix | Getting Representation')):
            data, target = data.to(self.device), target.to(self.device)
            # print('data shape:', data.shape)
            if self.rep_model is not None:
                data = self.rep_model(data).detach()
            if tot_data is None:
                tot_data = data.cpu().detach()
                tot_target = target.cpu().detach()
            else:
                tot_data = torch.cat((tot_data, data.cpu().detach()), dim=0)
                tot_target = torch.cat((tot_target, target.cpu().detach()), dim=0)
        
        cpu_cls_model = self.cls_model.cpu()
        output = cpu_cls_model(tot_data)
        pred = output.argmax(-1)
        indices = self.cls_num * pred + tot_target
        
        m = torch.bincount(indices, minlength=self.cls_num ** 2)
        cmatrix += m.reshape(cmatrix.shape)
        
        cmatrix_joint = F.normalize(cmatrix.float().view(-1),
                                    p=1, dim=0).reshape(self.cls_num, self.cls_num)
        u, s, v = torch.svd(cmatrix_joint)
        
        cmatrix = F.normalize(cmatrix.float(), p=1, dim=0)
        _u, _s, _v = torch.svd(cmatrix)
        
        cm_inv = cmatrix.inverse()
        
        print("[BBSE] Joint Minimum Singular Value: {}".format(s.min().item()))
        print("[BBSE] Conditional Minimum Singular Value: {}".format(_s.min().item()))
        
        return cmatrix, cm_inv, _s.min().item()
    
    @torch.no_grad()
    def estimate(self, target_x):
        self.cls_model = self.cls_model.cpu()
        if self.rep_model is not None:
            target_x = self.rep_model(target_x)
        target_x = target_x.cpu().detach()
        output = self.cls_model(target_x.to(torch.float32))
        # if output.shape[0] == 0:
        #     output = torch.ones((1, self.cls_num), device=self.device) / self.cls_num
        # print(output.shape)
        pred = output.argmax(-1)
        q_count = torch.bincount(pred, minlength=self.cls_num).cpu()
        q_f = F.normalize(q_count.float(), p=1, dim=0)
        
        if self.use_reg:
            q_estimate = self.reg_estimate(q_f)
        else:
            q_estimate = self.cm_inv.cpu().matmul(q_f.T)
            
            if self.nn_clip:
                q_estimate = q_estimate.clamp(min=0)
            
            if self.softmax:
                q_estimate = q_estimate.softmax(dim=-1)
            
            if self.use_history and self.history is not None:
                q_estimate = self.history * self.smooth_ratio + q_estimate * (1 - self.smooth_ratio)
        
        self.history = q_estimate
        return q_estimate
    
    def reg_estimate(self, q_f):
        C = self.cm.detach().numpy()
        q = q_f.detach().numpy().flatten()
        ones = np.ones(len(q))
        
        history = None
        if self.history is not None:
            history = self.history.detach().numpy().flatten()
        
        ans = cp.Variable(len(q))
        loss_func = cp.pnorm(C @ ans - q, p=2)
        if history is not None:
            loss_func += self.lamda * cp.pnorm(ans / history - ones, p=2)
        objective = cp.Minimize(loss_func)
        prob = cp.Problem(objective)
        
        prob.solve()
        
        q_estimate = torch.from_numpy(ans.value).float()
        
        return q_estimate
